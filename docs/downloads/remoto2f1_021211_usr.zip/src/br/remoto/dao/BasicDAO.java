package br.remoto.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import br.remoto.model.ReMoto;


public class BasicDAO 
{
	protected static final String jdbcDriver = "org.hsqldb.jdbcDriver";
	protected static final String jdbcUser = "sa";
	protected static final String jdbcPassword = "";
	protected static String jdbcUrl;
	
	protected static Connection con;
	protected static boolean serverStarted = false;
	protected ResultSet rs;
	protected Statement st;
	protected PreparedStatement pst; 	
	
	
	public BasicDAO()
	{
	}
	

	public void connect()
	{
		try 
		{
			if( con == null )
			{
				Class.forName( jdbcDriver );
				
				jdbcUrl = "jdbc:hsqldb:file:" + ReMoto.path + "db/" + "remoto;shutdown=true";
				
				con = DriverManager.getConnection( jdbcUrl, jdbcUser, jdbcPassword ); 
				
				//System.out.println("BasicDAO.connect");
			}
		} 
		catch (ClassNotFoundException e) 
		{
			System.out.println( e.getMessage() ); 
		} 
		catch (SQLException e) 
		{
			System.out.println( e.getMessage() ); 
		}
		catch(Exception e) 
		{ 
			System.out.println( e.getMessage() ); 
		} 
	}


	public void close()
	{
	}

	
	public void disconnect()
	{
		try 
		{
			if( rs != null ) rs.close();
			if( st != null ) st.close(); 
			if( pst != null ) pst.close(); 
			
			rs = null;
			st = null;
			pst = null;
			
			if( con != null ) con.close(); 
			
			con = null;
			//System.out.println("BasicDAO.disconnect");
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
}
