
package br.remoto.model.vo;

import java.io.Serializable;



public class MotorUnitVO implements Serializable
{
	private static final long serialVersionUID = 1L;

	protected double maxTension1;
	protected double maxTension2;
	protected double twitchTension1;
	protected double twitchTension2;
	protected double contractionTime1;
	protected double contractionTime2;
	protected double ampEMG1;
	protected double ampEMG2;
	protected double lambdaEMG1;
	protected double lambdaEMG2;
	protected boolean active;
	protected String type;
	protected String cdNucleus;

	
	public MotorUnitVO()
	{
	}


	public double getAmpEMG1() {
		return ampEMG1;
	}
	public void setAmpEMG1(double ampEMG1) {
		this.ampEMG1 = ampEMG1;
	}
	public double getAmpEMG2() {
		return ampEMG2;
	}
	public void setAmpEMG2(double ampEMG2) {
		this.ampEMG2 = ampEMG2;
	}
	public double getContractionTime1() {
		return contractionTime1;
	}
	public void setContractionTime1(double contractionTime1) {
		this.contractionTime1 = contractionTime1;
	}
	public double getContractionTime2() {
		return contractionTime2;
	}
	public void setContractionTime2(double contractionTime2) {
		this.contractionTime2 = contractionTime2;
	}
	public double getLambdaEMG1() {
		return lambdaEMG1;
	}
	public void setLambdaEMG1(double lambdaEMG1) {
		this.lambdaEMG1 = lambdaEMG1;
	}
	public double getLambdaEMG2() {
		return lambdaEMG2;
	}
	public void setLambdaEMG2(double lambdaEMG2) {
		this.lambdaEMG2 = lambdaEMG2;
	}
	public double getTwitchTension1() {
		return twitchTension1;
	}
	public void setTwitchTension1(double twitchTension1) {
		this.twitchTension1 = twitchTension1;
	}
	public double getTwitchTension2() {
		return twitchTension2;
	}
	public void setTwitchTension2(double twitchTension2) {
		this.twitchTension2 = twitchTension2;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public String getCdNucleus() {
		return cdNucleus;
	}
	public void setCdNucleus(String cdNucleus) {
		this.cdNucleus = cdNucleus;
	}
	public double getMaxTension1() {
		return maxTension1;
	}
	public void setMaxTension1(double maxTension1) {
		this.maxTension1 = maxTension1;
	}
	public double getMaxTension2() {
		return maxTension2;
	}
	public void setMaxTension2(double maxTension2) {
		this.maxTension2 = maxTension2;
	}
	
}
	
