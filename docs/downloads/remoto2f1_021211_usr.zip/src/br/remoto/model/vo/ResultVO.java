package br.remoto.model.vo;

import java.io.Serializable;

import br.remoto.model.ReMoto;
import br.remoto.util.Coordenate;

public class ResultVO implements Serializable 
{
	private static final long serialVersionUID = 1L;

	private String task;
	private String cdEMG;
	private String cdForce;
	private String cdSignal;
	private String cdConductance;
	private String cdSpikes;
	private String cdFiringRate;
	private String cdHistogram;
	private String cdProperties;
	private String whichSignal;
	
	private double sample;
	private double fcLow;
	private double fcHigh;
	private double binWidth;
	private int numberOfBins;
	
	private boolean withEMGnoise;
	private boolean withEMGattenuation;
	
	private String filter;
	private String cdNucleus;
	private String opt;
	private Coordenate coordenate = new Coordenate();
	
	
	public ResultVO()
	{
		// Default values
		fcLow = 50;
		fcHigh = 1000;
		filter = ReMoto.FirstSecond;
		whichSignal = ReMoto.Vs;
		withEMGnoise = true;
		withEMGattenuation = true;
	}
	
	public String getTask() {
		return task;
	}
	public void setTask(String task) {
		this.task = task;
	}
	public String getCdEMG() {
		return cdEMG;
	}
	public void setCdEMG(String cdEMG) {
		this.cdEMG = cdEMG;
	}
	public String getCdForce() {
		return cdForce;
	}
	public void setCdForce(String cdForce) {
		this.cdForce = cdForce;
	}
	public String getCdSpikes() {
		return cdSpikes;
	}
	public void setCdSpikes(String cdSpikes) {
		this.cdSpikes = cdSpikes;
	}
	public String getCdSignal() {
		return cdSignal;
	}
	public void setCdSignal(String cdVm) {
		this.cdSignal = cdVm;
	}
	public double getSample() {
		return sample;
	}
	public void setSample(double sample) {
		this.sample = sample;
	}
	public double getFcHigh() {
		return fcHigh;
	}
	public void setFcHigh(double fcHigh) {
		this.fcHigh = fcHigh;
	}
	public double getFcLow() {
		return fcLow;
	}
	public void setFcLow(double fcLow) {
		this.fcLow = fcLow;
	}
	public String getFilter() 
	{
		if( filter == null )
			filter = ReMoto.FirstSecond;
		
		return filter;
	}
	public void setFilter(String filter) {
		this.filter = filter;
	}
	public String getCdNucleus() {
		return cdNucleus;
	}
	public void setCdNucleus(String cdNucleus) {
		this.cdNucleus = cdNucleus;
	}
	public Coordenate getCoordenate() {
		return coordenate;
	}
	public void setCoordenate(Coordenate coordenate) {
		this.coordenate = coordenate;
	}
	public String getWhichSignal() 
	{
		if( whichSignal == null )
			whichSignal = ReMoto.Vs;
		
		return whichSignal;
	}
	public void setWhichSignal(String whichVm) {
		this.whichSignal = whichVm;
	}
	public String getCdConductance() {
		return cdConductance;
	}
	public void setCdConductance(String cdConductance) {
		this.cdConductance = cdConductance;
	}
	public String getCdHistogram() {
		return cdHistogram;
	}
	public void setCdHistogram(String cdHistogram) {
		this.cdHistogram = cdHistogram;
	}

	public double getBinWidth() {
		return binWidth;
	}

	public void setBinWidth(double binWidth) {
		this.binWidth = binWidth;
	}

	public int getNumberOfBins() {
		return numberOfBins;
	}

	public void setNumberOfBins(int numberOfBins) {
		this.numberOfBins = numberOfBins;
	}

	public boolean isWithEMGnoise() {
		return withEMGnoise;
	}

	public void setWithEMGnoise(boolean withEMGnoise) {
		this.withEMGnoise = withEMGnoise;
	}

	public String getOpt() {
		return opt;
	}

	public void setOpt(String opt) {
		this.opt = opt;
	}

	public String getCdFiringRate() {
		return cdFiringRate;
	}

	public void setCdFiringRate(String cdFiringRate) {
		this.cdFiringRate = cdFiringRate;
	}

	public String getCdProperties() {
		return cdProperties;
	}

	public void setCdProperties(String cdProperties) {
		this.cdProperties = cdProperties;
	}

	public boolean isWithEMGattenuation() {
		return withEMGattenuation;
	}

	public void setWithEMGattenuation(boolean withEMGattenuation) {
		this.withEMGattenuation = withEMGattenuation;
	}

}
