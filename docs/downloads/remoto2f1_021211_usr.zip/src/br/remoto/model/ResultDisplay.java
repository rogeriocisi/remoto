package br.remoto.model;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.Double;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.servlet.ServletOutputStream;

import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.statistics.HistogramDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import br.remoto.model.Neuron.Motoneuron;
import br.remoto.model.Neuron.NeuralTract;
import br.remoto.model.Neuron.Neuron;
import br.remoto.model.Neuron.SensoryFiber;
import br.remoto.model.Neuron.SpinalNeuron;
import br.remoto.model.vo.ResultVO;
import br.remoto.model.vo.Summary;
import br.remoto.util.PlotBarGraph;
import br.remoto.util.ButterworthBilinear;
import br.remoto.util.ButterworthImpulseInvariance;
import br.remoto.util.Coordenate;
import br.remoto.util.ElectroCalculation;
import br.remoto.util.PlotCombinedGraph;
import br.remoto.util.PlotHistogramGraph;
import br.remoto.util.PlotLineGraph;
import br.remoto.util.PlotScatterGraph;
import br.remoto.util.Point;
import br.remoto.util.Signal;


public class ResultDisplay
{
	private Configuration conf;
	private ArrayList output;
	private ResultVO result;
	private Coordenate coord;
	private String cdNucleus;
	private double sample;
	private Neuron neurons[];
	private Muscle muscle;
	private MessageFormat mf;
	
	//Modified by Vitor
	//private String graphicEnvironment = "";
	
	public int chartHeigth 	= 500;
	public int chartWidth 	= 400;
	
	public int chartHeigth_new 	= 700;
	public int chartWidth_new  	= 500;

	public ResultDisplay(Configuration conf)
	{
		this.conf = conf;
	}
	
	
	public void generateResults(Simulation sim, OutputStream stream)
    {
			result = conf.getResult();
			coord = result.getCoordenate();
			cdNucleus = result.getCdNucleus();
			sample = 1.0 / result.getSample();
	
			mf = new MessageFormat("{0,number,#.#####}", Locale.US);
			neurons = sim.getNeurons(cdNucleus);
			
			//System.out.println("coord.getYfin(): " + coord.getYfin());
			
			if( coord == null ) 
				coord = new Coordenate();
			
			// Recreate muscle in order to allow parameters to be modified, before each graph generation
			if( result.getTask().equals( ReMoto.force ) || 
				result.getTask().equals( ReMoto.EMG ) ||
				result.getTask().equals( ReMoto.spikesAndForce ) ||
				result.getTask().equals( ReMoto.spikesAndEMG ) ||
				result.getTask().equals( ReMoto.properties ) )
			{
				sim.createMuscles(); //rcisi@13jun2009
				
				muscle = sim.getMuscle( cdNucleus );
				
				if( muscle == null )
				{
					if( result.getOpt().equals( ReMoto.file ) )
					{
						byte[] out = ("There is no data to generate the selected file").getBytes();
	
						try 
						{
							stream.write( out );
						} 
						catch (IOException e) 
						{
							e.printStackTrace();
						}
					}
					else
					{
						XYSeriesCollection dataset = new XYSeriesCollection();
						
						if( result.getOpt().equals( ReMoto.chart_img )){
							PlotLineGraph.generate(dataset,
		    						stream,
									"There is no data to generate the selected graphic", 
									"", 
									"",
									chartHeigth,
									chartWidth);
						}
						else if( result.getOpt().equals( ReMoto.chart_img_new )){
							PlotLineGraph.generate(dataset,
		    						stream,
									"There is no data to generate the selected graphic", 
									"", 
									"",
									chartHeigth_new,
									chartWidth_new);
						}
					}
					
					return;
				}
				
				boolean emgAttenuation = result.isWithEMGattenuation();
				
				muscle.reset(sample, emgAttenuation);
			}
			
			try
			{
				// ------------------------------------------------------
				// Create charts with data from spike times, EMG or force
				
				if( result.getTask().equals( ReMoto.force ) )
				{
					
					displayForce(stream);
					
				}
				else if( result.getTask().equals( ReMoto.EMG ) )
				{
					displayEMG(stream);
				}
				else if( result.getTask().equals( ReMoto.spikes ) )
				{
					displaySpikes(stream);
				}
				else if( result.getTask().equals( ReMoto.firingRate ) )
				{
					displayFiring(stream);
				}
				else if( result.getTask().equals( ReMoto.signal ) )
				{
					displaySignal(stream);
		        }
				else if( result.getTask().equals( ReMoto.histogram ) )
				{
					displayHistogram(stream);
				}
				else if( result.getTask().equals( ReMoto.spikesAndForce ) )
				{
					displaySpikesForce(stream);
				}
				else if( result.getTask().equals( ReMoto.spikesAndEMG ) )
				{
					displaySpikesEMG(stream);
				}
				else if( result.getTask().equals( ReMoto.properties ) )
				{
					displayProperties(stream);
				}
			}
			catch (IOException e)
			{
	    		System.out.println(e.getMessage());
			}
	}
	

	public void generateResults(Simulation sim, ArrayList output)
    {
		this.output = output;

		generateResults(sim, (ServletOutputStream)null);
    }
	
	
	private void displaySpikes(OutputStream stream) throws IOException
	{
		String cdNeuron = result.getCdSpikes();
		
		XYSeriesCollection dataset = processSpikes(stream, cdNeuron);
		
		if( result.getOpt().equals( ReMoto.chart_img ))
	    {
			PlotScatterGraph.generate(dataset,
								 stream,
								 "Spikes - " + cdNeuron, 
								 "Time [ms]", 
								 "Index",
								 chartHeigth,
								 chartWidth);
	    }
		else if(result.getOpt().equals( ReMoto.chart_img_new )){
			PlotScatterGraph.generate(dataset,
					 stream,
					 "Spikes - " + cdNeuron, 
					 "Time [ms]", 
					 "Index",
					 chartHeigth_new,
					 chartWidth_new);
		}
	}
	

	private void displayFiring(OutputStream stream) throws IOException
	{
		String cdNeuron = result.getCdFiringRate();
		
		XYSeriesCollection dataset = processFiring(stream, cdNeuron);
		
		if( result.getOpt().equals( ReMoto.chart_img ))
	    {
			PlotScatterGraph.generate(dataset,
								 stream,
								 "Firing rate - " + cdNeuron, 
								 "Time [ms]", 
								 "Firing rate [Hz]",
								 chartHeigth,
								 chartWidth);
	    }
		else if( result.getOpt().equals( ReMoto.chart_img_new ) ){
			PlotScatterGraph.generate(dataset,
					 stream,
					 "Firing rate - " + cdNeuron, 
					 "Time [ms]", 
					 "Firing rate [Hz]",
					 chartHeigth_new,
					 chartWidth_new);
		}
	}

	
	private void displayForce(OutputStream stream) throws IOException
	{
		
		String cdNeuron = result.getCdForce();
		//System.out.println("cdNeuron: " + cdNeuron);
		
		XYSeriesCollection dataset = processForce(stream, cdNeuron);
		
		//System.out.println("result.getOpt(): " + result.getOpt());
		
		if( result.getOpt().equals( ReMoto.chart_img))
		{
			PlotLineGraph.generate(dataset,
	    						stream,
								"Force", 
								"Time [ms]", 
								"Force [N]",
								chartHeigth,
								chartWidth);
		}
		else if(result.getOpt().equals( ReMoto.chart_img_new ))
		{
			PlotLineGraph.generate(dataset,
	    						stream,
								"Force", 
								"Time [ms]", 
								"Force [N]",
								chartHeigth_new,
								chartWidth_new);
		}
	}

	
	private void displayEMG(OutputStream stream) throws IOException
	{
		String cdNeuron = result.getCdEMG();
		
		XYSeriesCollection dataset = processEMG(stream, cdNeuron);
		
		if( result.getOpt().equals( ReMoto.chart_img ))
		{
	    	PlotLineGraph.generate(dataset,
	    						stream,
								"EMG", 
								"Time [ms]", 
								"EMG [mV]",
								chartHeigth,
								chartWidth);
		}
		else if(result.getOpt().equals( ReMoto.chart_img_new )  )
		{
	    	PlotLineGraph.generate(dataset,
	    						stream,
								"EMG", 
								"Time [ms]", 
								"EMG [mV]",
								chartHeigth_new,
								chartWidth_new);
		}
	}

	
	private void displaySpikesForce(OutputStream stream) throws IOException
	{
		XYSeriesCollection datasetForce = processForce( stream, ReMoto.ALL_MU );
		XYSeriesCollection datasetSpike = processSpikes( stream, ReMoto.ALL_MN_end_plate );
		
		if( result.getOpt().equals( ReMoto.chart_img ))
		{
			PlotCombinedGraph.generate(	datasetForce,
					datasetSpike,
					stream,
					"Force and spikes", 
					"Time [ms]", 
					"Motoneuron", 
					"Force [N]",
					 chartHeigth,
					 chartWidth);
		}
		else if(result.getOpt().equals( ReMoto.chart_img_new )  )
		{
			PlotCombinedGraph.generate(	datasetForce,
					datasetSpike,
					stream,
					"Force and spikes", 
					"Time [ms]", 
					"Motoneuron", 
					"Force [N]",
					 chartHeigth_new,
					 chartWidth_new);
		}
	}
	
	
	private void displaySpikesEMG(OutputStream stream) throws IOException
	{
		XYSeriesCollection datasetEMG = processEMG( stream, ReMoto.ALL_MU );
		XYSeriesCollection datasetSpike = processSpikes( stream, ReMoto.ALL_MN_end_plate );
		
    	if( result.getOpt().equals( ReMoto.chart_img ))
		{
    		PlotCombinedGraph.generate(	datasetEMG,
					datasetSpike,
					stream,
					"EMG and spikes", 
					"Time [ms]", 
					"Motoneuron", 
					"EMG [mV]" ,
					 chartHeigth,
					 chartWidth);
		}
		else if(result.getOpt().equals( ReMoto.chart_img_new )  )
		{
			PlotCombinedGraph.generate(	datasetEMG,
					datasetSpike,
					stream,
					"EMG and spikes", 
					"Time [ms]", 
					"Motoneuron", 
					"EMG [mV]" ,
					 chartHeigth_new,
					 chartWidth_new);
		}
	}
	
	
	private void displaySignal(OutputStream stream) throws IOException
	{
		
		
			String cdNeuron = result.getCdSignal();
			String cdConductance = result.getCdConductance();
			
	    	SpinalNeuron spinalNeu = null;
			NeuralTract tractNeu = null;
			Current current = null;
			
			// Create chart for signal
			XYSeries serie = new XYSeries( cdNeuron );
			
			for(int n = 0; neurons != null && n < neurons.length; n++)
		    {
				Neuron neu = (Neuron)neurons[n];
		    	
		        if( neu.isStoredSignals() || neu.getCategory().equals( ReMoto.TR ) )
		        {
		        	String cd = neurons[n].getCd();
		
		        	// cdNeuron.equals("") indicate all neurons
		        	if( !cdNeuron.equals("") &&
		        		!cdNeuron.equals( cd ) &&
			        	!( cdNeuron.equals( ReMoto.CM_TR_ext ) && neu.getType().equals( ReMoto.CM_ext ) ) &&
					    !( cdNeuron.equals( ReMoto.CM_TR_flex ) && neu.getType().equals( ReMoto.CM_flex ) ) &&
					    !( cdNeuron.equals( ReMoto.RBE_TR_ext ) && neu.getType().equals( ReMoto.RBE_ext ) ) &&
					    !( cdNeuron.equals( ReMoto.RBE_TR_flex ) && neu.getType().equals( ReMoto.RBE_flex ) ) &&
					    !( cdNeuron.equals( ReMoto.RBI_TR_ext ) && neu.getType().equals( ReMoto.RBI_ext ) ) &&
					    !( cdNeuron.equals( ReMoto.RBI_TR_flex ) && neu.getType().equals( ReMoto.RBI_flex ) ) )
		        	{
		        		continue;
		        	}
		        	
		        	if( neu.isStoredSignals() )
		        	{
		        		spinalNeu = (SpinalNeuron)neu;
		    			current = spinalNeu.getCurrent();
		        	}
		        	else if( neu.getCategory().equals( ReMoto.TR ) )
		        	{
		        		tractNeu = (NeuralTract)neu;
		        	}
		        	else
		        		continue;
	
		        	if( result.getTask().equals( ReMoto.signal ) && cdNeuron.equals("") )
		        		stream.write( (cd + "\n").getBytes() );
		        	
	    			Signal signal = null;
		    		double t = 0;
		    		double value = 0;
		
		    		// Injected current or modulated mean value
		    		if( ( result.getWhichSignal().equals( ReMoto.inj ) && current != null ) || 
		    			neu.getCategory().equals( ReMoto.TR ) )
		    		{
						int totSteps = (int)(conf.getTFin()/sample);
		    			
	    				for(int i = 0; i < totSteps; i++)
	    				{
	    					t = sample * i;
	
	    					if( result.getWhichSignal().equals( ReMoto.inj ) )
	    						value = current.getCurrent(t);
	    					else
	    						value = tractNeu.meanValue(t);
	
			        		if( !xLimit(coord, t) || !yLimit(coord, value) )
			        			continue;
			        		
			        		if( result.getOpt().equals( ReMoto.chart_img ) || result.getOpt().equals( ReMoto.chart_img_new )  )
							{
			        			serie.add(t, value);
							}
			        		else
			        		{
								Object[] objT = { new Double(t) };
								Object[] objVm = { new Double(value) };
								stream.write( (mf.format( objT ) + "\t" + mf.format( objVm ) + "\n").getBytes() );
			        		}
	    				}
		    		}
		    		// Internal neural signals
		    		else
		    		{
			    		for(int i = 0; i < spinalNeu.getSignalStore().size(); i++ )
			        	{
			    			signal = (Signal)spinalNeu.getSignalStore().get(i);
			
			        		if( result.getWhichSignal().equals( signal.getType() ) ||
			        			result.getWhichSignal().equals( "g" ) && cdConductance.equals( signal.getType() ) )
							{
			        			value = signal.getValue();
			        			
			        			// Conductance signals must be converted to nS
			        			if( result.getWhichSignal().equals( "g" ) )
			        				value = value * 1000;
							}
			    			else
			    			{
			    				continue;
			    			}
			        		
			        		if( !yLimit(coord, value) )
			        			continue;
			    			
			        		t = signal.getTime();
			        		
			        		if( !xLimit(coord, t) )
			        			continue;
			        		
			        		if( result.getOpt().equals( ReMoto.chart_img ) || result.getOpt().equals( ReMoto.chart_img_new ) )
							{
			        			serie.add(t, value);
							}
			        		else
			        		{
								Object[] objT = { new Double(t) };
								Object[] objVm = { new Double(value) };
								stream.write( (mf.format( objT ) + "\t" + mf.format( objVm ) + "\n").getBytes() );
			        		}
			        	}
		    		}
			        
			        // It has already found the target neuron
			        break;
		        }
		    }
	    	
			if( result.getOpt().equals( ReMoto.chart_img ) || result.getOpt().equals( ReMoto.chart_img_new ) )
			{
				String title = "";
				String label = "";
				
	    		if( cdNeuron.equals( ReMoto.CM_TR_ext ) || 
	    	    	cdNeuron.equals( ReMoto.CM_TR_flex ) || 
	    	    	cdNeuron.equals( ReMoto.RBE_TR_ext ) || 
	    	    	cdNeuron.equals( ReMoto.RBE_TR_flex ) || 
	    	    	cdNeuron.equals( ReMoto.RBI_TR_ext ) || 
	    	    	cdNeuron.equals( ReMoto.RBI_TR_flex ) )
				{
					title = "ISI - mean value";
	    			label = "ISI [ms]";
				}
				else if( result.getWhichSignal().equals( ReMoto.Vs ) || result.getWhichSignal().equals( ReMoto.Vd ) )
				{
					title = "Membrane Potential";
	    			label = "Membrane potential [mV]";
				}
				else if( result.getWhichSignal().equals( ReMoto.inj ) )
				{
					title = "Injected current";
	    			label = "Current [nA]";
				}
				else
				{
					title = "Conductance Activity - " + cdConductance;
	    			label = "Conductance value [nS]";
				}
				
				XYSeriesCollection dataset = new XYSeriesCollection( serie );
				
	        	if( result.getOpt().equals( ReMoto.chart_img ))
	    		{
	        		PlotLineGraph.generate( dataset,
							 //ReMoto.path + "\\results\\chart" + cd + ".jpg",
							 stream,
							 title, 
							 "Time [ms]", 
							 label,
							 chartHeigth,
							 chartWidth);
	    		}
	    		else if(result.getOpt().equals( ReMoto.chart_img_new )  )
	    		{
	    			PlotLineGraph.generate( dataset,
							 //ReMoto.path + "\\results\\chart" + cd + ".jpg",
							 stream,
							 title, 
							 "Time [ms]", 
							 label,
							 chartHeigth_new,
							 chartWidth_new);
	    		}
	        	
			}
	}	
	
	
	private void displayHistogram(OutputStream stream) throws IOException
	{
		HistogramDataset dataset = new HistogramDataset();
		
		String cdNeuron = result.getCdHistogram();	
		int numberOfBins = result.getNumberOfBins();
		
		int numSpikes = 0;
		
	    for(int n = 0; neurons != null && n < neurons.length; n++)
	    {
	    	String cd = neurons[n].getCd();
	    	
	    	
	    	// Plot histogram for the selected neuron 
	    	if( !cdNeuron.equals( ReMoto.ALL_MN ) && 
	    		!cdNeuron.equals( ReMoto.ALL_MN_S ) && 
	    		!cdNeuron.equals( ReMoto.ALL_MN_FR ) && 
	    		!cdNeuron.equals( ReMoto.ALL_MN_FF ) && 
	    		!cdNeuron.equals( ReMoto.ALL_CM_ext ) && 
	    		!cdNeuron.equals( ReMoto.ALL_CM_flex ) && 
	    		!cdNeuron.equals( ReMoto.ALL_RBE_ext ) && 
	    		!cdNeuron.equals( ReMoto.ALL_RBE_flex ) && 
	    		!cdNeuron.equals( ReMoto.ALL_RBI_ext ) && 
	    		!cdNeuron.equals( ReMoto.ALL_RBI_flex ) && 
	    		!cdNeuron.equals( ReMoto.ALL_Ia ) && 
	    		!cdNeuron.equals( ReMoto.ALL_Ib ) && 
	    		!cdNeuron.equals( cd ) )
	    		continue;
	    	
	    	if( ( cdNeuron.equals( ReMoto.ALL_MN ) && !neurons[n].getCategory().equals( ReMoto.MN ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_MN_S ) && !neurons[n].getType().equals( ReMoto.S ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_MN_FR ) && !neurons[n].getType().equals( ReMoto.FR ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_MN_FF ) && !neurons[n].getType().equals( ReMoto.FF ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_CM_ext ) && !neurons[n].getType().equals( ReMoto.CM_ext ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_CM_flex ) && !neurons[n].getType().equals( ReMoto.CM_flex ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_RBE_ext ) && !neurons[n].getType().equals( ReMoto.RBE_ext ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_RBE_flex ) && !neurons[n].getType().equals( ReMoto.RBE_flex ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_RBI_ext ) && !neurons[n].getType().equals( ReMoto.RBI_ext ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_RBI_flex ) && !neurons[n].getType().equals( ReMoto.RBI_flex ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_Ia ) && !neurons[n].getType().equals( ReMoto.Ia ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_Ib ) && !neurons[n].getType().equals( ReMoto.Ib ) ) )
	    		continue;
	    	
			List spikes = neurons[n].getTerminalSpikeTrain();

			double lastSpike = 0;
			double interval;
			
			
			if( spikes.size() > 0 )
				lastSpike = ((Double)(spikes.get(0))).doubleValue();
	
			// Colect all ISI
			for(int i = 1; i < spikes.size(); i++)
			{
				double tSpike = ((Double)(spikes.get(i))).doubleValue();
				interval = tSpike - lastSpike;
	    		lastSpike = tSpike;
	    		
	    		if( !xLimit(coord, interval) )
	    			continue;
	    		
	    		numSpikes++;
			}
	    }
	    
	    
	    double valuesISI[] = new double[numSpikes];
	    numSpikes = 0;
	    
	    for(int n = 0; neurons != null && n < neurons.length; n++)
	    {
	    	String cd = neurons[n].getCd();
	    	
	    	
	    	// Plot histogram for the selected neuron 
	    	if( !cdNeuron.equals( ReMoto.ALL_MN ) && 
	    		!cdNeuron.equals( ReMoto.ALL_MN_S ) && 
	    		!cdNeuron.equals( ReMoto.ALL_MN_FR ) && 
	    		!cdNeuron.equals( ReMoto.ALL_MN_FF ) && 
	    		!cdNeuron.equals( ReMoto.ALL_CM_ext ) && 
	    		!cdNeuron.equals( ReMoto.ALL_CM_flex ) && 
	    		!cdNeuron.equals( ReMoto.ALL_RBE_ext ) && 
	    		!cdNeuron.equals( ReMoto.ALL_RBE_flex ) && 
	    		!cdNeuron.equals( ReMoto.ALL_RBI_ext ) && 
	    		!cdNeuron.equals( ReMoto.ALL_RBI_flex ) && 
	    		!cdNeuron.equals( ReMoto.ALL_Ia ) && 
	    		!cdNeuron.equals( ReMoto.ALL_Ib ) && 
	    		!cdNeuron.equals( cd ) )
	    		continue;
	    	
	    	if( ( cdNeuron.equals( ReMoto.ALL_MN ) && !neurons[n].getCategory().equals( ReMoto.MN ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_MN_S ) && !neurons[n].getType().equals( ReMoto.S ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_MN_FR ) && !neurons[n].getType().equals( ReMoto.FR ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_MN_FF ) && !neurons[n].getType().equals( ReMoto.FF ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_CM_ext ) && !neurons[n].getType().equals( ReMoto.CM_ext ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_CM_flex ) && !neurons[n].getType().equals( ReMoto.CM_flex ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_RBE_ext ) && !neurons[n].getType().equals( ReMoto.RBE_ext ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_RBE_flex ) && !neurons[n].getType().equals( ReMoto.RBE_flex ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_RBI_ext ) && !neurons[n].getType().equals( ReMoto.RBI_ext ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_RBI_flex ) && !neurons[n].getType().equals( ReMoto.RBI_flex ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_Ia ) && !neurons[n].getType().equals( ReMoto.Ia ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_Ib ) && !neurons[n].getType().equals( ReMoto.Ib ) ) )
	    		continue;
	    	
			List spikes = neurons[n].getTerminalSpikeTrain();

			double lastSpike = 0;
			double interval;
			
			
			if( spikes.size() > 0 )
				lastSpike = ((Double)(spikes.get(0))).doubleValue();
	
    		
			// Colect all ISI
			for(int i = 1; i < spikes.size(); i++)
			{
				double tSpike = ((Double)(spikes.get(i))).doubleValue();
				interval = tSpike - lastSpike;
	    		lastSpike = tSpike;
	    		
	    		if( !xLimit(coord, interval) )
	    			continue;
	    		
	    		valuesISI[numSpikes++] = interval;
			}
	    }
	    


	    if(valuesISI.length != 0)
	    	dataset.addSeries("H1", valuesISI, numberOfBins);
		
	    
		if( result.getOpt().equals( ReMoto.chart_img ))
		{
			PlotHistogramGraph.generate(dataset,
					 stream,
					 "Histogram - " + cdNeuron, 
					 "Mean ISI [ms]", 
					 "Number of elements in each bin",
					 chartHeigth,
					 chartWidth);
		}
		else if(result.getOpt().equals( ReMoto.chart_img_new )  )
		{
			PlotHistogramGraph.generate(dataset,
					 stream,
					 "Histogram - " + cdNeuron, 
					 "Mean ISI [ms]", 
					 "Number of elements in each bin",
					 chartHeigth_new,
					 chartWidth_new);
		}
		
	}
	
	
	
	private void displayProperties(OutputStream stream) throws IOException
	{
		String cdNeuron = result.getCdProperties();
		
		if( cdNeuron.equals( ReMoto.ALL_MN ) )
			stream.write( ("Id\t\tRheobase\tSoma thresh.\tInp. resist.\tAxon veloc.\tAxon thresh.\tPosition (rostro-caudal axis)\n\n").getBytes() );
		else if( cdNeuron.equals( ReMoto.ALL_IN ) )
			stream.write( ("Id\t\tRheobase\tThresh.\tInp. resist.\tPosition\n\n").getBytes() );
		else
		{
			displayPropertiesMotorUnits(stream);
			
			return;
		}

		mf = new MessageFormat("{0,number,#.###}", Locale.US);

		for(int n = 0; neurons != null && n < neurons.length; n++)
	    {
	    	if( ( neurons[n].getCategory().equals( ReMoto.MN ) && !cdNeuron.equals( ReMoto.ALL_MN ) ) ||
	    		( neurons[n].getCategory().equals( ReMoto.IN ) && !cdNeuron.equals( ReMoto.ALL_IN ) ) ||
	    		( !neurons[n].getCategory().equals( ReMoto.MN ) && !neurons[n].getCategory().equals( ReMoto.IN ) ) )
	    	{
		    	continue;
	    	}
			
			SpinalNeuron neu = (SpinalNeuron)neurons[n];
			
			String cd = neu.getCd();

			ElectroCalculation el = new ElectroCalculation();

			double gCoupling = neu.getGCoupling();
			double gLeakSoma = neu.getGLeakSoma();
			double gLeakDend = neu.getGLeakDend();
			double threshold = neu.getThreshold();
			double position = neu.getXPosition();

			double axonThreshold = 0;
			double latencyStimulusSpinal = 0;
			double stimulusSpinalDistance = 0;
			double axonVelocity = 0; 
			double rn = 0;
			double rheobase = 0;

			if( cdNeuron.equals( ReMoto.ALL_MN ) )
			{
				axonThreshold = ((Motoneuron)neu).getAxonThreshold();
				latencyStimulusSpinal = ((Motoneuron)neu).getLatencyStimulusSpinal();
				stimulusSpinalDistance = ((Motoneuron)neu).getNerve().getStimulusSpinalEntry();
				axonVelocity = (stimulusSpinalDistance/latencyStimulusSpinal) * 1000.0; 
				rn = el.calcRn(gCoupling, gLeakSoma, gLeakDend);
			}
			else
			{
				rn = 1 / gLeakSoma;
			}

			rheobase = threshold / rn;

			if( cd.length() < 8 )
	    		stream.write( (cd + "\t\t").getBytes() );
	    	else
	    		stream.write( (cd + "\t").getBytes() );
	    	
			Object[] objRheobase = { new Double(rheobase) };
			Object[] objThreshold = { new Double(threshold) };
			Object[] objRn = { new Double(rn) };
			Object[] objAxonVelocity = { new Double(axonVelocity) };
			Object[] objAxonThreshold = { new Double(axonThreshold) };
			Object[] objPosition = { new Double(position) };

			if( cdNeuron.equals( ReMoto.ALL_MN ) )
				stream.write( ( mf.format( objRheobase ) + "\t\t" + 
								mf.format( objThreshold ) + "\t\t" + 
								mf.format( objRn ) + "\t\t" + 
								mf.format( objAxonVelocity ) + "\t\t" + 
								mf.format( objAxonThreshold ) + "\t\t" + 
								mf.format( objPosition ) + "\t\t" + 
								"\n").getBytes() );
			else
				stream.write( ( mf.format( objRheobase ) + "\t\t" + 
								mf.format( objThreshold ) + "\t\t" + 
								mf.format( objRn ) + "\t\t" + 
								mf.format( objPosition ) + "\t\t" + 
								"\n").getBytes() );
	    }
	}

	
	private void displayPropertiesMotorUnits(OutputStream stream) throws IOException
	{
		mf = new MessageFormat("{0,number,#.##}", Locale.US);

		stream.write( ("Id\t\tPos. Y\t\tPos. Z\t\tAttenuation [%]\tWidening [%]\n\n").getBytes() );

		MotorUnit motorunits[] = muscle.getMotorunits();
		
		for(int n = 0; motorunits != null && n < motorunits.length; n++)
	    {
			MotorUnit mu = motorunits[n];
			
			String cd = mu.getCd();
			double posY = 0; 
			double posZ = 0;
			double attenuation = 0;
			double timeWidening = 0;
			
			posY = mu.getPosY(); 
			posZ = mu.getPosZ();
			attenuation = (1 - mu.getAttenuationToSkin()) * 100;
			timeWidening = (mu.getTimeWidening() - 1) * 100;
			
			Object[] objPosY = { new Double(posY) };
			Object[] objPosZ = { new Double(posZ) };
			Object[] objAttenuation = { new Double(attenuation) };
			Object[] objTimeWidening = { new Double(timeWidening) };
			
			if( cd.length() < 8 )
	    		stream.write( (cd + "\t\t").getBytes() );
	    	else
	    		stream.write( (cd + "\t").getBytes() );
	    	
    		stream.write( (	mf.format( objPosY ) + "\t\t" + 
							mf.format( objPosZ ) + "\t\t" + 
							mf.format( objAttenuation ) + "\t\t" + 
							mf.format( objTimeWidening ) + "\t\t" + 
							"\n").getBytes() );
	    }
	}

	
	private XYSeriesCollection processForce(OutputStream stream, String cdNeuron) throws IOException
	{
		// Create chart for muscle force
		
		XYSeries serie = new XYSeries("force - " + cdNeuron);
		
		int totSteps = (int)(conf.getTFin()/sample);
		
		
		if( cdNeuron.equals( ReMoto.ALL_MU ) )
		{
			
			
			for(int i = 0; i < totSteps; i++)
			{
				
				double t = sample * i;
				double force = muscle.instantMuscleForce(t);
				
				
				
	    		if( !xLimit(coord, t) ){
	    			continue;
	    		}
	    			
	    		
	    		if( !yLimit(coord, force) ){
	    			continue;
	    		}
	    		
	    		if( result.getOpt().equals( ReMoto.chart_img ) || result.getOpt().equals( ReMoto.chart_img_new ) )
				{
					serie.add( t, force );
				}
				else if( result.getOpt().equals( ReMoto.file ) )
				{
					
					Object[] objT = { new Double(t) };
					Object[] objF = { new Double(force) };

					byte[] out = (mf.format( objT ) + "\t" + mf.format( objF ) + "\n").getBytes();

					stream.write( out );
				}
				else
				{
					Point point = new Point();
					
					point.setX( t );
					point.setY( force );
					
					output.add( point );
				}
	    		
			}
		}
		else
		{
			
			for(int i = 0; i < totSteps; i++)
			{
				double t = sample * i;
				double force = muscle.instantMotorUnitForce(cdNeuron, t);
				
				
				
	    		if( !xLimit(coord, t) ){
	    			continue;
	    		}
	    			
				
	    		if( !yLimit(coord, force) ){
	    			continue;
	    		}
	    			
	
	    		//force = yLimit(coord, force);
	    		
	    		if( result.getOpt().equals( ReMoto.chart_img ) || result.getOpt().equals( ReMoto.chart_img_new ) )
				{
					serie.add( t, force );
				}
				else
				{
					Object[] objT = { new Double(t) };
					Object[] objF = { new Double(force) };
					stream.write( (mf.format( objT ) + "\t" + mf.format( objF ) + "\n").getBytes() );
				}
			}
		}
		
		//System.out.println("RESULTDISPLAY-serie.getMaxX(): " + serie.getMaxX());
		XYSeriesCollection dataset = new XYSeriesCollection( serie );
		
		return dataset;
	}

	
	private XYSeriesCollection processEMG(OutputStream stream, String cdNeuron) throws IOException
	{
		// Create chart for muscle EMG
		XYSeries serie = new XYSeries("EMG - " + cdNeuron);

		int totSteps = (int)(conf.getTFin()/sample);
		double[] x = new double[totSteps];
		
		double meanNoise = 0;
		
		if( cdNeuron.equals( ReMoto.ALL_MU ) )
		{
			for(int i = 0; i < totSteps; i++)
			{
				x[i] = muscle.instantMuscleEMG(sample * i);
				meanNoise += Math.abs(x[i]);
			}
		}
		else
		{
	    	for(int i = 0; i < totSteps; i++)
	    	{
				x[i] = muscle.instantMotorUnitEMG(cdNeuron, sample * i);
				meanNoise += Math.abs(x[i]);
	    	}
		}
			
		if( result.isWithEMGnoise() )
			meanNoise /= totSteps;
		else
			meanNoise = 0;
		
		meanNoise *= conf.getMiscellaneous( ReMoto.noiseEMG );
		
		if( result.getFilter().equals( ReMoto.ThirdThird ) )
		{
			ButterworthBilinear butter = new ButterworthBilinear();
			x = butter.bandPass(x, result.getFcLow(), result.getFcHigh(), sample * 1e-3);
	
	    	for(int i = 0; i < x.length; i++ )
	    	{
	    		processEMG(coord, result, serie, stream, x[i] + meanNoise * Math.random(), i * sample);
	    	}        	
		}
		else if( result.getFilter().equals( ReMoto.FirstSecond ) )
		{
			ButterworthImpulseInvariance butter = new ButterworthImpulseInvariance(x, result.getFcLow(), result.getFcHigh(), sample * 1e-3);
	
			for(int i = 0; i < x.length; i++)
	    	{
	    		double out = butter.bandPass( x[i] + meanNoise * Math.random() );
	
	    		processEMG(coord, result, serie, stream, out, i * sample);
	    	}        	
		}
		else // No filtering
		{
	    	for(int i = 0; i < x.length; i++ )
	    	{
	    		processEMG(coord, result, serie, stream, x[i] + meanNoise * Math.random(), i * sample);
	    	}        	
		}
		
		XYSeriesCollection dataset = new XYSeriesCollection( serie );
		
		return dataset;
	}

	
	private XYSeriesCollection processSpikes(OutputStream stream, String cdNeuron) throws IOException
	{
		// Create chart for spike train
		XYSeries serie = new XYSeries( "spikes - " + cdNeuron );
		
		for(int n = 0; neurons != null && n < neurons.length; n++)
	    {
	    	String cd = neurons[n].getCd();
	    	
	    	// Plot spikes for the selected neuron 
	    	if( !cdNeuron.equals( ReMoto.ALL_MN_soma ) &&
		    	!cdNeuron.equals( ReMoto.ALL_MN_end_plate ) &&
		    	!cdNeuron.equals( ReMoto.ALL_Ia_stimulus_point ) && 
		    	!cdNeuron.equals( ReMoto.ALL_Ia_terminal ) && 
		    	!cdNeuron.equals( ReMoto.ALL_Ib_stimulus_point ) && 
		    	!cdNeuron.equals( ReMoto.ALL_Ib_terminal ) && 
	    		!cdNeuron.equals( ReMoto.ALL_CM_ext ) && 
	    		!cdNeuron.equals( ReMoto.ALL_CM_flex ) && 
	    		!cdNeuron.equals( ReMoto.ALL_RBE_ext ) && 
	    		!cdNeuron.equals( ReMoto.ALL_RBE_flex ) && 
	    		!cdNeuron.equals( ReMoto.ALL_RBI_ext ) && 
	    		!cdNeuron.equals( ReMoto.ALL_RBI_flex ) && 
		    	!cdNeuron.equals( ReMoto.ALL_RC ) && 
		    	!cdNeuron.equals( ReMoto.ALL_IaIn ) && 
		    	!cdNeuron.equals( ReMoto.ALL_IbIn ) && 
	    		!cdNeuron.equals( cd ) )
	    	{
	    		continue;
	    	}
	    	
	    	// If it was selected all MNs or NT, plot only MNs or NTs  
	    	if( ( cdNeuron.equals( ReMoto.ALL_MN_soma ) && !neurons[n].getCategory().equals( ReMoto.MN ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_MN_end_plate ) && !neurons[n].getCategory().equals( ReMoto.MN ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_Ia_stimulus_point ) && !neurons[n].getType().equals( ReMoto.Ia ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_Ia_terminal ) && !neurons[n].getType().equals( ReMoto.Ia ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_Ib_stimulus_point ) && !neurons[n].getType().equals( ReMoto.Ib ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_Ib_terminal ) && !neurons[n].getType().equals( ReMoto.Ib ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_CM_ext ) && !neurons[n].getType().equals( ReMoto.CM_ext ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_CM_flex ) && !neurons[n].getType().equals( ReMoto.CM_flex ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_RBE_ext ) && !neurons[n].getType().equals( ReMoto.RBE_ext ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_RBE_flex ) && !neurons[n].getType().equals( ReMoto.RBE_flex ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_RBI_ext ) && !neurons[n].getType().equals( ReMoto.RBI_ext ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_RBI_flex ) && !neurons[n].getType().equals( ReMoto.RBI_flex ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_RC ) && !neurons[n].getType().equals( ReMoto.RC ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_IaIn ) && !neurons[n].getType().equals( ReMoto.IaIn ) ) ||
	    		( cdNeuron.equals( ReMoto.ALL_IbIn ) && !neurons[n].getType().equals( ReMoto.IbIn ) ) )
	    		continue;
	    	

	    	if( result.getTask().equals( ReMoto.spikes ) && cdNeuron.equals("") )
	    		stream.write( (cd + "\n").getBytes() );
	    	
			List spikes = null;

    		if( cdNeuron.equals( ReMoto.ALL_MN_soma ) ||
    			neurons[n].getCategory().equals( ReMoto.IN ) )
    		{
    			spikes = ((SpinalNeuron)neurons[n]).getSomaSpikeTrain();
    		}
    		else if( cdNeuron.equals( ReMoto.ALL_Ia_stimulus_point ) || 
        			 cdNeuron.equals( ReMoto.ALL_Ib_stimulus_point ) )
    		{
    			spikes = ((SensoryFiber)neurons[n]).getAxonSpikeTrain();
    		}
    		else
				spikes = neurons[n].getTerminalSpikeTrain();

			for(int i = 0; i < spikes.size(); i++)
			{
	    		double t = ((Double)(spikes.get(i))).doubleValue();
	    		
	    		int index = neurons[n].getIndex();
	    		
	    		if( !xLimit(coord, t) )
	    			continue;
	    		
	    		if( !yLimit(coord, index) )
	    			continue;
	
	    		if( result.getOpt().equals( ReMoto.chart_img ) || result.getOpt().equals( ReMoto.chart_img_new ) )
				{
			        serie.add( new Double(t), new Integer(index) );
				}
				else if( result.getOpt().equals( ReMoto.file ) )
				{
					Object[] objIndex = { new Double(index) };
					Object[] objTime = { new Double(t) };
					stream.write( ( mf.format( objTime ) + "\t" + mf.format( objIndex ) + "\n").getBytes() );
				}
				else
				{
					Point point = new Point();
					
					point.setX( t );
					point.setY( index );
					
					output.add( point );
				}
			}
	    }
		
		XYSeriesCollection dataset = new XYSeriesCollection( serie );
		
		return dataset;
	}

	
	private XYSeriesCollection processFiring(OutputStream stream, String cdNeuron) throws IOException
	{
		// Create chart for spike train
		XYSeries serie = new XYSeries( "spikes - " + cdNeuron );
		
		for(int n = 0; neurons != null && n < neurons.length; n++)
	    {
	    	String cd = neurons[n].getCd();
	    	
	    	// Plot spikes for the selected neuron 
	    	if( !cdNeuron.equals( ReMoto.ALL_MN ) && 
	    		!cdNeuron.equals( ReMoto.ALL_CM_ext ) && 
	    		!cdNeuron.equals( ReMoto.ALL_CM_flex ) && 
	    		!cdNeuron.equals( ReMoto.ALL_RBE_ext ) && 
	    		!cdNeuron.equals( ReMoto.ALL_RBE_flex ) && 
	    		!cdNeuron.equals( ReMoto.ALL_RBI_ext ) && 
	    		!cdNeuron.equals( ReMoto.ALL_RBI_flex ) && 
	    		!cdNeuron.equals( cd ) )
	    	{
	    		continue;
	    	}
	    	
	    	// If it was selected all MNs or NT, plot only MNs or NTs  
	    	if( ( cdNeuron.equals( ReMoto.ALL_MN ) && !neurons[n].getCategory().equals( ReMoto.MN ) ) || 
        		( cdNeuron.equals( ReMoto.ALL_CM_ext ) && !neurons[n].getType().equals( ReMoto.CM_ext ) ) ||
        		( cdNeuron.equals( ReMoto.ALL_CM_flex ) && !neurons[n].getType().equals( ReMoto.CM_flex ) ) ||
        		( cdNeuron.equals( ReMoto.ALL_RBE_ext ) && !neurons[n].getType().equals( ReMoto.RBE_ext ) ) ||
        		( cdNeuron.equals( ReMoto.ALL_RBE_flex ) && !neurons[n].getType().equals( ReMoto.RBE_flex ) ) ||
        		( cdNeuron.equals( ReMoto.ALL_RBI_ext ) && !neurons[n].getType().equals( ReMoto.RBI_ext ) ) ||
        		( cdNeuron.equals( ReMoto.ALL_RBI_flex ) && !neurons[n].getType().equals( ReMoto.RBI_flex ) ) )
	    	{
	    		continue;
	    	}
	    	
	    	if( result.getTask().equals( ReMoto.spikes ) && cdNeuron.equals("") )
	    		stream.write( (cd + "\n").getBytes() );
	    	
			List spikes = neurons[n].getTerminalSpikeTrain();
			
			double tLastSpike = 0;
			
			if( spikes.size() > 0 )
				tLastSpike = ((Double)(spikes.get(0))).doubleValue();
			
			double firingRate = 0;

    		for(int i = 1; i < spikes.size(); i++)
			{
	    		double tSpike = ((Double)(spikes.get(i))).doubleValue();
	    		int index = neurons[n].getIndex();
	    		
	    		if( !xLimit(coord, tSpike) )
	    			continue;
	    		
	    		if( !yLimit(coord, index) )
	    			continue;
	    		
	    		firingRate = 1000.0 / (tSpike - tLastSpike);
	    		
	    		if( result.getOpt().equals( ReMoto.chart_img ) || result.getOpt().equals( ReMoto.chart_img_new ) )
				{
			        serie.add( new Double(tSpike), new Double(firingRate) );
				}
				else
				{
					Object[] objTime = { new Double(tSpike) };
					Object[] objRate = { new Double(firingRate) };
					Object[] objIndex = { new Integer(index) };
					
					stream.write( ( mf.format( objIndex ) + "\t" + mf.format( objRate ) + "\t" + mf.format( objTime ) + "\n" ).getBytes() );
				}
	    		
	    		tLastSpike = tSpike;
			}
	    }
		
		XYSeriesCollection dataset = new XYSeriesCollection( serie );
		
		return dataset;
	}

    
    private void processEMG(Coordenate coord, ResultVO result, XYSeries serie, OutputStream stream, double in, double t)
	{
		try
		{
			if( !xLimit(coord, t) )
				return;
			
			if( !yLimit(coord, in) )
				return;
		
    		if( result.getOpt().equals( ReMoto.chart_img ) || result.getOpt().equals( ReMoto.chart_img_new ) )
			{
				serie.add( t, in );
			}
			else if( result.getOpt().equals( ReMoto.file ) )
			{
				Object[] objT = { new Double(t) };
				Object[] objE = { new Double(in) };
				byte[] out = (mf.format( objT ) + "\t" + mf.format( objE ) + "\n").getBytes();
				
				stream.write( out );
			}
			else
			{
				Point point = new Point();
				
				point.setX( t );
				point.setY( in );
				
				output.add( point );
			}
		}
		catch (IOException e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	
	private void processHistogram(ResultVO result, DefaultCategoryDataset dataset, OutputStream stream, int spikes, String label)
	{
		try
		{
    		if( result.getOpt().equals( ReMoto.chart_img ) || result.getOpt().equals( ReMoto.chart_img_new ) )
			{
				dataset.addValue(spikes, label, "");
			}
			else
			{
				Object[] objS = { new Integer(spikes) };
				stream.write( ( label + "\t" + mf.format( objS ) + "\n").getBytes() );
			}
		}
		catch (IOException e)
		{
			System.out.println(e.getMessage());
		}
	}


	public List generateSummary(Simulation sim)
    {
		List ret = new ArrayList();
		Neuron neuronsNucleus[][] = sim.getNeurons();	
		int numSteadyState = 4;

		try
		{
			for(int x = 0; neuronsNucleus != null && x < neuronsNucleus.length; x++)
            {
				Neuron neurons[] = neuronsNucleus[x];	

				for(int n = 0; neurons != null && n < neurons.length; n++)
	            {
	            	String nucleus = neurons[n].getCdNucleus();
	            	String type = neurons[n].getType();
	            	String cd = neurons[n].getCd();
					int index = neurons[n].getIndex();
					double rate1I = 0;
					double rateSS = 0; 
					
					List listSpikes = neurons[n].getTerminalSpikeTrain();
					
					int numSpikes = listSpikes.size();

					if( numSpikes > 1 )
					{
						double tSpike0 = ((Double)(listSpikes.get(0))).doubleValue();
						double tSpike1 = ((Double)(listSpikes.get(1))).doubleValue();

						rate1I = 1000.0 / ( tSpike1 - tSpike0 );
					}
					
					if( numSpikes > numSteadyState )
					{
						double tSpikeSS =   ((Double)(listSpikes.get( numSteadyState - 1 ))).doubleValue();
						double tSpikeLast = ((Double)(listSpikes.get( numSpikes - 1 ))).doubleValue();

						rateSS = 1000.0 / ( (tSpikeLast - tSpikeSS) / (numSpikes - numSteadyState) ); 
					}

					double[] firingRates = new double[numSteadyState]; 

					for(int i = 0; i < firingRates.length; i++)
					{
						if( numSpikes > i+1 )
						{
							firingRates[i] = 1000/((((Double)(listSpikes.get(i+1))).doubleValue() -
							    	  				((Double)(listSpikes.get(i))  ).doubleValue() ) );
						}
						else
						{
							firingRates[i] = 0;				
						}
					}
					
					double gMaxExc = 0; 
					double gMaxInh = 0;
					double threshold = 0;
					double inputResistance = 0;
					int numberOfSpikesExc = 0;
					int numberOfSpikesInh = 0;

					if( neurons[n].getCategory().equals( ReMoto.IN ) || neurons[n].getCategory().equals( ReMoto.MN ) )
					{
						gMaxExc = ((SpinalNeuron)neurons[n]).getDendExcitSynapses().getGMaxTot();
						gMaxInh = ((SpinalNeuron)neurons[n]).getDendInhibSynapses().getGMaxTot();
						numberOfSpikesExc = ((SpinalNeuron)neurons[n]).getDendExcitSynapses().getNumberOfSpikesReceived();
						numberOfSpikesInh = ((SpinalNeuron)neurons[n]).getDendInhibSynapses().getNumberOfSpikesReceived();
						threshold = ((SpinalNeuron)neurons[n]).getThreshold();
						inputResistance = ((SpinalNeuron)neurons[n]).getRn();
					}

					Summary summ = new Summary( nucleus, 
												type, 
												cd, 
												index, 
												numSpikes, 
												rate1I, 
												rateSS, 
												firingRates, 
												gMaxExc, 
												gMaxInh, 
												numberOfSpikesExc, 
												numberOfSpikesInh, 
												threshold, 
												inputResistance);
					
					ret.add( summ );
	            }
            }
		}
		catch( Exception e )
		{
    		System.out.println(e.getMessage());
		}
		
		return ret;
    }

	
	private boolean xLimit(Coordenate coord, double x)
	{
		if( coord.getXini() < 0.1 && coord.getXfin() < 0.1 &&
			coord.getYini() < 0.1 && coord.getYfin() < 0.1	)
			return true;
			
		if( x < coord.getXini() )
			return false;
		
		if( x > coord.getXfin() )
			return false;

		return true;
	}


	private boolean yLimit(Coordenate coord, double y)
	{
		if( coord.getXini() < 0.1 && coord.getXfin() < 0.1 &&
			coord.getYini() < 0.1 && coord.getYfin() < 0.1	)
			return true;
		
		if( y < coord.getYini() )
			return false;
		
		if( y > coord.getYfin() )
			return false;

		return true;
	}

	
}
