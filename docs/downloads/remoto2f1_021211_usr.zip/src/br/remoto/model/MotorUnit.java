
package br.remoto.model;

import java.io.Serializable;
import java.util.ArrayList;

import br.remoto.model.Conductance.AlphaFunction;
import br.remoto.model.Neuron.Motoneuron;
import br.remoto.model.Neuron.Miscellaneous;


public class MotorUnit implements Serializable
{
	private static final long serialVersionUID = 1L;

	protected ArrayList endPlateSpikeTrain;
	protected AlphaFunction twitchFunction;

	protected double posY;
	protected double posZ;
	protected double attenuationToSkin;
	protected double timeWidening;

	protected double ampEMG;
	protected double lambdaEMG;
	
	protected String cd;
	protected String type;
	protected String cdNucleus;
	protected int index;
	protected int indexSpike;
	protected int iteration;
	protected double tSpike;
	protected double tPreviousSpike;
	
	protected boolean emgAttenuation;
	protected int hrType;
	
	protected Miscellaneous miscellaneous;

	public static final int EMG = 1;
	public static final int TWITCH = 2;

	
	public MotorUnit( Motoneuron mn )
	{
		this.endPlateSpikeTrain = mn.getTerminalSpikeTrain();
		this.index = mn.getIndex();
		this.type = mn.getType();
		this.cdNucleus = mn.getCdNucleus();
		this.cd = mn.getCd();
		this.miscellaneous = mn.getMiscellaneous();
		this.twitchFunction = new AlphaFunction(type, mn.getCdNucleus(), mn.getCdNucleus());
		
		// Pick one MUAP shape in a random way: HR1 or HR2
		// double pick = Math.random();
		// if( pick < 0.5 )
		// rcisi@13jun2009
		if( index%2 == 0 )
			hrType = 1;
		else
			hrType = 2;

		// Fiber data published in Hultborn et al. (1988). Acta Physiol Scand, 134: 363-374 
		// S: 0.4 - 5.0		- adotado:  0.4 - 5.0
		// FR: 6.0 - 37.1	- adotado:  6.0 - 30.0
		// FF: 15.0 - 64.4	- adotado: 15.0 - 60.0
		//
		// Burke (1980) Trends Neurosci 3: 255-258 in Uchiyama (2003a)
		// Fmax = 8 - 10 kg
		// Fmax = 70 * 5 + 60 * 28 + 140 * 60 = 10430 g
		// MNs quantity from Kernel (1977) apud Uchiyama (2003b)
	}

	
	public void reset( double sample, boolean emgAttenuation )
	{
		this.emgAttenuation = emgAttenuation;

		miscellaneous.setStep( sample );
		
		twitchFunction.reset( miscellaneous );
		indexSpike = 0;
		iteration = 0;
		
		if( getNumberOfSpikesAtEndPlate() > 0 )
			tSpike = getEndPlateSpike(0);
		else
			tSpike = ReMoto.T_MAX;
	}
	
	
	public double getSignal(double t, int output)
	{
		double out = 0;

		if( getNumberOfSpikesAtEndPlate() == 0 )
			return 0;

		if( t > tSpike )
		{
			indexSpike++;
			twitchFunction.start(iteration);
			
			if( getNumberOfSpikesAtEndPlate() > indexSpike )
			{
				tSpike = getEndPlateSpike(indexSpike);
			}
			else
			{
				tSpike = ReMoto.T_MAX;
				indexSpike = getNumberOfSpikesAtEndPlate() - 1;				
			}
		}

		// For Twitch signal
		if( output == TWITCH )
		{
			iteration++;

			out = twitchFunction.getValue(iteration);
		}
		// For EMG signal
		else if( output == EMG )
		{
			double timeCte = lambdaEMG;
			
			if( emgAttenuation == true )
			{
				timeCte *= timeWidening;
			}
			
			for(int n = indexSpike; n >= 0; n--)
			{
				tPreviousSpike = getEndPlateSpike(n);
				
				if( tPreviousSpike > t )
					continue;
	
				double value = 0;

				// For complete EMG graphic
				// According to Zhou et al. J. Neuroph.
				// Matlab: -exp(-(0.75*t).^2/2).*((0.75*t).^2-1)
				// double arg = Math.pow( 0.75*(t - tSpike - durEMG/2), 2);
				// out += ampEMG * -Math.exp(-arg/2) * (arg - 1);
				// hrA - hrB indica a amplificacao diferencial de 2 eletrodos

				// Matlab:	hr2 = k2 .* (1 - 2 * (t - 3*ld).^2/ld^2) .* exp(-(t - 3*ld).^2/ld^2);
				//			hr22 = k2 .* (1 - 2 * (tt - 3*ld).^2/ld^2) .* exp(-(tt - 3*ld).^2/ld^2);
				//			plot(t, (hr2 - hr22) .* (-t./10 + 0.5));
				
				double tA = t - tPreviousSpike - 3 * timeCte;
				
				// Break when signal reaches its resting value
				if( tA > 6 * timeCte )
					break;
				
				double term = Math.pow(tA/timeCte, 2);
				
				// Pick one MUAP shape in a random way
				if( hrType == 1 )
					value = 1.165 * tA * Math.exp(-term);		// shape HR1
				else
					value = 0.69 * ( 1 - 2 * term ) * Math.exp(-term);	// shape HR2
				
				//value = Math.exp(-term);					// shape HR0

				out += ampEMG * value;
			}
			
			if( emgAttenuation == true )
			{
				out *= attenuationToSkin;
			}
					
		}
		
		return out;
	}


	public void randomSpatialDistribution(double muscleThickness, double skinLayer, double tauAttenuation, double cteWidening)
	{
		// Place MU in a random position inside a muscle

		int cont = 0;
		double y = 2;
		double z = 2;
		
		// Pick a position inside the unitary circle
		while( Math.pow(y, 2) + Math.pow(z, 2) >= 1 )
		{
			y = 2 * (0.5 - Math.random());
			z = 2 * (0.5 - Math.random());
			
			cont++;
			
			// Give up, and pick a position in the z diameter
			if( cont > 10 )
			{
				z = 0;
				break;
			}
		}
		
		y = y * (muscleThickness/2) + (muscleThickness/2) + skinLayer;
		z *= (muscleThickness/2);

		/* Do not work!
		double y = 2 * (0.5 - Math.random());
		double maxZ = Math.sqrt( 1 - Math.pow(y, 2) );
		double z = 2 * (0.5 - Math.random()) * maxZ;
		
		y = y * (muscleThickness/2) + (muscleThickness/2) + skinLayer;
		z *= (muscleThickness/2);
		*/
		
		/* Do not work, also!
		double radius = (muscleThickness/2) * Math.random();
		double angle = 360 * Math.random();
		
		double y = radius * Math.sin( angle );
		double z = radius * Math.cos( angle );
		*/
		
		double distance = Math.sqrt( Math.pow( z, 2) + Math.pow( y, 2) );
		
		posY = y;
		posZ = z;

		// Fitted to Fuglevand et al. 1992 - Biological Cybernetics
		attenuationToSkin = Math.exp( -distance/tauAttenuation );

		// Fitted to Hermens et al. 1992 - IEEE EMBS 
		timeWidening = 1 + cteWidening * distance;
	}


	public void linearSpatialDistribution(double muscleThickness, double skinLayer, double tauAttenuation, double cteWidening, int muNumber, int muTotal)
	{
		// Place MU in a fixed position inside a muscle
		double y = (double)muNumber / (muTotal - 1);
		double z = 0;
		
		y = y * (muscleThickness - skinLayer) + skinLayer;
		
		double distance = y;
		
		posY = y;
		posZ = z;

		// Fitted to Fuglevand et al. 1992 - Biological Cybernetics
		attenuationToSkin = Math.exp( -distance/tauAttenuation );

		// Fitted to Hermens et al. 1992 - IEEE EMBS 
		timeWidening = 1 + cteWidening * distance;
	}

	
	public void presetSpatialDistribution(double y, double z, double muscleThickness, double skinLayer, double tauAttenuation, double cteWidening, int muNumber, int muTotal)
	{
		// Place MU in a preset position inside a muscle
		posY = y;
		posZ = z;

		double distance = Math.sqrt( Math.pow( posY, 2) + Math.pow( posZ, 2) );
		
		// Fitted to Fuglevand et al. 1992 - Biological Cybernetics
		attenuationToSkin = Math.exp( -distance/tauAttenuation );

		// Fitted to Hermens et al. 1992 - IEEE EMBS 
		timeWidening = 1 + cteWidening * distance;
	}

	
	private double getEndPlateSpike(int index) 
	{
		return ((Double)endPlateSpikeTrain.get(index)).doubleValue();
	}
	
	
	private int getNumberOfSpikesAtEndPlate() 
	{
		return endPlateSpikeTrain.size();
	}

	
	// General getters and setters 
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getAmpEMG() {
		return ampEMG;
	}
	public void setAmpEMG(double ampEMG) {
		this.ampEMG = ampEMG;
	}
	public double getLambdaEMG() {
		return lambdaEMG;
	}
	public void setLambdaEMG(double lambdaEMG) {
		this.lambdaEMG = lambdaEMG;
	}
	public String getCd() {
		return cd;
	}
	public void setCd(String id) {
		this.cd = id;
	}
	public String getCdNucleus() {
		return cdNucleus;
	}
	public void setCdNucleus(String cdNucleus) {
		this.cdNucleus = cdNucleus;
	}
	public AlphaFunction getTwitchFunction() {
		return twitchFunction;
	}
	public void setTwitchFunction(AlphaFunction twitchFunction) {
		this.twitchFunction = twitchFunction;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public double getPosZ() {
		return posZ;
	}
	public void setPosZ(double posX) {
		this.posZ = posX;
	}
	public double getPosY() {
		return posY;
	}
	public void setPosY(double posY) {
		this.posY = posY;
	}
	public double getAttenuationToSkin() {
		return attenuationToSkin;
	}
	public void setAttenuationToSkin(double distanceToSkin) {
		this.attenuationToSkin = distanceToSkin;
	}
	public double getTimeWidening() {
		return timeWidening;
	}
	public void setTimeWidening(double timeEnlargement) {
		this.timeWidening = timeEnlargement;
	}

}

