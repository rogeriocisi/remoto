/*
 * Created on 27/01/2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package br.remoto.model.Neuron;

import java.util.ArrayList;

import br.remoto.model.Nerve;
import br.remoto.model.ReMoto;
import br.remoto.model.vo.NeuronVO;


/**
 * @author RRCisi
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SensoryFiber extends Neuron
{
	private static final long serialVersionUID = 1L;

	protected double tAxonSpike;

	protected double nextSpike;
	protected int indexSpike;

	protected double axonThreshold;
	protected double latencyStimulusSpinal;

	protected ArrayList axonSpikeTrain = new ArrayList();

	protected Nerve nerve;


	
	public SensoryFiber()
	{
	}
	
	
	public SensoryFiber(NeuronVO neu, int index, Miscellaneous misc)
	{
		super(neu, index, misc);
		
		reset();
	}
	
	
	public void reset()
	{
		super.reset();
		
		if( axonSpikeTrain != null )
			axonSpikeTrain.clear();
		else
			axonSpikeTrain = new ArrayList();

		tAxonSpike = -ReMoto.T_MAX;

		nextSpike = -ReMoto.T_MAX;
		indexSpike = 0;
	}
		
	
	public void ensureCapacity(int size)
	{
		super.ensureCapacity(size);
		
		axonSpikeTrain.ensureCapacity(size);
	}
	

	public void atualize(double t) 
	{
		if( nerve == null || nerve.isActive() == false )
			return;
		
		try
		{
			// Propagate spike to all post-synaptic neurons
			if( indexSpike < axonSpikeTrain.size() )
			{
				nextSpike = ((Double)axonSpikeTrain.get(indexSpike)).doubleValue() + latencyStimulusSpinal;
	
				if( t > nextSpike )
				{
					propagateSpike(t);
					indexSpike++;
					
					terminalSpikeTrain.add( new Double(t) );
				}
			}
	
			// If stimulus is greater than threshold and fiber is not in refractory period
			if( nerve.getIntensity() > axonThreshold && t - tAxonSpike > miscellaneous.getAfAxonRefractoryPeriod() )
			{
				tAxonSpike = t;
				
				axonSpikeTrain.add( new Double(t) );
			}
		}
		catch (Exception e) 
		{
			System.out.println( "Error while atualizing AF: " + cd );
		}
	}

	
	public void setLatency(double axonVelocity, double stimulusSpinalDistance) 
	{
		if( axonVelocity < 0.01 )
			axonVelocity = 0.01;
		
		latencyStimulusSpinal = (stimulusSpinalDistance/axonVelocity) * 1000.0; 
	}


	public int getIndexSpike() {
		return indexSpike;
	}


	public void setIndexSpike(int indexSpike) {
		this.indexSpike = indexSpike;
	}


	public double getLatencyStimulusSpinal() {
		return latencyStimulusSpinal;
	}


	public void setLatencyStimulusSpinal(double latencyStimulusSpinal) {
		this.latencyStimulusSpinal = latencyStimulusSpinal;
	}


	public double getNextSpike() {
		return nextSpike;
	}


	public void setNextSpike(double nextSpike) {
		this.nextSpike = nextSpike;
	}


	public ArrayList getAxonSpikeTrain() {
		return axonSpikeTrain;
	}


	public void setAxonSpikeTrain(ArrayList axonSpikeTrain) {
		this.axonSpikeTrain = axonSpikeTrain;
	}


	public double getAxonThreshold() {
		return axonThreshold;
	}


	public void setAxonThreshold(double axonThreshold) {
		this.axonThreshold = axonThreshold;
	}


	public Nerve getNerve() {
		return nerve;
	}


	public void setNerve(Nerve nerve) {
		this.nerve = nerve;
	}

	
}
