
package br.remoto.servlet;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import br.remoto.model.Configuration;
import br.remoto.model.Current;
import br.remoto.model.MotorUnit;
import br.remoto.model.Muscle;
import br.remoto.model.ReMoto;
import br.remoto.model.ResultDisplay;
import br.remoto.model.Simulation;
import br.remoto.model.Neuron.Motoneuron;
import br.remoto.model.Neuron.NeuralTract;
import br.remoto.model.Neuron.Neuron;
import br.remoto.model.Neuron.SensoryFiber;
import br.remoto.model.Neuron.SpinalNeuron;
import br.remoto.model.vo.ResultVO;
import br.remoto.model.vo.Summary;
import br.remoto.spindle.Input;
import br.remoto.spindle.Spindle;
import br.remoto.util.BarPlot;
import br.remoto.util.ButterworthBilinear;
import br.remoto.util.ButterworthImpulseInvariance;
import br.remoto.util.Coordenate;
import br.remoto.util.ElectroCalculation;
import br.remoto.util.PlotCombined;
import br.remoto.util.PlotScatter;
import br.remoto.util.PlotXYLine;
import br.remoto.util.Point;
import br.remoto.util.Signal;

public class ProgressBarServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	
	ObjectOutputStream outputToApplet;
	ObjectInputStream inputFromApplet;
	
	protected Configuration conf;
	
	String cdSimulation;
	String status;
	
	int percentage=0;
	
    public ProgressBarServlet(){}
    
    public void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		try {
						
			inputFromApplet = new ObjectInputStream(request.getInputStream());
			cdSimulation = (String)inputFromApplet.readUTF();
			inputFromApplet.close();
			
			//System.out.println("cdSimulation: " + cdSimulation);
			
			if(cdSimulation!=null && !cdSimulation.equals("vazio")){
				Simulation sim = (Simulation)ReMoto.simulations.get( cdSimulation );
				
				Configuration conf = sim.getConfiguration();
				
				if(sim.getStatus() == Simulation.SIM_RUNNING){
						percentage = sim.getPercentageInt();
				}
				
				outputToApplet = new ObjectOutputStream(response.getOutputStream());

				outputToApplet.writeInt(percentage);
				outputToApplet.writeInt(sim.getStatus());
				outputToApplet.flush();
				
				outputToApplet.close();
			}
			
		}
		catch (Exception e) {
			System.err.println(e.toString());
		}
    }
   
}
