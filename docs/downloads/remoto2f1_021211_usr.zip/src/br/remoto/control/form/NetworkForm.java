/*
 * Created on 01/10/2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package br.remoto.control.form;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import br.remoto.model.vo.NeuronVO;


/**
 * @author rrcisi
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class NetworkForm extends ActionForm
{
	private static final long serialVersionUID = 1L;

	private List neurons;
	private String cdJoint;
	private boolean activeAnkleExtensorMNs;
	private boolean activeAnkleExtensorINs;
	private boolean activeAnkleExtensorSAs;
	private boolean activeAnkleFlexorMNs;
	private boolean activeAnkleFlexorINs;
	private boolean activeAnkleFlexorSAs;
	
    public NetworkForm()
	{
		super();
	
		neurons = new ArrayList();
	}

	public void reset(ActionMapping map, HttpServletRequest req)
	{
		super.reset(map, req);
		
		neurons = new ArrayList();
	}
	
	public ActionErrors validate(ActionMapping map, HttpServletRequest req)
	{
		return super.validate(map, req);
	}
    
    public NeuronVO getNucleus(int index)
    {
       while(neurons.size() <= index)
       {
    	   neurons.add(new NeuronVO());
       }

       return (NeuronVO) neurons.get(index);
	}

	public List getNeurons() {
		return neurons;
	}

	public void setNeurons(List neurons) {
		this.neurons = neurons;
	}

	public String getCdJoint() {
		return cdJoint;
	}

	public void setCdJoint(String cdJoint) {
		this.cdJoint = cdJoint;
	}

	public boolean isActiveAnkleExtensorMNs() {
		return activeAnkleExtensorMNs;
	}

	public void setActiveAnkleExtensorMNs(boolean activeAnkleExtensorMNs) {
		this.activeAnkleExtensorMNs = activeAnkleExtensorMNs;
	}

	public boolean isActiveAnkleExtensorINs() {
		return activeAnkleExtensorINs;
	}

	public void setActiveAnkleExtensorINs(boolean activeAnkleExtensorINs) {
		this.activeAnkleExtensorINs = activeAnkleExtensorINs;
	}

	public boolean isActiveAnkleExtensorSAs() {
		return activeAnkleExtensorSAs;
	}

	public void setActiveAnkleExtensorSAs(boolean activeAnkleExtensorSAs) {
		this.activeAnkleExtensorSAs = activeAnkleExtensorSAs;
	}

	public boolean isActiveAnkleFlexorMNs() {
		return activeAnkleFlexorMNs;
	}

	public void setActiveAnkleFlexorMNs(boolean activeAnkleFlexorMNs) {
		this.activeAnkleFlexorMNs = activeAnkleFlexorMNs;
	}

	public boolean isActiveAnkleFlexorINs() {
		return activeAnkleFlexorINs;
	}

	public void setActiveAnkleFlexorINs(boolean activeAnkleFlexorINs) {
		this.activeAnkleFlexorINs = activeAnkleFlexorINs;
	}

	public boolean isActiveAnkleFlexorSAs() {
		return activeAnkleFlexorSAs;
	}

	public void setActiveAnkleFlexorSAs(boolean activeAnkleFlexorSAs) {
		this.activeAnkleFlexorSAs = activeAnkleFlexorSAs;
	}

	

}
