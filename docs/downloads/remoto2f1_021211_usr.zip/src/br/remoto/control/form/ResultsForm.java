/*
 * Created on 01/10/2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package br.remoto.control.form;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;


/**
 * @author rrcisi
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class ResultsForm extends ActionForm
{
	private static final long serialVersionUID = 1L;

	private String task;
	private String cdEMG;
	private String cdForce;
	private String cdSignal;
	private String cdConductance;
	private String cdSpikes;
	private String cdFiringRate;
	private String cdHistogram;
	private String cdProperties;
	private String whichSignal;
	
	private String cdSimulation = "vazio";
	
	private double xini;
	private double xfin;
	private double yini;
	private double yfin;
	private double fcLow;
	private double fcHigh;
	private double sample;
	private int numberOfBins;
	
	private boolean withEMGnoise;
	private boolean withEMGattenuation;
	
	private String filter;
	private String opt;
	
	private List elementsEMG 			= new ArrayList();
	private List elementsForce 			= new ArrayList();
	private List elementsSignal 		= new ArrayList();
	private List elementsTracts 		= new ArrayList();
	private List elementsConductance 	= new ArrayList();
	private List elementsSpikes 		= new ArrayList();
	private List elementsFiringRate 	= new ArrayList();
	private List elementsHistogram 		= new ArrayList();
	private List elementsProperties 	= new ArrayList();
	private List listSamples 			= new ArrayList();

	private List nuclei;
	private String cdNucleus;
	
	
    public ResultsForm()
	{
		super();
	}

	public void reset(ActionMapping map, HttpServletRequest req)
	{
		super.reset(map, req);
	}
	
	public ActionErrors validate(ActionMapping map, HttpServletRequest req)
	{
		return super.validate(map, req);
	}

	public String getTask() {
		return task;
	}

	public void setTask(String task) {
		this.task = task;
	}

	public double getXfin() {
		return xfin;
	}

	public void setXfin(double xfin) {
		this.xfin = xfin;
	}

	public double getXini() {
		return xini;
	}

	public void setXini(double xini) {
		this.xini = xini;
	}

	public double getYfin() {
		return yfin;
	}

	public void setYfin(double yfin) {
		this.yfin = yfin;
	}

	public double getYini() {
		return yini;
	}

	public void setYini(double yini) {
		this.yini = yini;
	}

	public String getCdEMG() {
		return cdEMG;
	}

	public void setCdEMG(String cdEMG) {
		this.cdEMG = cdEMG;
	}

	public String getCdForce() {
		return cdForce;
	}

	public void setCdForce(String cdForce) {
		this.cdForce = cdForce;
	}

	public String getCdSpikes() {
		return cdSpikes;
	}

	public void setCdSpikes(String cdSpikes) {
		this.cdSpikes = cdSpikes;
	}

	public String getCdSignal() {
		return cdSignal;
	}

	public void setCdSignal(String cdVm) {
		this.cdSignal = cdVm;
	}

	public List getElementsEMG() {
		return elementsEMG;
	}

	public void setElementsEMG(List elementsEMG) {
		this.elementsEMG = elementsEMG;
	}

	public List getElementsForce() {
		return elementsForce;
	}

	public void setElementsForce(List elementsForce) {
		this.elementsForce = elementsForce;
	}

	public List getElementsSpikes() {
		return elementsSpikes;
	}

	public void setElementsSpikes(List elementsSpikes) {
		this.elementsSpikes = elementsSpikes;
	}

	public List getElementsSignal() {
		return elementsSignal;
	}

	public void setElementsSignal(List elementsVm) {
		this.elementsSignal = elementsVm;
	}

	public double getSample() {
		return sample;
	}

	public void setSample(double sample) {
		this.sample = sample;
	}

	public List getListSamples() {
		return listSamples;
	}

	public void setListSamples(List listSamples) {
		this.listSamples = listSamples;
	}

	public double getFcHigh() {
		return fcHigh;
	}

	public void setFcHigh(double fcHigh) {
		this.fcHigh = fcHigh;
	}

	public double getFcLow() {
		return fcLow;
	}

	public void setFcLow(double fcLow) {
		this.fcLow = fcLow;
	}

	public String getFilter() {
		return filter;
	}

	public void setFilter(String filter) {
		this.filter = filter;
	}

	public String getCdNucleus() {
		return cdNucleus;
	}

	public void setCdNucleus(String cdNucleus) {
		this.cdNucleus = cdNucleus;
	}

	public List getNuclei() {
		return nuclei;
	}

	public void setNuclei(List nuclei) {
		this.nuclei = nuclei;
	}

	public String getWhichSignal() {
		return whichSignal;
	}

	public void setWhichSignal(String whichVm) {
		this.whichSignal = whichVm;
	}

	public List getElementsConductance() {
		return elementsConductance;
	}

	public void setElementsConductance(List elementsConductance) {
		this.elementsConductance = elementsConductance;
	}

	public String getCdConductance() {
		return cdConductance;
	}

	public void setCdConductance(String cdConductance) {
		this.cdConductance = cdConductance;
	}

	public String getCdHistogram() {
		return cdHistogram;
	}

	public void setCdHistogram(String cdHistogram) {
		this.cdHistogram = cdHistogram;
	}

	public int getNumberOfBins() {
		return numberOfBins;
	}

	public void setNumberOfBins(int numberOfBins) {
		this.numberOfBins = numberOfBins;
	}

	public boolean isWithEMGnoise() {
		return withEMGnoise;
	}

	public void setWithEMGnoise(boolean withEMGnoise) {
		this.withEMGnoise = withEMGnoise;
	}

	public String getOpt() {
		return opt;
	}

	public void setOpt(String opt) {
		this.opt = opt;
	}

	public String getCdFiringRate() {
		return cdFiringRate;
	}

	public void setCdFiringRate(String cdFiringRate) {
		this.cdFiringRate = cdFiringRate;
	}

	public List getElementsTracts() {
		return elementsTracts;
	}

	public void setElementsTracts(List elementsTracts) {
		this.elementsTracts = elementsTracts;
	}

	public List getElementsFiringRate() {
		return elementsFiringRate;
	}

	public void setElementsFiringRate(List elementsFiringRate) {
		this.elementsFiringRate = elementsFiringRate;
	}

	public List getElementsHistogram() {
		return elementsHistogram;
	}

	public void setElementsHistogram(List elementsHistogram) {
		this.elementsHistogram = elementsHistogram;
	}

	public String getCdProperties() {
		return cdProperties;
	}

	public void setCdProperties(String cdProperties) {
		this.cdProperties = cdProperties;
	}

	public List getElementsProperties() {
		return elementsProperties;
	}

	public void setElementsProperties(List elementsProperties) {
		this.elementsProperties = elementsProperties;
	}

	public boolean isWithEMGattenuation() {
		return withEMGattenuation;
	}

	public void setWithEMGattenuation(boolean withEMGattenuation) {
		this.withEMGattenuation = withEMGattenuation;
	}
	
	//testando
	
	public String getCdSimulation() {
		return cdSimulation;
	}

	public void setCdSimulation(String cdSimulation) {
		this.cdSimulation = cdSimulation;
	}

}
