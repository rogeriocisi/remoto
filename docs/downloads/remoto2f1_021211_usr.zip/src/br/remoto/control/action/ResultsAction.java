
package br.remoto.control.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import br.remoto.control.form.ResultsForm;
import br.remoto.model.Configuration;
import br.remoto.model.ReMoto;
import br.remoto.model.ResultDisplay;
import br.remoto.model.Simulation;
import br.remoto.model.Neuron.Interneuron;
import br.remoto.model.Neuron.Motoneuron;
import br.remoto.model.Neuron.NeuralTract;
import br.remoto.model.Neuron.SensoryFiber;
import br.remoto.model.vo.ConductanceVO;
import br.remoto.model.vo.ResultVO;
import br.remoto.util.Coordenate;


/**
 * @author rrcisi
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class ResultsAction extends MainAction
{
	/**
	 * Busca a lista de eventos de um determinado dia na base de dados.
	 * Se n�o houver eventos para a data especificada, retorna um formul�rio em branco.
	 */
	public ActionForward execute(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res)
	{
		ActionForward af = null;
		ResultsForm resultsForm = (ResultsForm) form;
		Configuration conf = getConfiguration(req);
		String opt = resultsForm.getOpt();
		String action = (String)req.getParameter("action");
		String task = resultsForm.getTask();
		
		
		// task is the type of data stored (i.e. spike times, firing rate..)
		// opt is the operation to be performed (i.e generate graphic, export data..)
		
		try
		{
			if( conf == null )
			{
				af = map.findForward( "noConfiguration" );
				req.setAttribute("msg", "No configuration set.");
				
				return af;
			}

			Simulation sim = getSimulation(req, conf.getId());
			
			if( sim == null || sim.getStatus() == Simulation.SIM_IDLE )
			{
				// Try to recover simulation, if it is stored in disk
				sim = recoverStoredSimulation( req, conf.getId() );

				if( sim == null || sim.getStatus() == Simulation.SIM_IDLE )
				{
					af = map.findForward( "noConfiguration" );
					req.setAttribute("msg", "You must perform a simulation in order to see results.");
					
					return af;
				}
			}
			
			req.getSession().setAttribute("start", sim.getStart());
			req.getSession().setAttribute("finish", sim.getFinish());
			req.getSession().setAttribute("duration",  String.valueOf( sim.getConfiguration().getTFin() ) );
			req.getSession().setAttribute("step",  String.valueOf( sim.getConfiguration().getStep() ) );
			
			if( "change".equals( action ) )
			{
				
				setFormProperties(resultsForm, sim, conf, req);
				setConfProperties(conf, resultsForm);
				req.getSession().setAttribute("task", task);
				req.getSession().setAttribute("opt", opt);
				
				af = map.findForward( "results" );
			}
			else if( ReMoto.file.equals( opt ) && task != null )
			{
				
				ResultDisplay results = new ResultDisplay(conf);
				
				setConfProperties(conf, resultsForm);
				req.getSession().setAttribute("task", task);
				
				res.setContentType("text/plain");

				// Do not store cache
				res.setHeader("Content-disposition", "inline; filename=result.txt");
				res.setHeader("Expires", "Mon, 26 Jul 1997 05:00:00 GMT");
				res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
				res.setHeader("Cache-Control", "post-check=0, pre-check=0");
				res.setHeader("Pragma", "no-cache");
				
				results.generateResults(sim, res.getOutputStream() );
				
				res.getOutputStream().flush();
				
				results = null;
				System.gc();
				
				return null;
			}
			else if( ReMoto.chart.equals( opt ) && task != null ) 
			{
				
				setConfProperties(conf, resultsForm);
				req.getSession().setAttribute("task", task);

				String cdSimulation = getCdSimulation(req, conf.getId());
				req.setAttribute( "cdSimulation", cdSimulation );
				req.getSession().setAttribute("opt", opt);
				

				// Chart will be drawn in ServletChartGenerator
				af = map.findForward( "chart" );
			}
			else if( ReMoto.chart_img.equals( opt ) && task != null ) 
			{
				
				setConfProperties(conf, resultsForm);
				req.getSession().setAttribute("task", task);

				String cdSimulation = getCdSimulation(req, conf.getId());
				req.setAttribute( "cdSimulation", cdSimulation );
				req.getSession().setAttribute("opt", opt);

				setFormProperties(resultsForm, sim, conf, req);
				
				af = map.findForward( "results" );
			}
			else if( ReMoto.chart_img_new.equals( opt ) && task != null ) 
			{
				task = (String)req.getSession().getAttribute( "task" );
				
				if( task == null || "".equals( task ) || ReMoto.force.equals( task ) )
					conf.getResult().setTask( ReMoto.force );
				
				//setFormProperties(resultsForm, sim, conf, req);
				
				setConfProperties(conf, resultsForm);
				req.getSession().setAttribute("task", task);
				
				String cdSimulation = getCdSimulation(req, conf.getId());
				req.setAttribute( "cdSimulation", cdSimulation );
				req.getSession().setAttribute("opt", opt);
				
				setFormProperties(resultsForm, sim, conf, req);
				
				af = map.findForward( "chart_img_new" );
			}
			else if( ReMoto.summary.equals( opt ) ) 
			{
				ResultDisplay results = new ResultDisplay(conf);
				List summ = results.generateSummary(sim);
				
				results = null;
				System.gc();
				
				req.setAttribute( "summ", summ );
				req.setAttribute( "duration", Double.toString( conf.getTFin() ) );
				
				
				af = map.findForward( "summary" );
			}
			else 
			{
				
				task = (String)req.getSession().getAttribute( "task" );
				
				if( task == null || "".equals( task ) || ReMoto.force.equals( task ) )
					conf.getResult().setTask( ReMoto.force );
				
				setFormProperties(resultsForm, sim, conf, req);
				
				af = map.findForward( "results" );
			}
		}
		catch (Exception e) 
		{
			System.out.println( e.getMessage() );
		}
		
		return af;
	}
	
	
	private void setConfProperties(Configuration conf, ResultsForm resultsForm)
	{
		ResultVO result = new ResultVO();
		Coordenate coord = new Coordenate(); 
		
		coord.setXini( resultsForm.getXini() );
		coord.setXfin( resultsForm.getXfin() );
		coord.setYini( resultsForm.getYini() );
		coord.setYfin( resultsForm.getYfin() );
		
		if( resultsForm.getXini() > 0 || resultsForm.getXfin() < ReMoto.T_MAX ||
			resultsForm.getYini() > -ReMoto.Y_MAX || resultsForm.getYfin() < ReMoto.Y_MAX )
		{
			coord.setActive( true );
		}

		result.setCoordenate( coord );
		result.setOpt( resultsForm.getOpt() );
		result.setCdNucleus( resultsForm.getCdNucleus() );
		result.setTask( resultsForm.getTask() );
		result.setCdSpikes( resultsForm.getCdSpikes() );
		result.setCdFiringRate( resultsForm.getCdFiringRate() );
		result.setCdHistogram( resultsForm.getCdHistogram() );
		result.setCdProperties( resultsForm.getCdProperties() );
		result.setCdEMG( resultsForm.getCdEMG() );
		result.setCdForce( resultsForm.getCdForce() );
		result.setCdSignal( resultsForm.getCdSignal() );
		result.setCdConductance( resultsForm.getCdConductance() );
		result.setWhichSignal( resultsForm.getWhichSignal() );
		result.setSample( resultsForm.getSample() );
		result.setFcLow( resultsForm.getFcLow() );
		result.setFcHigh( resultsForm.getFcHigh() );
		result.setFilter( resultsForm.getFilter() );
		result.setWithEMGnoise( resultsForm.isWithEMGnoise() );
		result.setWithEMGattenuation( resultsForm.isWithEMGattenuation() );
		
		
		if( resultsForm.getNumberOfBins() < 1 )
			resultsForm.setNumberOfBins( ReMoto.numberOfBins );

		result.setNumberOfBins( resultsForm.getNumberOfBins() );

		// Minimum frequency
		if( result.getFcLow() < 0.01 )
			result.setFcLow( 0.01 );
		
		conf.setResult( result );
	}
	
	
	private void setFormProperties(ResultsForm resultsForm, Simulation sim, Configuration conf, HttpServletRequest req)
	{
		List nuclei = conf.getNuclei( ReMoto.MNs );
		nuclei.addAll( conf.getNuclei( ReMoto.INs ) );
		nuclei.addAll( conf.getNuclei( ReMoto.DTs ) );
		
		String cdNucleus = resultsForm.getCdNucleus();
		
		// Set default value
		if( cdNucleus == null )
		{
			
			cdNucleus = conf.getCdNucleus();
			
		}
		else{
			
			conf.setCdNucleus(resultsForm.getCdNucleus());
			req.getSession().setAttribute("cdNucleus", cdNucleus);
		}
		

		if( cdNucleus.equals( ReMoto.DT ) )
		{
			NeuralTract allCM_ext = new NeuralTract();
			allCM_ext.setCd( ReMoto.ALL_CM_ext );
			
			NeuralTract allCM_flex = new NeuralTract();
			allCM_flex.setCd( ReMoto.ALL_CM_flex );
			
			NeuralTract allRBE_ext = new NeuralTract();
			allRBE_ext.setCd( ReMoto.ALL_RBE_ext );
			
			NeuralTract allRBE_flex = new NeuralTract();
			allRBE_flex.setCd( ReMoto.ALL_RBE_flex );
			
			NeuralTract allRBI_ext = new NeuralTract();
			allRBI_ext.setCd( ReMoto.ALL_RBI_ext );
			
			NeuralTract allRBI_flex = new NeuralTract();
			allRBI_flex.setCd( ReMoto.ALL_RBI_flex );
			
			NeuralTract cm_ext = new NeuralTract();
			cm_ext.setCd( ReMoto.CM_TR_ext );
			
			NeuralTract cm_flex = new NeuralTract();
			cm_flex.setCd( ReMoto.CM_TR_flex );
			
			NeuralTract rbe_ext = new NeuralTract();
			rbe_ext.setCd( ReMoto.RBE_TR_ext );
			
			NeuralTract rbe_flex = new NeuralTract();
			rbe_flex.setCd( ReMoto.RBE_TR_flex );
			
			NeuralTract rbi_ext = new NeuralTract();
			rbi_ext.setCd( ReMoto.RBI_TR_ext );
			
			NeuralTract rbi_flex = new NeuralTract();
			rbi_flex.setCd( ReMoto.RBI_TR_flex );
			
			resultsForm.getElementsSpikes().add(allCM_ext);
			resultsForm.getElementsSpikes().add(allCM_flex);
			resultsForm.getElementsSpikes().add(allRBE_ext);
			resultsForm.getElementsSpikes().add(allRBE_flex);
			resultsForm.getElementsSpikes().add(allRBI_ext);
			resultsForm.getElementsSpikes().add(allRBI_flex);
			
			resultsForm.getElementsFiringRate().add(allCM_ext);
			resultsForm.getElementsFiringRate().add(allCM_flex);
			resultsForm.getElementsFiringRate().add(allRBE_ext);
			resultsForm.getElementsFiringRate().add(allRBE_flex);
			resultsForm.getElementsFiringRate().add(allRBI_ext);
			resultsForm.getElementsFiringRate().add(allRBI_flex);

			resultsForm.getElementsHistogram().add(allCM_ext);
			resultsForm.getElementsHistogram().add(allCM_flex);
			resultsForm.getElementsHistogram().add(allRBE_ext);
			resultsForm.getElementsHistogram().add(allRBE_flex);
			resultsForm.getElementsHistogram().add(allRBI_ext);
			resultsForm.getElementsHistogram().add(allRBI_flex);

			resultsForm.getElementsTracts().add( cm_ext );
			resultsForm.getElementsTracts().add( cm_flex );
			resultsForm.getElementsTracts().add( rbe_ext );
			resultsForm.getElementsTracts().add( rbe_flex );
			resultsForm.getElementsTracts().add( rbi_ext );
			resultsForm.getElementsTracts().add( rbi_flex );
		}
		else if( cdNucleus.equals( ReMoto.SOL ) || cdNucleus.equals( ReMoto.MG ) || cdNucleus.equals( ReMoto.LG ) || cdNucleus.equals( ReMoto.TA ) )
		{
			// Set labels
			Motoneuron allMN = new Motoneuron();
			allMN.setCd( ReMoto.ALL_MN );

			Motoneuron allMNsoma = new Motoneuron();
			allMNsoma.setCd( ReMoto.ALL_MN_soma );

			Motoneuron allMNendPlate = new Motoneuron();
			allMNendPlate.setCd( ReMoto.ALL_MN_end_plate );

			Motoneuron allMN_S = new Motoneuron();
			allMN_S.setCd( ReMoto.ALL_MN_S );

			Motoneuron allMN_FR = new Motoneuron();
			allMN_FR.setCd( ReMoto.ALL_MN_FR );

			Motoneuron allMN_FF = new Motoneuron();
			allMN_FF.setCd( ReMoto.ALL_MN_FF );

			SensoryFiber allIaSynapses = new SensoryFiber();
			allIaSynapses.setCd( ReMoto.ALL_Ia_terminal );
			
			SensoryFiber allIaStimulusPoint = new SensoryFiber();
			allIaStimulusPoint.setCd( ReMoto.ALL_Ia_stimulus_point );
			
			SensoryFiber allIbSynapses = new SensoryFiber();
			allIbSynapses.setCd( ReMoto.ALL_Ib_terminal );
			
			SensoryFiber allIbStimulusPoint = new SensoryFiber();
			allIbStimulusPoint.setCd( ReMoto.ALL_Ib_stimulus_point );

			SensoryFiber allIa = new SensoryFiber();
			allIa.setCd( ReMoto.ALL_Ia );
			
			SensoryFiber allIb = new SensoryFiber();
			allIb.setCd( ReMoto.ALL_Ib );

			Motoneuron allMU = new Motoneuron();
			allMU.setCd( ReMoto.ALL_MU );
			
			ArrayList condArray = new ArrayList();
			condArray.add( new ConductanceVO(ReMoto.gNa, cdNucleus, cdNucleus) );
			condArray.add( new ConductanceVO(ReMoto.gKf, cdNucleus, cdNucleus) );
			condArray.add( new ConductanceVO(ReMoto.gKs, cdNucleus, cdNucleus) );
			condArray.add( new ConductanceVO(ReMoto.gCa, cdNucleus, cdNucleus) );
			condArray.add( new ConductanceVO(ReMoto.gExcDend, cdNucleus, cdNucleus) );
			condArray.add( new ConductanceVO(ReMoto.gInibDend, cdNucleus, cdNucleus) );
			condArray.add( new ConductanceVO(ReMoto.gExcSoma, cdNucleus, cdNucleus) );
			condArray.add( new ConductanceVO(ReMoto.gInibSoma, cdNucleus, cdNucleus) );

			// Set ElementsSpikes
			resultsForm.getElementsSpikes().add(allMNsoma);
			resultsForm.getElementsSpikes().add(allMNendPlate);
			resultsForm.getElementsSpikes().add(allIaSynapses);
			resultsForm.getElementsSpikes().add(allIaStimulusPoint);
			resultsForm.getElementsSpikes().add(allIbSynapses);
			resultsForm.getElementsSpikes().add(allIbStimulusPoint);
			resultsForm.getElementsSpikes().addAll( sim.getNeuronsStoredSignals(cdNucleus, ReMoto.MN) );
				
			// Set ElementsFiringRate
			resultsForm.getElementsFiringRate().add(allMN);
			resultsForm.getElementsFiringRate().addAll( sim.getNeuronsStoredSignals(cdNucleus, ReMoto.MN) );
			// rcisi@19jul2008 - commented for avoid bug: no results showed 
			//resultsForm.getElementsFiringRate().add(allIa);
			//resultsForm.getElementsFiringRate().add(allIb);

			// Set ElementsHistogram
			resultsForm.getElementsHistogram().add(allMN);
			resultsForm.getElementsHistogram().add(allMN_S);
			resultsForm.getElementsHistogram().add(allMN_FR);
			resultsForm.getElementsHistogram().add(allMN_FF);
			resultsForm.getElementsHistogram().add(allIa);
			resultsForm.getElementsHistogram().add(allIb);
			resultsForm.getElementsHistogram().addAll( sim.getNeuronsStoredSignals(cdNucleus, ReMoto.MN) );
			
			// Set ElementsEMG
			resultsForm.getElementsEMG().add(allMU);
			resultsForm.getElementsEMG().addAll( sim.getNeuronsStoredSignals(cdNucleus, ReMoto.MN) );

			// Set ElementsForce
			resultsForm.getElementsForce().add(allMU);
			resultsForm.getElementsForce().addAll( sim.getNeuronsStoredSignals(cdNucleus, ReMoto.MN) );

			// Set ElementsProperties
			resultsForm.getElementsProperties().add(allMN);
			resultsForm.getElementsProperties().add(allMU);
			
			// Set ElementsSignal
			resultsForm.setElementsSignal( sim.getNeuronsStoredSignals(cdNucleus, ReMoto.MN) );
			
			// Set ElementsConductance
			resultsForm.setElementsConductance( condArray );
		}
		else // Interneurons pools
		{
			// Set labels
			Interneuron allIN = new Interneuron();
			allIN.setCd( ReMoto.ALL_IN );

			Interneuron allRC = new Interneuron();
			allRC.setCd( ReMoto.ALL_RC );

			Interneuron allIaIn = new Interneuron();
			allIaIn.setCd( ReMoto.ALL_IaIn );

			Interneuron allIbIn = new Interneuron();
			allIbIn.setCd( ReMoto.ALL_IbIn );

			ArrayList condArray = new ArrayList();
			condArray.add( new ConductanceVO(ReMoto.gNa, cdNucleus, cdNucleus) );
			condArray.add( new ConductanceVO(ReMoto.gKf, cdNucleus, cdNucleus) );
			condArray.add( new ConductanceVO(ReMoto.gKs, cdNucleus, cdNucleus) );
			condArray.add( new ConductanceVO(ReMoto.gExcDend, cdNucleus, cdNucleus) );
			condArray.add( new ConductanceVO(ReMoto.gInibDend, cdNucleus, cdNucleus) );

			// Set ElementsSpikes
			resultsForm.getElementsSpikes().add(allRC);
			resultsForm.getElementsSpikes().add(allIaIn);
			resultsForm.getElementsSpikes().add(allIbIn);
			resultsForm.getElementsSpikes().addAll( sim.getNeuronsStoredSignals(cdNucleus, ReMoto.IN) );
				
			// Set ElementsFiringRate
			resultsForm.getElementsFiringRate().addAll( sim.getNeuronsStoredSignals(cdNucleus, ReMoto.IN) );

			// Set ElementsHistogram
			resultsForm.getElementsHistogram().addAll( sim.getNeuronsStoredSignals(cdNucleus, ReMoto.IN) );
			
			// Set ElementsProperties
			resultsForm.getElementsProperties().add(allIN);
			
			// Set ElementsSignal
			resultsForm.getElementsSignal().addAll( sim.getNeuronsStoredSignals(cdNucleus, ReMoto.IN) );
			
			// Set ElementsConductance
			resultsForm.setElementsConductance( condArray );
		}

		// Set ListSamples
		resultsForm.setListSamples( conf.getListSamples() );

		resultsForm.setCdNucleus( cdNucleus );
		resultsForm.setNuclei( nuclei );
		resultsForm.setTask( conf.getResult().getTask() );
		resultsForm.setCdSpikes( conf.getResult().getCdSpikes() );
		resultsForm.setCdFiringRate( conf.getResult().getCdFiringRate() );
		resultsForm.setCdHistogram( conf.getResult().getCdHistogram() );
		resultsForm.setCdEMG( conf.getResult().getCdEMG() );
		resultsForm.setCdForce( conf.getResult().getCdForce() );
		resultsForm.setCdSignal( conf.getResult().getCdSignal() );
		resultsForm.setCdProperties( conf.getResult().getCdProperties() );
		resultsForm.setCdConductance( conf.getResult().getCdConductance() );
		resultsForm.setWhichSignal( conf.getResult().getWhichSignal() );
		resultsForm.setSample( conf.getResult().getSample() );
		resultsForm.setFcLow( conf.getResult().getFcLow() );
		resultsForm.setFcHigh( conf.getResult().getFcHigh() );
		resultsForm.setFilter( conf.getResult().getFilter() );
		resultsForm.setWithEMGnoise( conf.getResult().isWithEMGnoise() );
		resultsForm.setWithEMGattenuation( conf.getResult().isWithEMGattenuation() );
		
		
		if( conf.getResult().getNumberOfBins() < 1 )
			conf.getResult().setNumberOfBins( ReMoto.numberOfBins );
		
		resultsForm.setNumberOfBins( conf.getResult().getNumberOfBins() );
		
		resultsForm.setXfin( conf.getResult().getCoordenate().getXfin() );
		resultsForm.setXini( conf.getResult().getCoordenate().getXini() );
		resultsForm.setYini( conf.getResult().getCoordenate().getYini() );
		resultsForm.setYfin( conf.getResult().getCoordenate().getYfin() );
	}
	
}
