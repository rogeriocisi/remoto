
 drop table current;
 drop table motorunit_type;
 drop table markov_type;
 drop table signal;
 drop table neuron_type;
 drop table synaptic_dynamics;
 drop table conductance_type;
 drop table nerve;
 drop table category;
 drop table mu_position;
 drop table nucleus;
 drop table miscellaneous;
 drop table configuration;


-- drop table user;
    
-- CREATE TABLE user (
--        cd_user              varchar(20) PRIMARY KEY,
--        password         	 varchar(50) NULL,
--        email         		 varchar(20) NULL,
--        institution          varchar(20) NULL,
--        nm_user              varchar(20) NULL
-- );

-- insert into user (cd_user, nm_user, password, email, institution) values ('guest', 'Guest user', 'guest', 'rcisi@leb.usp.br', 'USP');
-- insert into user (cd_user, nm_user, password, email, institution) values ('rcisi', 'Rog�rio Cisi', 'rcisi', 'rcisi@leb.usp.br', 'USP');
 

 CREATE TABLE category (
        cd_category          varchar(20) PRIMARY KEY,
        nm_category          varchar(20) NULL
 );

 CREATE TABLE nucleus (
        cd_nucleus          varchar(10),
        nm_nucleus          varchar(20) NULL,
        layer          		varchar(3),
        index             	int NULL,
        PRIMARY KEY (cd_nucleus)
 );

 CREATE TABLE configuration (
        id_configuration     int PRIMARY KEY,
        cd_user              varchar(20) NULL,
        nm_configuration     varchar(20) NULL,
        ds_configuration     varchar(20) NULL,
        dt_configuration     datetime NULL,
        tfin                 numeric NULL,
        merge				 int NULL,
        keep_properties		 int NULL,
        FOREIGN KEY (cd_user) REFERENCES user(cd_user)
 );
 
 CREATE TABLE miscellaneous (
        property          	varchar(20),
        id_configuration    int,
        description        	varchar(100),
        value             	numeric,
        index             	int NULL,
        division            int NULL,
        PRIMARY KEY (property, id_configuration),
        FOREIGN KEY (id_configuration) REFERENCES configuration(id_configuration)
 );

 CREATE TABLE nerve (
        cd_nerve				varchar(20),
        id_configuration		int, 
		stimulus_spinal_entry	numeric,
    	stimulus_end_plate		numeric,        
        active              	int NULL,
        index             		int NULL,
        PRIMARY KEY (cd_nerve, id_configuration),
        FOREIGN KEY (id_configuration) REFERENCES configuration(id_configuration)
 );

 CREATE TABLE conductance_type (
        cd_conductance_type  varchar(20),
        id_configuration     int,
        cd_nucleus           varchar(10),
        cd_nucleus_pre       varchar(10),
        gmax                 numeric NULL,
        E                    numeric NULL,
        connectivity         numeric NULL,
        delay				 numeric NULL,
        compartment          varchar(1),
        active               int NULL,
        index             	 int NULL,
        PRIMARY KEY (cd_conductance_type, id_configuration, cd_nucleus, cd_nucleus_pre),
        FOREIGN KEY (cd_nucleus) REFERENCES nucleus(cd_nucleus),
        FOREIGN KEY (cd_nucleus_pre) REFERENCES nucleus(cd_nucleus),
        FOREIGN KEY (id_configuration) REFERENCES configuration(id_configuration)
 );
 
 CREATE TABLE neuron_type (
        cd_neuron_type       varchar(20),
        id_configuration     int NULL,
        cd_nucleus           varchar(10),
        cd_nucleus_pre       varchar(10) NULL,
        cd_category          varchar(20) NULL,
        rheobase1            numeric NULL,
        rheobase2            numeric NULL,
		axon_velocity1		 numeric NULL,
		axon_velocity2		 numeric NULL,
		axon_threshold1		 numeric NULL,
		axon_threshold2		 numeric NULL,
        rm_soma1              numeric NULL,
        rm_soma2              numeric NULL,
        rm_dend1              numeric NULL,
        rm_dend2              numeric NULL,
        d_dend1               numeric NULL,
        d_dend2               numeric NULL,
        l_dend1			 	 numeric NULL,
        l_dend2			 	 numeric NULL,
        d_soma1				 numeric NULL,
        d_soma2				 numeric NULL,
        l_soma1    			 numeric NULL,
        l_soma2    			 numeric NULL,
        cm                   numeric NULL,
        ri                   numeric NULL,
        total_area 			 numeric NULL,
        distribution         varchar(2) NULL,
        cd_nerve	         varchar(20) NULL,
        mean                 int NULL,
        std                  int NULL,
        quantity          	 int NULL,
        active               int NULL,
        index             	 int NULL,
        PRIMARY KEY (cd_neuron_type, id_configuration, cd_nucleus),
        FOREIGN KEY (id_configuration) REFERENCES configuration(id_configuration),
        FOREIGN KEY (cd_nucleus) REFERENCES nucleus(cd_nucleus),
        FOREIGN KEY (cd_nerve, id_configuration) REFERENCES nerve(cd_nerve, id_configuration),
        FOREIGN KEY (cd_category) REFERENCES category(cd_category)
 );
 
 CREATE TABLE markov_type (
        cd_markov_type  	 varchar(20),
        id_configuration     int,
        cd_nucleus           varchar(10),
		tpeak				 numeric NULL,
		tmax				 numeric NULL,
		alpha				 numeric NULL,
		beta				 numeric NULL,
        gmax                 numeric NULL,
        E                    numeric NULL,
        index             	 int NULL,
        PRIMARY KEY (cd_markov_type, id_configuration, cd_nucleus, index),
        FOREIGN KEY (cd_nucleus) REFERENCES nucleus(cd_nucleus),
        FOREIGN KEY (id_configuration) REFERENCES configuration(id_configuration)
 );
 
 CREATE TABLE current (
        id_configuration     int,
        cd_nucleus           varchar(10),
        cd_neuron_type       varchar(20),
        compartment          varchar(1) NULL,
        imax                 numeric NULL,
        cd_signal            varchar(10),
        tini                 numeric NULL,
        tfin                 numeric NULL,
        amp                  numeric NULL,
        freq             	 numeric NULL,
        width	             numeric NULL,
        active               int NULL,
        index             	 int NULL,
        PRIMARY KEY (id_configuration, cd_nucleus, cd_neuron_type),
        FOREIGN KEY (cd_neuron_type, id_configuration, cd_nucleus) REFERENCES neuron_type(cd_neuron_type, id_configuration, cd_nucleus)
 );
 
 CREATE TABLE motorunit_type (
        cd_motorunit_type    varchar(20),
        id_configuration     int,
        cd_nucleus           varchar(10),
        twitch_tension1      numeric NULL,
        twitch_tension2      numeric NULL,
        tetanic_tension1     numeric NULL,
        tetanic_tension2     numeric NULL,
        tau_force1           numeric NULL,
        tau_force2           numeric NULL,
        amp_emg1             numeric NULL,
        amp_emg2             numeric NULL,
        dur_emg1             numeric NULL,
        dur_emg2             numeric NULL,
        index             	 int NULL,
        PRIMARY KEY (cd_motorunit_type, id_configuration, cd_nucleus),
        FOREIGN KEY (cd_nucleus) REFERENCES nucleus(cd_nucleus),
        FOREIGN KEY (id_configuration) REFERENCES configuration(id_configuration)
 );
 
 CREATE TABLE signal (
        id_configuration     int,
        cd_nucleus           varchar(10),
        cd_neuron_type 		 varchar(10),
        cd_signal            varchar(10),
        mod_type 		 	 varchar(10),
        tini                 numeric NULL,
        tfin                 numeric NULL,
        amp                  numeric NULL,
        freq             	 numeric NULL,
        width	             numeric NULL,
        PRIMARY KEY (id_configuration, cd_nucleus, cd_neuron_type),
        FOREIGN KEY (cd_neuron_type, id_configuration, cd_nucleus) REFERENCES neuron_type(cd_neuron_type, id_configuration, cd_nucleus)
 );

 CREATE TABLE synaptic_dynamics (
        id_configuration     int,
        cd_nucleus           varchar(10),
        cd_nucleus_pre       varchar(10),
        cd_conductance_type  varchar(20),
        dynamic_type         varchar(2),
        tau                  numeric NULL,
        variation          	 numeric NULL,
        PRIMARY KEY (id_configuration, cd_nucleus, cd_nucleus_pre, cd_conductance_type),
        FOREIGN KEY (cd_nucleus) REFERENCES nucleus(cd_nucleus),
        FOREIGN KEY (cd_nucleus_pre) REFERENCES nucleus(cd_nucleus),
        FOREIGN KEY (id_configuration) REFERENCES configuration(id_configuration),
        FOREIGN KEY (cd_conductance_type, id_configuration, cd_nucleus, cd_nucleus_pre) REFERENCES conductance_type(cd_conductance_type, id_configuration, cd_nucleus, cd_nucleus_pre)
 );
 
  
 CREATE TABLE mu_position (
        cd_nucleus          varchar(10),
        cd_mu	          	varchar(10),
        position_y         	numeric NULL,
        position_z         	numeric NULL,
        PRIMARY KEY (cd_nucleus, cd_mu),
        FOREIGN KEY (cd_nucleus) REFERENCES nucleus(cd_nucleus)
 );


 insert into nucleus (cd_nucleus, nm_nucleus, layer, index) values ('DT', 'Descending tracts', 'DTs', 0);
 insert into nucleus (cd_nucleus, nm_nucleus, layer, index) values ('SOL','Soleus', 'MNs', 1);
 insert into nucleus (cd_nucleus, nm_nucleus, layer, index) values ('MG', 'Medial gastrocnemius', 'MNs', 2);
 insert into nucleus (cd_nucleus, nm_nucleus, layer, index) values ('LG', 'Lateral gastrocnemius', 'MNs', 3); 
 insert into nucleus (cd_nucleus, nm_nucleus, layer, index) values ('TA', 'Tibial anterior', 'MNs', 4);
 insert into nucleus (cd_nucleus, nm_nucleus, layer, index) values ('IN_ext', 'Interneurons (SOL-MG-LG)', 'INs', 5);
 insert into nucleus (cd_nucleus, nm_nucleus, layer, index) values ('IN_flex', 'Interneurons (TA)', 'INs', 6);

 insert into category (cd_category, nm_category) values ('MN', 'Motoneuron');
 insert into category (cd_category, nm_category) values ('IN', 'Interneuron');
 insert into category (cd_category, nm_category) values ('TR', 'Descending Tract');
 insert into category (cd_category, nm_category) values ('AF', 'Afferent Sensory Fiber');
 insert into category (cd_category, nm_category) values ('Noise', 'Noise');
 
 insert into configuration (id_configuration, nm_configuration, ds_configuration, cd_user, dt_configuration, tfin, merge, keep_properties) values (1, 'Ankle flexion-extension', 'MG, LG, SOL and TA nucleus', 'guest', '2005-03-30', 200, 1, 0);
 
 