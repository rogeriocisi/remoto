package br.remoto.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import br.remoto.model.Configuration;
import br.remoto.model.Current;
import br.remoto.model.ModulatingSignal;
import br.remoto.model.ReMoto;
import br.remoto.model.vo.MiscellaneousVO;
import br.remoto.model.vo.NerveVO;
import br.remoto.model.vo.Category;
import br.remoto.model.vo.ConductanceVO;
import br.remoto.model.vo.DynamicVO;
import br.remoto.model.vo.MotorUnitVO;
import br.remoto.model.vo.Nucleus;
import br.remoto.model.vo.GeneralVO;
import br.remoto.model.vo.NeuronVO;
import br.remoto.model.vo.User;
import br.remoto.util.Point;


public class ConfigurationDAO extends BasicDAO
{
	private Configuration conf;
	

	public Configuration getConfiguration(int idConfiguration)
	{
   		connect();
    	
		conf = new Configuration();
		
    	conf.setNuclei( loadNucleus() );
    	conf.setCategories( loadCategories() );
    	conf.setGeneral( loadConfiguration(idConfiguration) );
    	
    	conf.setNerves( loadNerves(idConfiguration) );
    	conf.setModulatingSignals( loadSignals(idConfiguration) );
    	conf.setCurrents( loadCurrents(idConfiguration) );
    	conf.setSynapseTypes( loadSynapseTypes(idConfiguration) );
    	conf.setMarcovTypes( loadMarcovTypes(idConfiguration) );
    	conf.setDynamicTypes( loadDynamicTypes(idConfiguration) );
    	conf.setNeuronTypes( loadNeuronTypes(idConfiguration) );
    	conf.setMotorunitsTypes( loadMotorunitsTypes(idConfiguration) );
    	conf.setMiscellaneous( loadMiscellaneous(idConfiguration) );
    	conf.setMuPresetPosition( loadMuPresetPosition() );
    	
    	disconnect();
    	
    	return conf;
	}
    

	public boolean saveConfiguration(Configuration conf, User user)
	{
    	try
    	{
       		connect();
       		
       		this.conf = conf;
	    	
	    	if( prepareToSave() == false ) return false; 
	    	if( storeConfiguration(user) == false ) return false;
	    	if( storeNerves() == false ) return false;
	    	if( storeMotorunitsTypes() == false ) return false;
	    	if( storeNeuronTypes() == false ) return false;
	    	if( storeSynapseTypes() == false ) return false;
	    	if( storeMarcovTypes() == false ) return false;
	    	if( storeDynamicTypes() == false ) return false;
	    	if( storeCurrents() == false ) return false;
	    	if( storeMiscellaneous() == false ) return false;

	    	con.commit();
	    	
	    	disconnect();
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    		return false;
    	}
    	
    	return true;
	}
    

	public boolean deleteConfiguration(int idConfiguration)
	{
    	try
    	{
       		connect();
	    	
			st = con.createStatement();

			/*
			if( storeDynamicTypes() == false ) return false;
	    	if( storeSignals() == false ) return false;
	    	*/

	    	st.executeUpdate("delete from current where id_configuration = " + idConfiguration);
			st.executeUpdate("delete from signal where id_configuration = " + idConfiguration);
			st.executeUpdate("delete from markov_type where id_configuration = " + idConfiguration);
			st.executeUpdate("delete from synaptic_dynamics where id_configuration = " + idConfiguration);
			st.executeUpdate("delete from conductance_type where id_configuration = " + idConfiguration);
			st.executeUpdate("delete from neuron_type where id_configuration = " + idConfiguration);
			st.executeUpdate("delete from nerve where id_configuration = " + idConfiguration);
			st.executeUpdate("delete from motorunit_type where id_configuration = " + idConfiguration);
			st.executeUpdate("delete from miscellaneous where id_configuration = " + idConfiguration);
			st.executeUpdate("delete from configuration where id_configuration = " + idConfiguration);
			
			st.close(); 
	    	
			con.commit();
	    	
	    	disconnect();
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    		return false;
    	}
    	
    	return true;
	}
	
	
	private boolean prepareToSave()
	{
    	try
    	{
	    	if( conf.getId() == -1 )
	    	{
            	String sql = "select max(id_configuration)" +
      		  		  		 " from configuration";

            	st = con.createStatement();
            	rs = st.executeQuery(sql);
            	
            	if( rs.next() )
            	{
            		conf.setId( rs.getInt(1) + 1 );
            	}

            	rs.close();
    			st.close(); 
	    	}
	    	else
	    	{
	    		deleteConfiguration(conf.getId());
	    	}
		}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    		return false;
    	}
    	
    	if( con == null )
       		connect();

		return true;
	}
	
    
    public List loadConfigurations(String cdUser)
	{
    	connect();
    	
    	List configurations = new ArrayList();
    	
    	try
    	{
    		// -----------------------------------------
			// Load availables configurations for that user

    		String sql =  "select id_configuration, nm_configuration, ds_configuration," +
		    			  " tfin, merge, cd_user, keep_properties" +
		    			  " from configuration" +
		    			  " where (cd_user = '" + cdUser + "'" +
		    			  " or cd_user = 'guest')" +
		    			  " order by nm_configuration";

        	st = con.createStatement();
        	rs = st.executeQuery(sql);
        	
        	while( rs.next() )
        	{
        		GeneralVO general = new GeneralVO();
        		
        		general.setId( rs.getInt(1) );
        		general.setName( rs.getString(2) );
        		general.setDescription( rs.getString(3) );
        		general.setTFin( rs.getDouble(4) );
        		general.setMerge( rs.getBoolean(5) );
        		general.setCdUser( rs.getString(6) );
        		general.setKeepProperties( rs.getBoolean(7) );
        		
        		configurations.add( general );
        	}

        	rs.close();
			st.close(); 
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    	}
    	
    	disconnect();
    	
    	return configurations;
	}
	
    
    public GeneralVO loadConfiguration(int idConfiguration)
	{
		GeneralVO general = new GeneralVO();
		
    	try
    	{
    		// -----------------------------------------
			// Load availables configurations for that user

    		String sql =  "select id_configuration, nm_configuration, ds_configuration, tfin," +
		    			  " merge, cd_user, keep_properties" +
		    			  " from configuration" +
		    			  " where id_configuration = " + idConfiguration +
		    			  " order by nm_configuration";

        	st = con.createStatement();
        	rs = st.executeQuery(sql);
        	
        	if( rs.next() )
        	{
        		general.setId( rs.getInt(1) );
        		general.setName( rs.getString(2) );
        		general.setDescription( rs.getString(3) );
        		general.setTFin( rs.getDouble(4) );
        		general.setMerge( rs.getBoolean(5) );
        		general.setCdUser( rs.getString(6) );
        		general.setKeepProperties( rs.getBoolean(7) );
        	}

        	rs.close();
			st.close(); 
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    	}
    	
    	return general;
	}

    
    private List loadNucleus()
	{
    	List list = new ArrayList();
    	
    	try
    	{
    		String sql = "select cd_nucleus, nm_nucleus, layer, index" +
    					 " from nucleus order by index";

        	st = con.createStatement();
        	rs = st.executeQuery(sql);
        	
        	while( rs.next() )
        	{
            	Nucleus nucleus = new Nucleus();
            	
            	nucleus.setCd( rs.getString(1) );
            	nucleus.setName( rs.getString(2) );
            	nucleus.setLayer( rs.getString(3) );
            	nucleus.setInd( rs.getInt(4) );

        		list.add( nucleus );
        	}

        	rs.close();
			st.close(); 
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    	}
    	
    	return list;
	}

	
    private List loadCategories()
	{
    	List list = new ArrayList();
    	
    	try
    	{
    		String sql = "select cd_category, nm_category" +
    					 " from category" +
    					 " order by nm_category desc";

        	st = con.createStatement();
        	rs = st.executeQuery(sql);
        	
        	while( rs.next() )
        	{
            	Category category = new Category();
            	
            	category.setCdCategory( rs.getString(1) );
            	category.setName( rs.getString(2) );

        		list.add( category );
        	}

        	rs.close();
			st.close(); 
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    	}
    	
    	return list;
	}


	private List loadCurrents(int idConfiguration)
	{
		List list = new ArrayList();
    	
    	try
    	{
    		String sql = "select imax, cd_nucleus, cd_neuron_type," +
    					 " cd_signal, tini, tfin, amp, freq, width," +
    					 " compartment, active, index" +
    					 " from current" +
    					 " where id_configuration = " + idConfiguration +
    					 " order by cd_nucleus, index";

        	st = con.createStatement();
        	rs = st.executeQuery(sql);
        	
        	while( rs.next() )
        	{
        		Current inj = new Current();
        		
        		inj.setImax( rs.getDouble(1) );
        		inj.setCdNucleus( rs.getString(2) );
        		inj.setCdNeuronType( rs.getString(3) );

				inj.setCdSignal( rs.getString(4) );
				inj.setIni( rs.getDouble(5) );
				inj.setFin( rs.getDouble(6) );
				inj.setAmp( rs.getDouble(7) );
				inj.setFreq( rs.getDouble(8) );
				inj.setWidth( rs.getDouble(9) );
        		
        		inj.setCompartment( rs.getString(10) );
        		inj.setActive( rs.getBoolean(11) );
        		inj.setIndex( rs.getInt(12) );
        		
        		list.add( inj );
        	}

        	rs.close();
			st.close(); 
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    	}
    	
    	return list;
	}


	private List loadSignals(int idConfiguration)
	{
		List list = new ArrayList();
    	
        try
    	{
    		String sql = "select cd_signal, cd_nucleus, cd_neuron_type," +
    					 " mod_type, tini, tfin, amp, freq, width" +
    					 " from signal" +
    					 " where id_configuration = " + idConfiguration +
    					 " order by cd_nucleus";

        	st = con.createStatement();
        	rs = st.executeQuery(sql);
        	
        	while( rs.next() )
        	{
        		ModulatingSignal signal = new ModulatingSignal();
        		
        		signal.setCdSignal( rs.getString(1) );
        		signal.setCdNucleus( rs.getString(2) );
        		signal.setCdNeuronType( rs.getString(3) );
        		signal.setModType( rs.getString(4) );
        		signal.setTini( rs.getDouble(5) );
        		signal.setTfin( rs.getDouble(6) );
        		signal.setAmp( rs.getDouble(7) );
        		signal.setFreq( rs.getDouble(8) );
        		signal.setWidth( rs.getDouble(9) );
        		
        		list.add( signal );
        	}

        	rs.close();
			st.close(); 
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    	}
    	
    	return list;
	}
    
    
    private List loadSynapseTypes(int idConfiguration)
	{
    	List list = new ArrayList();
    	
    	try
    	{
    		String sql = "select cd_conductance_type, cd_nucleus, cd_nucleus_pre," +
    					 " E, gmax, connectivity, compartment, active, delay, index" +
    					 " from conductance_type" +
    					 " where id_configuration = " + idConfiguration +
  		  		  		 " order by compartment, index";

        	st = con.createStatement();
        	rs = st.executeQuery(sql);
        	
        	while( rs.next() )
        	{
            	ConductanceVO g = new ConductanceVO();
            	
            	g.setCdConductanceType( rs.getString(1) );
            	g.setCdNucleus( rs.getString(2) );
            	g.setCdNucleusPre( rs.getString(3) );
            	g.setE( rs.getDouble(4) );
            	g.setGmax( rs.getDouble(5) );
            	g.setConnectivity( rs.getDouble(6) );
            	g.setCompartment( rs.getString(7) );
            	g.setActive( rs.getBoolean(8) );
            	g.setDelay( rs.getDouble(9) );
            	g.setIndex( rs.getInt(10) );

        		list.add( g );
        	}

        	rs.close();
			st.close(); 
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    	}
    	
    	return list;
	}
    
    
    private Hashtable loadMarcovTypes(int idConfiguration)
	{
    	Hashtable hash = new Hashtable();
    	
    	try
    	{
    		String sql = "select cd_markov_type, cd_nucleus," +
    					 " E, gmax, tpeak, tmax, alpha, beta, index" +
    					 " from markov_type" +
    					 " where id_configuration = " + idConfiguration +
  		  		  		 " order by index";

        	st = con.createStatement();
        	rs = st.executeQuery(sql);
        	
        	while( rs.next() )
        	{
        		ConductanceVO g = new ConductanceVO();
            	
            	g.setCdConductanceType( rs.getString(1) );
            	g.setCdNucleus( rs.getString(2) );
            	g.setE( rs.getDouble(3) );
            	g.setGmax( rs.getDouble(4) );
            	g.setTpeak( rs.getDouble(5) );
            	g.setTmax( rs.getDouble(6) );
            	g.setAlpha( rs.getDouble(7) );
            	g.setBeta( rs.getDouble(8) );
            	g.setIndex( rs.getInt(9) );

        		hash.put( g.getCdNucleus() + g.getCdConductanceType() + g.getPolarity(), g);
        	}

        	rs.close();
			st.close(); 
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    	}
    	
    	return hash;
	}
    
    
    private List loadDynamicTypes(int idConfiguration)
	{
    	List list = new ArrayList();
    	
    	try
    	{
    		String sql = "select cd_nucleus, cd_nucleus_pre," +
    					 " cd_conductance_type, dynamic_type, tau, variation" +
    					 " from synaptic_dynamics" +
    					 " where id_configuration = " + idConfiguration;

        	st = con.createStatement();
        	rs = st.executeQuery(sql);
        	
        	while( rs.next() )
        	{
        		DynamicVO vo = new DynamicVO();
            	
        		vo.setCdNucleus( rs.getString(1) );
        		vo.setCdNucleusPre( rs.getString(2) );
        		vo.setCdConductanceType( rs.getString(3) );
        		vo.setDynamicType( rs.getString(4) );
        		vo.setTau( rs.getDouble(5) );
        		vo.setVariation( rs.getDouble(6) );

        		list.add( vo );
        	}

        	rs.close();
			st.close(); 
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    	}
    	
    	return list;
	}
    
    
    private List loadNeuronTypes(int idConfiguration)
	{
    	List list = new ArrayList();
    	
    	try
    	{
    		String sql = "select cd_neuron_type, cd_category, cd_nucleus, rheobase1, rheobase2," +
						 " cm, ri, rm_dend1, rm_dend2, rm_soma1, rm_soma2, d_dend1, d_dend2, " +
						 " l_dend1, l_dend2, d_soma1, d_soma2, l_soma1, l_soma2, total_area," +
						 " distribution, mean, std, axon_velocity1, axon_velocity2," +
						 " axon_threshold1, axon_threshold2, quantity, cd_nerve, active, index" +
    					 " from neuron_type" +
    					 " where id_configuration = " + idConfiguration +
    					 " order by cd_nucleus, index";

        	st = con.createStatement();
        	rs = st.executeQuery(sql);
        	
        	while( rs.next() )
        	{
        		NeuronVO neu = new NeuronVO();
            	
        		neu.setType( rs.getString(1) );
        		neu.setCategory( rs.getString(2) );
        		neu.setCdNucleus( rs.getString(3) );
        		neu.setRheobase1( rs.getDouble(4) );
        		neu.setRheobase2( rs.getDouble(5) );
        		
        		neu.setCm( rs.getDouble(6) );
        		neu.setRi( rs.getDouble(7) );
        		neu.setRmDend1( rs.getDouble(8) );
        		neu.setRmDend2( rs.getDouble(9) );
        		neu.setRmSoma1( rs.getDouble(10) );
        		neu.setRmSoma2( rs.getDouble(11) );
    			neu.setDdend1( rs.getDouble(12) );
    			neu.setDdend2( rs.getDouble(13) );
    			neu.setLdend1( rs.getDouble(14) );
    			neu.setLdend2( rs.getDouble(15) );
    			neu.setDsoma1( rs.getDouble(16) );
    			neu.setDsoma2( rs.getDouble(17) );
        		neu.setLsoma1( rs.getDouble(18) );
        		neu.setLsoma2( rs.getDouble(19) );
        		neu.setTotalArea( rs.getDouble(20) );
    			
    			neu.setDistribution( rs.getString(21) );
    			neu.setMean( rs.getDouble(22) );
    			neu.setStd( rs.getDouble(23) );
    			neu.setAxonVelocity1( rs.getDouble(24) );
    			neu.setAxonVelocity2( rs.getDouble(25) );
    			neu.setAxonThreshold1( rs.getDouble(26) );
    			neu.setAxonThreshold2( rs.getDouble(27) );
    			
    			neu.setQuantity( rs.getInt(28) );
    			neu.setCdNerve( rs.getString(29) );
    			neu.setActive( rs.getBoolean(30) );
    			neu.setIndex( rs.getInt(31) );
    			
    			ModulatingSignal signal = conf.getModulationSignal( neu.getType(), neu.getCdNucleus() );

    			if( signal != null )
    			{
        			neu.setCdSignal( signal.getCdSignal() );
        			neu.setAmp( signal.getAmp() );
        			neu.setFreq( signal.getFreq() );
        			neu.setIni( signal.getTini() );
        			neu.setFin( signal.getTfin() );
        			neu.setModType( signal.getModType() );
        			neu.setWidth( signal.getWidth() );
    			}

    			list.add( neu );
        	}

        	rs.close();
			st.close(); 
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    	}
    	
    	return list;
	}
    
    
    private List loadMotorunitsTypes(int idConfiguration)
	{
    	List list = new ArrayList();
    	
    	try
    	{
    		String sql = "select cd_motorunit_type, cd_nucleus, twitch_tension1," +
    					 " twitch_tension2, tetanic_tension1, tetanic_tension2," +
    					 " tau_force1, tau_force2, amp_emg1, amp_emg2, dur_emg1," +
    					 " dur_emg2" +
    					 " from motorunit_type" +
    					 " where id_configuration = " + idConfiguration +
  		  		  		 " order by index";

        	st = con.createStatement();
        	rs = st.executeQuery(sql);
        	
        	while( rs.next() )
        	{
            	MotorUnitVO mu = new MotorUnitVO();
            	
            	mu.setType( rs.getString(1) );
            	mu.setCdNucleus( rs.getString(2) );
            	mu.setTwitchTension1( rs.getDouble(3) );
            	mu.setTwitchTension2( rs.getDouble(4) );
            	mu.setMaxTension1( rs.getDouble(5) );
            	mu.setMaxTension2( rs.getDouble(6) );
        		mu.setContractionTime1( rs.getDouble(7) );
        		mu.setContractionTime2( rs.getDouble(8) );
        		mu.setAmpEMG1( rs.getDouble(9) );
        		mu.setAmpEMG2( rs.getDouble(10) );
        		mu.setLambdaEMG1( rs.getDouble(11) );
        		mu.setLambdaEMG2( rs.getDouble(12) );

        		list.add( mu );
        	}

        	rs.close();
			st.close(); 
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    	}
    	
    	return list;
	}
    
    
    private List loadNerves(int idConfiguration)
	{
    	List list = new ArrayList();
    	
    	try
    	{
    		String sql = "select cd_nerve, active," +
    					 " stimulus_spinal_entry, stimulus_end_plate, index" +
    					 " from nerve" +
    					 " where id_configuration = " + idConfiguration +
    					 " order by index";

        	st = con.createStatement();
        	rs = st.executeQuery(sql);
        	
        	while( rs.next() )
        	{
        		NerveVO nerve = new NerveVO();
            	
            	nerve.setCdNerve( rs.getString(1) );
        		nerve.setActive( rs.getBoolean(2) );
        		nerve.setStimulusSpinalEntry( rs.getDouble(3) );
        		nerve.setStimulusEndPlate( rs.getDouble(4) );
        		nerve.setIndex( rs.getInt(5) );

        		list.add( nerve );
        	}

        	rs.close();
			st.close(); 
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    	}
    	
    	return list;
	}
    
    
    private List loadMiscellaneous(int idConfiguration)
	{
    	List list = new ArrayList();
    	
    	try
    	{
    		String sql = "select property, description, value, index, division" +
    					 " from miscellaneous" +
    					 " where id_configuration = " + idConfiguration +
    					 " order by index";

        	st = con.createStatement();
        	rs = st.executeQuery(sql);
        	
        	while( rs.next() )
        	{
        		MiscellaneousVO vo = new MiscellaneousVO();
            	
        		vo.setProperty( rs.getString(1) );
        		vo.setDescription( rs.getString(2) );
        		vo.setValue( rs.getDouble(3) );
        		vo.setIndex( rs.getInt(4) );
        		vo.setDivision( rs.getBoolean(5) );

        		list.add( vo );
        	}

        	rs.close();
			st.close(); 
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    	}
    	
    	return list;
	}
    

    private Hashtable loadMuPresetPosition()
	{
    	Hashtable hash = new Hashtable();
    	
    	try
    	{
    		String sql = "select cd_nucleus, cd_mu, position_y, position_z" +
    					 " from mu_position";

        	st = con.createStatement();
        	rs = st.executeQuery(sql);
        	
        	while( rs.next() )
        	{
        		Point point = new Point();
            	
        		String cdNucleus = rs.getString(1);
        		String cd = rs.getString(2);
        		
        		point.setY( rs.getDouble(3) );
        		point.setZ( rs.getDouble(4) );

        		hash.put( cdNucleus + cd, point);
        	}

        	rs.close();
			st.close(); 
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    	}
    	
    	return hash;
	}
    
    
    private boolean storeConfiguration(User user)
	{
    	try
    	{
    		int idConfiguration = conf.getId();
    		Calendar cal = Calendar.getInstance();
    		Date date = new Date(cal.getTimeInMillis());
    		
    		String sql = "insert into configuration (id_configuration, nm_configuration, ds_configuration, " +
    					 " cd_user, dt_configuration, tfin, merge, keep_properties) values " +
    					 "(?, ?, ?, ?, ?, ?, ?, ?)";

        	pst = con.prepareStatement(sql);
        	
        	pst.setInt(1, idConfiguration);
        	pst.setString(2, conf.getName());
        	pst.setString(3, conf.getDescription());
        	pst.setString(4, user.getCdUser());
        	pst.setDate(5, date);
        	pst.setDouble(6, conf.getTFin());
        	pst.setBoolean(7, conf.isMerge());
        	pst.setBoolean(8, conf.isKeepProperties());
        	
        	pst.executeUpdate();
        	pst.close(); 
    	}
    	catch (Exception e) 
    	{
    		System.out.println(e.getMessage());
    		return false;
		}
    	
    	return true;
	}

	
	private boolean storeCurrents()
	{
        List list = conf.getCurrents();
    	
    	try
    	{
    		String sql = "insert into current (id_configuration, cd_nucleus, cd_neuron_type," +
    					 " cd_signal, tini, tfin, amp, freq, width," +
    					 " compartment, imax, active, index) " +
    					 " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        	pst = con.prepareStatement(sql);

        	for(int i = 0; i < list.size(); i++)
        	{
        		Current inj = (Current)list.get(i);
        		
	        	pst.setInt(1, conf.getId());
	        	pst.setString(2, inj.getCdNucleus() );
	        	pst.setString(3, inj.getCdNeuronType() );
	        	
	        	pst.setString(4, inj.getCdSignal() );
	        	pst.setDouble(5, inj.getIni());
	        	pst.setDouble(6, inj.getFin());
	        	pst.setDouble(7, inj.getAmp());
	        	pst.setDouble(8, inj.getFreq());
	        	pst.setDouble(9, inj.getWidth());
	        	
	        	pst.setString(10, inj.getCompartment() );
	        	pst.setDouble(11, inj.getImax());
	        	pst.setBoolean(12, inj.isActive());
	        	pst.setInt(13, inj.getIndex());
	        	
	        	pst.executeUpdate();
        	}

        	pst.close();
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    		return false;
    	}
    	
    	return true;
	}

	
	private boolean storeSignal(ModulatingSignal signal)
	{
        try
    	{
    		String sql = "insert into signal (id_configuration, cd_nucleus, cd_neuron_type," +
    					 " cd_signal, mod_type, tini, tfin, amp, freq, width) " +
    					 " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    		PreparedStatement ps = con.prepareStatement(sql);

    		ps.setInt(1, conf.getId());
    		ps.setString(2, signal.getCdNucleus() );
    		ps.setString(3, signal.getCdNeuronType() );
    		ps.setString(4, signal.getCdSignal() );
    		ps.setString(5, signal.getModType() );
    		ps.setDouble(6, signal.getTini());
    		ps.setDouble(7, signal.getTfin());
    		ps.setDouble(8, signal.getAmp());
    		ps.setDouble(9, signal.getFreq());
    		ps.setDouble(10, signal.getWidth());
        	
    		ps.executeUpdate();

    		ps.close();
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    		return false;
    	}
    	
    	return true;
	}
    
    
    private boolean storeSynapseTypes()
	{
    	try
    	{
	    	int idConfiguration = conf.getId();
	    	Hashtable hash = conf.getSynapseTypes();
	
			Iterator it = hash.values().iterator();

			while( it.hasNext() )
			{
				ConductanceVO g = (ConductanceVO)it.next();
	        	
	    		storeConductanceType(g, idConfiguration);
	    	}
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    		return false;
    	}
    	
    	return true;
	}
    
    
    private void storeConductanceType(ConductanceVO g, int idConfiguration) throws Exception
	{
		String sql = "insert into conductance_type" +
					 " (cd_conductance_type, id_configuration, cd_nucleus, cd_nucleus_pre," +
					 " gmax, E, connectivity, compartment, active, delay, index)" +
					 " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		pst = con.prepareStatement(sql);
    	
    	pst.setString(1, g.getCdConductanceType());
    	pst.setDouble(2, idConfiguration);
    	pst.setString(3, g.getCdNucleus());
    	pst.setString(4, g.getCdNucleusPre());
    	pst.setDouble(5, g.getGmax());
    	pst.setDouble(6, g.getE());
    	pst.setDouble(7, g.getConnectivity());
    	pst.setString(8, g.getCompartment());
    	pst.setBoolean(9, g.isActive());
    	pst.setDouble(10, g.getDelay());
    	pst.setInt(11, g.getIndex());

    	pst.executeUpdate();
    	pst.close();
	}
    
    
    private boolean storeMarcovTypes() throws Exception
	{
    	Hashtable hash = conf.getMarcovTypes();
    	
    	try
    	{
			String sql = "insert into markov_type" +
						 " (cd_markov_type, id_configuration, cd_nucleus," +
						 " E, gmax, tpeak, tmax, alpha, beta, index)" +
						 " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	
    		pst = con.prepareStatement(sql);
        	
    		Iterator it = hash.values().iterator();

    		while( it.hasNext() )
    		{
    			ConductanceVO g = (ConductanceVO)it.next();
            	
				pst.setString(1, g.getCdConductanceType());
				pst.setDouble(2, conf.getId());
				pst.setString(3, g.getCdNucleus());
				pst.setDouble(4, g.getE());
				pst.setDouble(5, g.getGmax());
				pst.setDouble(6, g.getTpeak());
				pst.setDouble(7, g.getTmax());
				pst.setDouble(8, g.getAlpha());
				pst.setDouble(9, g.getBeta());
				pst.setInt(10, g.getIndex());

            	pst.executeUpdate();
        	}

        	pst.close();
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    		return false;
    	}
    	
    	return true;
	}
    
    
    private boolean storeDynamicTypes() throws Exception
	{
    	List list = conf.getDynamicTypes();
    	
    	try
    	{
			String sql = "insert into synaptic_dynamics" +
						 " (id_configuration, cd_nucleus, cd_nucleus_pre," +
						 " cd_conductance_type, dynamic_type, tau, variation)" +
						 " values (?, ?, ?, ?, ?, ?, ?)";
	
    		pst = con.prepareStatement(sql);
        	
        	for(int i = 0; i < list.size(); i++)
        	{
        		DynamicVO vo = (DynamicVO)list.get(i);
            	
				pst.setInt(1, conf.getId());
				pst.setString(2, vo.getCdNucleus());
				pst.setString(3, vo.getCdNucleusPre());
				pst.setString(4, vo.getCdConductanceType());
				pst.setString(5, vo.getDynamicType());
				pst.setDouble(6, vo.getTau());
				pst.setDouble(7, vo.getVariation());

            	pst.executeUpdate();
        	}

        	pst.close();
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    		return false;
    	}
    	
    	return true;
	}

    
    private boolean storeNeuronTypes()
	{
    	List list = conf.getNeuronTypes();
    	NeuronVO neu = null;
    	
    	try
    	{
        	String sql = "insert into neuron_type (id_configuration, cd_neuron_type, cd_category, cd_nucleus," +
    					 " rheobase1, rheobase2, rm_dend1, rm_dend2, rm_soma1, rm_soma2, d_dend1, d_dend2," +
    					 " l_dend1, l_dend2, d_soma1, d_soma2, l_soma1, l_soma2, total_area," +
    					 " distribution, quantity, mean, std, axon_velocity1, axon_velocity2," +
    					 " axon_threshold1, axon_threshold2, cm, ri, cd_nerve, index, active)" +
    					 " values (?, ?, ?, ?, " +
    					 "		   ?, ?, ?, ?, " +
    					 "	       ?, ?, ?, ?, " +
    					 "		   ?, ?, ?, ?, " +
    					 "         ?, ?, ?, ?, " +
    					 "         ?, ?, ?, ?, " +
    					 "         ?, ?, ?, ?, " +
						 "         ?, ?, ?, ?)";

    		pst = con.prepareStatement(sql);
        	
        	for(int i = 0; i < list.size(); i++)
        	{
        		neu = (NeuronVO)list.get(i);
            	
            	pst.setInt(1, conf.getId());
            	pst.setString(2, neu.getType());
            	pst.setString(3, neu.getCategory());
            	pst.setString(4, neu.getCdNucleus());
            	
            	pst.setDouble(5, neu.getRheobase1());
            	pst.setDouble(6, neu.getRheobase2());
            	pst.setDouble(7, neu.getRmDend1());
            	pst.setDouble(8, neu.getRmDend2());
            	pst.setDouble(9, neu.getRmSoma1());
            	pst.setDouble(10, neu.getRmSoma2());
            	pst.setDouble(11, neu.getDdend1());
            	pst.setDouble(12, neu.getDdend2());
            	pst.setDouble(13, neu.getLdend1());
            	pst.setDouble(14, neu.getLdend2());
            	pst.setDouble(15, neu.getDsoma1());
            	pst.setDouble(16, neu.getDsoma2());
            	pst.setDouble(17, neu.getLsoma1());
            	pst.setDouble(18, neu.getLsoma2());
            	pst.setDouble(19, neu.getTotalArea());
            	pst.setString(20, neu.getDistribution());
            	pst.setInt(21, neu.getQuantity());
            	pst.setDouble(22, neu.getMean());
            	pst.setDouble(23, neu.getStd());
            	pst.setDouble(24, neu.getAxonVelocity1());
            	pst.setDouble(25, neu.getAxonVelocity2());
            	pst.setDouble(26, neu.getAxonThreshold1());
            	pst.setDouble(27, neu.getAxonThreshold2());
            	pst.setDouble(28, neu.getCm());
            	pst.setDouble(29, neu.getRi());
            	pst.setString(30, neu.getCdNerve());
            	
            	pst.setInt(31, neu.getIndex());
            	pst.setBoolean(32, neu.isActive());

    	    	pst.executeUpdate();

            	if( neu.getCategory().equals( ReMoto.TR ) )
            	{
                	ModulatingSignal signal = new ModulatingSignal();

                	signal.setCdNucleus( neu.getCdNucleus() );
                	signal.setCdNeuronType( neu.getType() );
        			signal.setCdSignal( neu.getCdSignal() );
                	signal.setAmp( neu.getAmp() );
        			signal.setFreq( neu.getFreq() );
        			signal.setTini( neu.getIni() );
        			signal.setTfin( neu.getFin() );
        			signal.setModType( neu.getModType() );
        			signal.setWidth( neu.getWidth() );

        			storeSignal(signal); 
            	}
        	}

        	pst.close();
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage() + " - " + neu.getType());
    		return false;
    	}
    	
    	return true;
	}
    
    
    private boolean storeMotorunitsTypes()
	{
    	List list = conf.getMotorunitsTypes();
    	
    	try
    	{
    		String sql = "insert into motorunit_type (id_configuration, cd_motorunit_type, cd_nucleus," +
    					 " twitch_tension1, twitch_tension2, tetanic_tension1, tetanic_tension2," +
    					 " tau_force1, tau_force2, amp_emg1, amp_emg2, dur_emg1, dur_emg2) values" +
    					 "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    		pst = con.prepareStatement(sql);
        	
        	for(int i = 0; i < list.size(); i++)
        	{
            	MotorUnitVO mu = (MotorUnitVO)list.get(i);
            	
            	pst.setInt(1, conf.getId());
            	pst.setString(2, mu.getType());
            	pst.setString(3, mu.getCdNucleus());
            	pst.setDouble(4, mu.getTwitchTension1());
            	pst.setDouble(5, mu.getTwitchTension2());
            	pst.setDouble(6, mu.getMaxTension1());
            	pst.setDouble(7, mu.getMaxTension2());
            	pst.setDouble(8, mu.getContractionTime1());
            	pst.setDouble(9, mu.getContractionTime2());
            	pst.setDouble(10, mu.getAmpEMG1());
            	pst.setDouble(11, mu.getAmpEMG2());
            	pst.setDouble(12, mu.getLambdaEMG1());
            	pst.setDouble(13, mu.getLambdaEMG2());

            	pst.executeUpdate();
        	}

        	pst.close();
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    		return false;
    	}
    	
    	return true;
	}


    private boolean storeNerves()
	{
    	List list = conf.getNerves();
    	
    	try
    	{
    		String sql = "insert into nerve (id_configuration, cd_nerve, active," +
    					 " stimulus_spinal_entry, stimulus_end_plate, index)" +
    					 " values (?, ?, ?, ?, ?, ?)";

    		pst = con.prepareStatement(sql);
        	
        	for(int i = 0; i < list.size(); i++)
        	{
            	NerveVO nerve = (NerveVO)list.get(i);
            	
            	pst.setInt(1, conf.getId());
            	pst.setString(2, nerve.getCdNerve());
            	pst.setBoolean(3, nerve.isActive());
            	pst.setDouble(4, nerve.getStimulusSpinalEntry());
            	pst.setDouble(5, nerve.getStimulusEndPlate());
            	pst.setInt(6, nerve.getIndex());

            	pst.executeUpdate();
        	}

        	pst.close();
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    		return false;
    	}
    	
    	return true;
	}

    
	private boolean storeMiscellaneous()
	{
        List list = conf.getMiscellaneous();

    	try
    	{
    		String sql = "insert into miscellaneous (id_configuration, property, description, value, index, division)" +
    					 " values (?, ?, ?, ?, ?, ?)";

        	pst = con.prepareStatement(sql);

        	for(int i = 0; i < list.size(); i++)
        	{
        		MiscellaneousVO vo = (MiscellaneousVO)list.get(i);
        		
	        	pst.setInt(1, conf.getId());
	        	pst.setString(2, vo.getProperty());
	        	pst.setString(3, vo.getDescription());
	        	pst.setDouble(4, vo.getValue());
	        	pst.setInt(5, vo.getIndex());
	        	pst.setBoolean(6, vo.isDivision());
	        	
	        	pst.executeUpdate();
        	}

        	pst.close();
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    		return false;
    	}
    	
    	return true;
	}

    
}
