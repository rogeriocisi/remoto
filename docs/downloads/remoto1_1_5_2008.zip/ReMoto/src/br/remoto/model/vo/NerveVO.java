package br.remoto.model.vo;

import java.io.Serializable;

public class NerveVO implements Serializable 
{
	private static final long serialVersionUID = 1L;

	protected String cdNerve;
	protected double tini;
    protected double tfin;
    protected double amp;
    protected double freq;
	protected double stimulusSpinalEntry;
	protected double stimulusEndPlate;    
	protected boolean active;

	protected boolean paired;
	protected double ampPaired;
	protected double delayPaired;
    protected double freqPaired;

	protected int index;

	
	public NerveVO()
	{
	}


	public boolean isActive() {
		return active;
	}


	public void setActive(boolean active) {
		this.active = active;
	}


	public double getAmp() {
		return amp;
	}


	public void setAmp(double amp) {
		this.amp = amp;
	}


	public String getCdNerve() {
		return cdNerve;
	}


	public void setCdNerve(String cdNerve) {
		this.cdNerve = cdNerve;
	}


	public double getFreq() {
		return freq;
	}


	public void setFreq(double freq) {
		this.freq = freq;
	}


	public int getIndex() {
		return index;
	}


	public void setIndex(int index) {
		this.index = index;
	}


	public double getStimulusEndPlate() {
		return stimulusEndPlate;
	}


	public void setStimulusEndPlate(double stimulusEndPlate) {
		this.stimulusEndPlate = stimulusEndPlate;
	}


	public double getStimulusSpinalEntry() {
		return stimulusSpinalEntry;
	}


	public void setStimulusSpinalEntry(double stimulusSpinalEntry) {
		this.stimulusSpinalEntry = stimulusSpinalEntry;
	}


	public double getTfin() {
		return tfin;
	}


	public void setTfin(double tfin) {
		this.tfin = tfin;
	}


	public double getTini() {
		return tini;
	}


	public void setTini(double tini) {
		this.tini = tini;
	}
	


	public boolean isPaired() {
		return paired;
	}


	public void setPaired(boolean paired) {
		this.paired = paired;
	}


	public double getAmpPaired() {
		return ampPaired;
	}


	public void setAmpPaired(double ampPaired) {
		this.ampPaired = ampPaired;
	}


	public double getDelayPaired() {
		return delayPaired;
	}


	public void setDelayPaired(double delayPaired) {
		this.delayPaired = delayPaired;
	}


	public double getFreqPaired() {
		return freqPaired;
	}


	public void setFreqPaired(double freqPaired) {
		this.freqPaired = freqPaired;
	}
	
	
}
