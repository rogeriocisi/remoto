package br.remoto.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import br.remoto.model.Neuron.Neuron;
import br.remoto.model.vo.ConductanceVO;
import br.remoto.model.vo.DynamicVO;
import br.remoto.model.vo.MiscellaneousVO;
import br.remoto.model.vo.MotorUnitVO;
import br.remoto.model.vo.NerveVO;
import br.remoto.model.vo.Nucleus;
import br.remoto.model.vo.ResultVO;
import br.remoto.model.vo.Sample;
import br.remoto.model.vo.GeneralVO;
import br.remoto.model.vo.NeuronVO;


public class Configuration implements Serializable
{
	private static final long serialVersionUID = 1L;

	private GeneralVO general = new GeneralVO();
	private ResultVO result = new ResultVO();

	private boolean changedConfiguration;
	private int muDistribution;
	
	private List miscellaneous;
	private List nuclei;
	private List categories;
	private List neuronTypes;
	private List dynamicTypes;
	private List motorunitsTypes;
	private List nerves;
	private List currents;
	private List modulatingSignals;

	private Hashtable synapseTypes;
	private Hashtable marcovTypes;
	private Hashtable muPresetPosition;

	
	public Configuration()
	{
		changedConfiguration = true;
		muDistribution = ReMoto.muDistributionPreset;
	}
	
	
	public List getNuclei(String layer) 
	{
		List nuclei = getNuclei();
		List ret = new ArrayList();
		
		for(int x = 0; x < nuclei.size(); x++)
		{
			Nucleus nucleus = (Nucleus)nuclei.get(x);
			
			if( layer == null || nucleus.getLayer().equals( layer ) )
				ret.add( nucleus );
		}
		
		return ret;
	}

	
	public Nucleus getNucleus(String cdNucleus) 
	{
		List nuclei = getNuclei();
		Nucleus nucleus = null;
		
		for(int x = 0; x < nuclei.size(); x++)
		{
			nucleus = (Nucleus)nuclei.get(x);
			
			if( nucleus.getCd().equals( cdNucleus ) )
				return nucleus;
		}
		
		return nucleus;
	}

	
	public Nucleus[] getArrayNuclei()
	{
		Nucleus[] ret = new Nucleus[ nuclei.size() ]; 
		
		for(int x = 0; x < nuclei.size(); x++)
		{
			ret[x] = (Nucleus)nuclei.get(x);
		}
		
		return ret;
	}
	
	
	public String getCategory(String neuronType) 
	{
		String category = "";
		
		for(int i = 0; i < neuronTypes.size(); i++)
		{
			NeuronVO neu = (NeuronVO)neuronTypes.get(i);
			
			if( neuronType.equals( neu.getType() ) )
				return neu.getCategory();
		}
		
		return category;
	}

	
	public NeuronVO getNeuronType(String cdNucleus, String type) 
	{
		for(int i = 0; i < neuronTypes.size(); i++)
		{
			NeuronVO neu = (NeuronVO)neuronTypes.get(i);
			
			if( neu.getType().equals( type ) && 
				( cdNucleus == null || cdNucleus.equals( neu.getCdNucleus() ) ) )
			{
				return neu;
			}
		}
		
		return null;
	}

	
	public List getNeuronTypes(String cdNucleus, String category) 
	{
		List list = new ArrayList();
		
		for(int i = 0; i < neuronTypes.size(); i++)
		{
			NeuronVO neu = (NeuronVO)neuronTypes.get(i);
			
			if( ( category == null || neu.getCategory().equals( category ) ) && 
				( cdNucleus == null || cdNucleus.equals( neu.getCdNucleus() ) ) )
			{
				list.add(neu); 
			}
		}
		
		return list;
	}

	
	public NeuronVO getCompleteNeuronType(String cdNucleus, String type) 
	{
		for(int i = 0; i < neuronTypes.size(); i++)
		{
			NeuronVO neu = (NeuronVO)neuronTypes.get(i);
			
			if( neu.getType().equals( type ) && 
				( cdNucleus == null || cdNucleus.equals( neu.getCdNucleus() ) ) )
			{
				// Markov model
				ConductanceVO gNaM = getMarcovType(cdNucleus, ReMoto.gNaM + "-" + type, ReMoto.excitatory);
				ConductanceVO gNaH = getMarcovType(cdNucleus, ReMoto.gNaH + "-" + type, ReMoto.excitatory);
				ConductanceVO gKN = getMarcovType(cdNucleus,  ReMoto.gKN  + "-" + type, ReMoto.inhibitory);
				ConductanceVO gKQ = getMarcovType(cdNucleus,  ReMoto.gKQ  + "-" + type, ReMoto.inhibitory);
				 
				neu.setGNaMVO( new ConductanceVO( gNaM ) );
				neu.setGNaHVO( new ConductanceVO( gNaH ) );
				neu.setGKNVO( new ConductanceVO( gKN ) );
				neu.setGKQVO( new ConductanceVO( gKQ ) );

				return neu;
			}
		}
		
		return null;
	}

	
	public void setListNeuronTypes(List neuronTypes) 
	{
		for(int i = 0; i < neuronTypes.size(); i++)
		{
			NeuronVO neuType = (NeuronVO)neuronTypes.get(i);
			
			for(int j = 0; j < this.neuronTypes.size(); j++)
			{
				NeuronVO neuThis = (NeuronVO)this.neuronTypes.get(j);
				
				if( neuType.getType().equals( neuThis.getType() ) && 
					neuType.getCdNucleus().equals( neuThis.getCdNucleus() ) )
				{
					this.neuronTypes.set(j, neuType);
					break;
				}
			}
		}
	}

	
	public void setQuantityNeuronType(String cdNucleus, String type, int quantity) 
	{
		getNeuronType(cdNucleus, type).setQuantity( quantity );
		getNeuronType(cdNucleus, type).setActive( true );
	}

    
	public MotorUnitVO getMotorUnitType(String cdNucleus, String type) 
	{
		for(int i = 0; i < motorunitsTypes.size(); i++)
		{
			MotorUnitVO fb = (MotorUnitVO)motorunitsTypes.get(i);
			
			if( cdNucleus.equals( fb.getCdNucleus() ) &&
				type.equals( fb.getType() ) )
			{
				return fb;
			}
		}
		
		return null;
	}
	
	
	public List getMotorUnitTypes(String cdNucleus) 
	{
		List list = new ArrayList();
		
		for(int i = 0; i < motorunitsTypes.size(); i++)
		{
			MotorUnitVO fb = (MotorUnitVO)motorunitsTypes.get(i);
			
			if( cdNucleus.equals( fb.getCdNucleus() ) )
				list.add(fb);
		}
		
		return list;
	}

    
	public void setListMotorUnitTypes(List muTypes) 
	{
		for(int i = 0; i < muTypes.size(); i++)
		{
			MotorUnitVO mu = (MotorUnitVO)muTypes.get(i);
			
			for(int j = 0; j < this.motorunitsTypes.size(); j++)
			{
				MotorUnitVO muThis = (MotorUnitVO)this.motorunitsTypes.get(j);
				
				if( mu.getType().equals( muThis.getType() ) && 
					mu.getCdNucleus().equals( muThis.getCdNucleus() ) )
				{
					this.motorunitsTypes.set(j, mu);
					break;
				}
			}
		}
	}
	
	
	public ConductanceVO getSynapseType(Neuron neuronPre, Neuron neuronPos) 
	{
		ConductanceVO g = (ConductanceVO)synapseTypes.get( neuronPre.getCdNucleus() + 
														   neuronPos.getCdNucleus() +  
														   neuronPre.getCategory() + " " + neuronPre.getType() + 
														   "-" +
														   neuronPos.getCategory() + " " + neuronPos.getType() );
		
		return g;
	}

	
	public ConductanceVO getSynapseType(String cdNucleusPre, String cdNucleus, String cdConductanceType)
	{
		ConductanceVO g = (ConductanceVO)synapseTypes.get( cdNucleusPre + cdNucleus + cdConductanceType );
		
		return g;
	}

	
	public List getSynapticConductances(String cdNucleus, String pre, String pos) 
	{
		List list = new ArrayList();
		
		Hashtable active = new Hashtable();

		// Verify active neuronTypes 
		for(int i = 0; i < neuronTypes.size(); i++)
		{
			NeuronVO nt = (NeuronVO)neuronTypes.get(i);
			
			active.put( nt.getCategoryType() + " " + nt.getCdNucleus(), new Boolean(nt.isActive()) ); 
		}
		
		Iterator it = synapseTypes.values().iterator();

		while( it.hasNext() )
		{
			ConductanceVO g = (ConductanceVO)it.next();
			
			if( ( pre.equals( ReMoto.ALL ) || pre.equals( ReMoto.ACTIVE ) ) &&
				( g.getCdConductanceType().lastIndexOf( pos ) > 0  || pos.equals( ReMoto.ALL ) || pos.equals( ReMoto.ACTIVE ) ) &&
				( cdNucleus == null || cdNucleus.equals( g.getCdNucleus() ) ) )
			{
        		Boolean statePre = (Boolean)active.get(g.getPreSimple() + " " + g.getCdNucleusPre());
        		Boolean statePos = (Boolean)active.get(g.getPos() + " " + g.getCdNucleus());
				
        		if( ( pre.equals( ReMoto.ALL ) || (pre.equals( ReMoto.ACTIVE ) && statePre != null && statePre.equals(Boolean.TRUE)) ) &&
					( g.getPos().indexOf( pos ) == 0 || pos.equals( ReMoto.ALL ) || (pos.equals( ReMoto.ACTIVE ) && statePos != null && statePos.equals(Boolean.TRUE)) ) )
				{
        			// Set synaptic dynamics type (depressing, facilitating or none)
        			DynamicVO vo = getDynamicType(g.getCdConductanceType(), g.getCdNucleusPre(), g.getCdNucleus());
       				g.setDynamics( vo );
        			
        			list.add(g);
				}
			}
		}
		
		Collections.sort(list);
		
		return list;
	}
	
	
	public void setSynapseTypes(List conductances)
	{
		if( synapseTypes == null )
			synapseTypes = new Hashtable();
		
		for(int i = 0; i < conductances.size(); i++)
		{
			ConductanceVO g = (ConductanceVO)conductances.get(i);
			
			synapseTypes.put(g.getCdNucleusPre() + g.getCdNucleus() + g.getCdConductanceType(), g);
		}
	}
	

	public void setSynapseType(String cdConductance, ConductanceVO g)
	{
		synapseTypes.put(g.getCdNucleusPre() + g.getCdNucleus() + g.getCdConductanceType(), g);
	}

	
	public double getSynapticConnectivity(ConductanceVO g) 
	{
		if( g != null )
			return g.getConnectivity() / 100.0;
		else
			return 0;
	}
	
	
	public List getSynapticDynamics(String cdNucleus) 
	{
		List list = new ArrayList();
		
		Iterator it = marcovTypes.values().iterator();

		while( it.hasNext() )
		{
			ConductanceVO g = (ConductanceVO)it.next();
			
			if( ( cdNucleus == null || cdNucleus.equals( "" ) || cdNucleus.equals( g.getCdNucleus() ) ) &&
				g.getCdConductanceType().indexOf( "g" ) != 0 )
			{
				list.add(g);
			}
		}
		
		Collections.sort(list);
		
		return list;
	}
	

	public ConductanceVO getMarcovType(String cdNucleus, String type, String polarityType)
	{
		ConductanceVO g = (ConductanceVO)marcovTypes.get( cdNucleus + type + polarityType );
		
		return g;
	}

	
	public void setListMarkovTypes(List conductances)
	{
		for(int i = 0; i < conductances.size(); i++)
		{
			ConductanceVO g = (ConductanceVO)conductances.get(i);
			
			marcovTypes.put(g.getCdNucleus() + g.getCdConductanceType() + g.getPolarity(), g);
		}
	}

	
	public List getNeuronIonicConductances(String cdNucleus, String cdNeuronType) 
	{
		List list = new ArrayList();
		
		Iterator it = marcovTypes.values().iterator();

		while( it.hasNext() )
		{
			ConductanceVO g = (ConductanceVO)it.next();
			
			if( g.getCdNucleus().equals( cdNucleus ) && 
				g.getCdConductanceType().indexOf( "-" + cdNeuronType ) > 0 )
			{
				list.add(g);
			}
		}
		
		return list;
	}
	
	
	public void setNeuronIonicConductances(List conductances)
	{
		for(int i = 0; i < conductances.size(); i++)
		{
			ConductanceVO g = (ConductanceVO)conductances.get(i);
			
			marcovTypes.put(g.getCdNucleus() + g.getCdConductanceType() + g.getPolarity(), g);
		}
	}

	
	public List getCurrents(String cdNucleus)
	{
		List list = new ArrayList();
		
		for(int i = 0; i < currents.size(); i++)
		{
			Current current = (Current)currents.get(i); 
			
			if( cdNucleus.equals( current.getCdNucleus() ) )
			{
				list.add( current );
			}
		}
		
		return list;
	}
	
	
	public Current getCurrent(String cdNucleus, String type)
	{
		for(int i = 0; i < currents.size(); i++)
		{
			Current current = (Current)currents.get(i); 
			
			if( cdNucleus.equals( current.getCdNucleus() ) && 
				type.equals( current.getCdNeuronType() ) )
			{
				return current;
			}
		}
		
		return null;
	}
	
	
	public void setListCurrents(List listCurrents) 
	{
		for(int i = 0; i < listCurrents.size(); i++)
		{
			Current current = (Current)listCurrents.get(i);
			
			for(int j = 0; j < currents.size(); j++)
			{
				Current currentThis = (Current)currents.get(j);
				
				if( current.getCdNeuronType().equals( currentThis.getCdNeuronType() ) && 
					current.getCdNucleus().equals( currentThis.getCdNucleus() ) )
				{
					currents.set(j, current);
					break;
				}
			}
		}
	}

    
	public DynamicVO getDynamicType( String cdConductanceType, String cdNucleusPre, String cdNucleus )
	{
		for(int i = 0; i < dynamicTypes.size(); i++)
		{
			DynamicVO vo = (DynamicVO)dynamicTypes.get(i);
			
			if( vo.getCdConductanceType().equals( cdConductanceType ) &&
				vo.getCdNucleusPre().equals( cdNucleusPre ) &&  
				vo.getCdNucleus().equals( cdNucleus )  )
			{
				return vo;
			}
		}
		
		return null;
	}
	
	
	public void setDynamicType(DynamicVO vo)
	{
		boolean found = false;
		
		for(int i = 0; i < dynamicTypes.size(); i++)
		{
			DynamicVO voList = (DynamicVO)dynamicTypes.get(i);
			
			if( vo.getCdConductanceType().equals( voList.getCdConductanceType() ) &&
				vo.getCdNucleusPre().equals( voList.getCdNucleusPre() ) &&  
				vo.getCdNucleus().equals( voList.getCdNucleus() )  )
			{
				dynamicTypes.set(i, vo);
				found = true;
				break;
			}
		}
		
		if( found == false )
		{
			dynamicTypes.add(vo);
		}
	}
	
	
	public NerveVO getNerve(String cdNerve) 
	{
		NerveVO ret = null;
		
		for(int i = 0; i < nerves.size(); i++)
		{
			ret = (NerveVO)nerves.get(i);
			
			if( ret.getCdNerve().equals( cdNerve ) )
			{
				return ret;
			}
		}

		return ret;
	}
	
	
	public ModulatingSignal getModulationSignal( String cdNeuronType, String cdNucleus )
	{
		ModulatingSignal signal = null;
		
		for(int i =0; i < modulatingSignals.size(); i++)
		{
			ModulatingSignal listSignal = (ModulatingSignal)modulatingSignals.get(i);
			
			if( listSignal.getCdNeuronType().equals( cdNeuronType ) && 
				listSignal.getCdNucleus().equals( cdNucleus ) )
			{
				signal = listSignal;
				break;
			}
		}
		
		if( signal == null )
		{
			signal = new ModulatingSignal(cdNeuronType, cdNucleus);
		}
		
		return signal;
	}

	
	public double getMiscellaneous(String property)
	{
		for(int i = 0; i < miscellaneous.size(); i++)
		{
			MiscellaneousVO vo = (MiscellaneousVO)miscellaneous.get(i);
			
			if( vo.getProperty().equals( property ) )
			{
				return vo.getValue();
			}
		}

		return 0;
	}
	

	public void setMiscellaneous(String property, double value)
	{
		for(int i = 0; i < miscellaneous.size(); i++)
		{
			MiscellaneousVO vo = (MiscellaneousVO)miscellaneous.get(i);
			
			if( vo.getProperty().equals( property ) )
			{
				vo.setValue( value );
			}
		}
	}
	
	
	
	public double getStep()
	{
		return getMiscellaneous( ReMoto.step );
	}

		
	public List getListSamples() 
	{
		List list = new ArrayList();
		
		list.add( new Sample( Double.toString(1.0/getStep()), 1.0/getStep() ) );
		list.add( new Sample( Double.toString(0.4/getStep()), 0.4/getStep() ) );
		list.add( new Sample( Double.toString(0.2/getStep()), 0.2/getStep() ) );
		
		return list;
	}
	
	
	public void placeMns(String cdNucleus)
	{
		

	}

	
	// ------------------------
	// -- Simulation properties
	
    public GeneralVO getGeneral() {
		return general;
	}
    
	public void setGeneral(GeneralVO vo) 
	{
		this.general = vo;
	}
	
	public double getTFin() {
		return general.getTFin();
	}
	
	public void setTFin(double fin) 
	{
		general.setTFin( fin );
	}

	public String getDescription() {
		return general.getDescription();
	}
	
	public void setDescription(String description) 
	{
		general.setDescription( description );
	}
	
	public String getName() {
		return general.getName();
	}
	
	public void setName(String name) 
	{
		general.setName( name );
	}
	
	public int getId() {
		return general.getId();
	}
	
	public void setId(int idConfiguration) 
	{
		general.setId( idConfiguration );
	}
	
	public String getCdUser() {
		return general.getCdUser();
	}
	
	public void setCdUser(String cdUser) 
	{
		general.setCdUser( cdUser );
	}
	
	// Always true: no more used
	public boolean isMerge() {
		return true;
	}
	
	// Always true: no more used
	public void setMerge(boolean merge) 
	{
		general.setMerge( true );
	}
	
	public boolean isKeepProperties() {
		return general.isKeepProperties();
	}

	public void setKeepProperties(boolean keepProperties) {
		general.setKeepProperties( keepProperties );
	}

	public boolean isStoreResults() {
		return general.isStoreResults();
	}

	public void setStoreResults(boolean store) {
		general.setStoreResults( store );
	}

	public boolean isStoreSignals() {
		return general.isStoreSignals();
	}

	public void setStoreSignals(boolean store) {
		general.setStoreSignals( store );
	}


	// --------------------
	// -- Common properties
	
	public List getNeuronTypes() {
		return neuronTypes;
	}
	
	public void setNeuronTypes(List neurons) 
	{
		this.neuronTypes = neurons;
	}
	
	public List getMotorunitsTypes() {
		return motorunitsTypes;
	}
	
	public void setMotorunitsTypes(List muTypes) 
	{
		this.motorunitsTypes = muTypes;
	}

	public List getCategories() {
		return categories;
	}

	public void setCategories(List categories) 
	{
		this.categories = categories;
	}

	public ResultVO getResult() {
		return result;
	}
	
	public void setResult(ResultVO result) 
	{
		this.result = result;
	}

	public List getNuclei() {
		return nuclei;
	}
	
	public void setNuclei(List nucleus) 
	{
		this.nuclei = nucleus;
	}

	public List getNerves() {
		return nerves;
	}

	public void setNerves(List nerves) 
	{
		this.nerves = nerves;
	}

	public List getCurrents() {
		return currents;
	}
	
	public void setCurrents(List currents) 
	{
		this.currents = currents;
	}

	public List getModulatingSignals() {
		return modulatingSignals;
	}
	
	public void setModulatingSignals(List modulations) 
	{
		this.modulatingSignals = modulations;
	}

	public List getDynamicTypes() 
	{
		return dynamicTypes;
	}

	public void setDynamicTypes(List dynamicTypes) 
	{
		this.dynamicTypes = dynamicTypes;
	}

	public Hashtable getSynapseTypes() {
		return synapseTypes;
	}
	
	public void setSynapseTypes(Hashtable conductanceTypes) 
	{
		this.synapseTypes = conductanceTypes;
	}

	public Hashtable getMarcovTypes() {
		return marcovTypes;
	}
	
	public void setMarcovTypes(Hashtable markovTypes) 
	{
		this.marcovTypes = markovTypes;
	}

	public List getMiscellaneous() {
		return miscellaneous;
	}
	
	public void setMiscellaneous(List miscellaneous) 
	{
		this.miscellaneous = miscellaneous;
	}


	public boolean isChangedConfiguration() {
		return changedConfiguration;
	}


	public void setChangedConfiguration(boolean configurationChanged) {
		this.changedConfiguration = configurationChanged;
	}


	public int getMuDistribution() {
		return muDistribution;
	}


	public void setMuDistribution(int muDistribution) {
		this.muDistribution = muDistribution;
	}


	public Hashtable getMuPresetPosition() {
		return muPresetPosition;
	}


	public void setMuPresetPosition(Hashtable muPresetPosition) {
		this.muPresetPosition = muPresetPosition;
	}
	
	
}