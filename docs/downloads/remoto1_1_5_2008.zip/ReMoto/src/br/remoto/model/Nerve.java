package br.remoto.model;


import br.remoto.model.vo.NerveVO;


public class Nerve extends NerveVO
{
	private static final long serialVersionUID = 1L;

	protected double intensity;

	
	public Nerve()
	{
	}
	
	
	public Nerve(NerveVO vo, double step)
	{
		this.cdNerve = vo.getCdNerve();
		this.tini = vo.getTini();
		this.tfin = vo.getTfin();
		this.amp = vo.getAmp();
		this.freq = vo.getFreq();
		this.active = vo.isActive();
		this.index = vo.getIndex();
		this.stimulusSpinalEntry = vo.getStimulusSpinalEntry();
		this.stimulusEndPlate = vo.getStimulusEndPlate(); 
		this.setPaired( vo.isPaired() );
		this.setDelayPaired( vo.getDelayPaired() );
		this.setAmpPaired( vo.getAmpPaired() );
		
		if( freq < 1000/ReMoto.T_MAX )
			freq = 1;
		else if( freq > 1000/step )
			freq = 1000/step;

		if( freqPaired < 1000/ReMoto.T_MAX )
			freqPaired = freq;
	}
	
	
	public void atualize(double t)
	{
		// rcisi@03092007 ??? retirar depois do teste de step response das RCs
		//if( t > 500 )
		//	freq = 33;
		
		intensity = 0;

		if( t < tini || t > tfin )
			return;
		
		double period = 1000.0/freq;
		int cycle = (int)( (t - tini) / period );
		double start = tini + cycle * period;
		double finish = start + ReMoto.pulseWidth;
		
		if( t > start && t < finish + ReMoto.T_TOLERANCE )
			intensity = amp;
		
		if( paired == true )
			atualizePaired(t);
	}
	
	
	public void atualizePaired(double t)
	{
		double tIniPaired = tini + delayPaired;
		
		if( t < tIniPaired || t > tfin )
			return;
		
		double period = 1000.0/freqPaired;
		int cycle = (int)( (t - tIniPaired) / period );
		double start = tIniPaired + cycle * period;
		double finish = start + ReMoto.pulseWidth;
		
		if( t > start && t < finish + ReMoto.T_TOLERANCE )
			intensity += ampPaired;
	}


	public double getIntensity() {
		return intensity;
	}


	public void setIntensity(double intensity) {
		this.intensity = intensity;
	}

	
}
