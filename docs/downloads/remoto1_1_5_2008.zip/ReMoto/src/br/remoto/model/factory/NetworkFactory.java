package br.remoto.model.factory;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import br.remoto.model.Configuration;
import br.remoto.model.MotorUnit;
import br.remoto.model.Muscle;
import br.remoto.model.Neuron.Neuron;
import br.remoto.model.ReMoto;
import br.remoto.model.Neuron.Interneuron;
import br.remoto.model.Neuron.Motoneuron;
import br.remoto.model.Neuron.Miscellaneous;
import br.remoto.model.vo.ConductanceVO;
import br.remoto.model.vo.MotorUnitVO;
import br.remoto.model.vo.Nucleus;
import br.remoto.model.vo.NeuronVO;
import br.remoto.util.Bias;
import br.remoto.util.Point;


public class NetworkFactory 
{

	public void createNeurons(Configuration conf, Neuron[][] neurons)
	{
		NeuronFactory neuFactory = new NeuronFactory();
    	List nuclei = conf.getNuclei();
    	List neuronTypes = conf.getNeuronTypes();
		
    	// Create only one Miscellaneous object for all neurons, in order to save memory
    	Miscellaneous misc = new Miscellaneous();

    	misc.setStep( conf.getStep() );
    	misc.setStepByTwo( conf.getStep()/2.0 );
    	misc.setStepBySix( conf.getStep()/6.0 );
    	misc.setMnSomaRefractoryPeriod( conf.getMiscellaneous( ReMoto.mnSomaRefractoryPeriod ) );  	
    	misc.setMnAxonRefractoryPeriod( conf.getMiscellaneous( ReMoto.mnAxonRefractoryPeriod ) ); 	
    	misc.setRcSomaRefractoryPeriod( conf.getMiscellaneous( ReMoto.inRcSomaRefractoryPeriod ) ); 	
    	misc.setIaInSomaRefractoryPeriod( conf.getMiscellaneous( ReMoto.inIaSomaRefractoryPeriod ) ); 	
    	misc.setIbInSomaRefractoryPeriod( conf.getMiscellaneous( ReMoto.inIbSomaRefractoryPeriod ) ); 	
    	misc.setAfAxonRefractoryPeriod( conf.getMiscellaneous( ReMoto.afAxonRefractoryPeriod ) );
		
		// --------------------------------------------------
	    // Make a loop among motor nuclei, excuding DT nuclei
    	for(int x = ReMoto.indIN_ext; x < nuclei.size(); x++)
		{
	    	Nucleus nuc = (Nucleus)nuclei.get(x);
	    	
	    	List listNeurons = new ArrayList();

			// Get references to use in MN an IN creation
	    	NeuronVO referenceS = conf.getCompleteNeuronType(nuc.getCd(), ReMoto.S);
	    	NeuronVO referenceFR = conf.getCompleteNeuronType(nuc.getCd(), ReMoto.FR);
	    	NeuronVO referenceFF = conf.getCompleteNeuronType(nuc.getCd(), ReMoto.FF);
			
			if( referenceS != null )
				getIonicConductance(conf, referenceS);

			if( referenceFR != null )
				getIonicConductance(conf, referenceFR);

			if( referenceFF != null )
				getIonicConductance(conf, referenceFF);
			
	    	// ---------------------------------------
		    // Make a loop to create neuron array pool
		    for(int n = 0; n < neuronTypes.size(); n++)
			{
				NeuronVO reference = (NeuronVO)neuronTypes.get(n);
				
				if( !reference.isActive() || reference.getQuantity() == 0 || !reference.getCdNucleus().equals( nuc.getCd() ) )
		    		continue;
				
				if( reference.getCategory().equals(ReMoto.MN) || reference.getCategory().equals(ReMoto.IN) )
				{
					getIonicConductance(conf, reference);
				}
				
				for(int index = 0; index < reference.getQuantity(); index++)
				{
					// ------------------------------------------------
					// Create neuron according to its category and type
					// ------------------------------------------------
					Neuron neu = neuFactory.create(listNeurons, conf, misc, reference, referenceS, referenceFR, referenceFF, index);
					
					// neu is null if reference is not AF, MN or IN
					if( neu == null ) 
						continue;
				    
					// Sore neuron signals
					if( conf.isStoreSignals() == true )
					{
					    // Store membrane potential for the marked indexes
				    	// # of signals per neuron = 7
					    if( neu.getCategory().equals(ReMoto.MN) &&
						    ( index + 1 == reference.getIndexStoreVm1() || index + 1 == reference.getIndexStoreVm2() ) )
					    {
						    ((Motoneuron)neu).setStoredSignals(true);
					    	((Motoneuron)neu).getSignalStore().ensureCapacity( (int)( conf.getTFin()/conf.getStep() * 7 ) ); 
					    }
					    else if( neu.getCategory().equals(ReMoto.IN) && index + 1 == reference.getIndexStoreVm1() )
					    {
					    	((Interneuron)neu).setStoredSignals(true);
					    	((Interneuron)neu).getSignalStore().ensureCapacity( (int)( conf.getTFin()/conf.getStep() * 7 ) );
					    }
					}
				    
			    	// Put neuron in the temporary array
				    listNeurons.add( neu );
				}
			}
		    
		    // Transform ArrayList in Array to speed-up simulations
		    Neuron[] arrayNucleus = new Neuron[listNeurons.size()];

		    for(int n = 0; n < listNeurons.size(); n++)
			{
				arrayNucleus[n] = (Neuron)listNeurons.get(n);
			}
			
			neurons[x] = arrayNucleus;
		}
    	
    	// Make the spatial positioning of the neurons
    	createNeuralColumn(conf, neurons);
	}

	
	private void getIonicConductance(Configuration conf, NeuronVO reference)
	{
		ConductanceVO gNaM = conf.getMarcovType(reference.getCdNucleus(), ReMoto.gNaM + "-" + reference.getType(), ReMoto.excitatory);
		ConductanceVO gNaH = conf.getMarcovType(reference.getCdNucleus(), ReMoto.gNaH + "-" + reference.getType(), ReMoto.excitatory);
		ConductanceVO gKN = conf.getMarcovType(reference.getCdNucleus(),  ReMoto.gKN  + "-" + reference.getType(), ReMoto.inhibitory);
		ConductanceVO gKQ = conf.getMarcovType(reference.getCdNucleus(),  ReMoto.gKQ  + "-" + reference.getType(), ReMoto.inhibitory);
		 
		reference.setGNaMVO( new ConductanceVO( gNaM ) );
		reference.setGNaHVO( new ConductanceVO( gNaH ) );
		reference.setGKNVO( new ConductanceVO( gKN ) );
		reference.setGKQVO( new ConductanceVO( gKQ ) );
	}
	

	// Create column in the spinal cord ventral horn, placing all simulated cells
	private void createNeuralColumn(Configuration conf, Neuron neurons[][])
	{
    	List nuclei = conf.getNuclei();
		int numS[] = new int[ neurons.length ];
		int numFR[] = new int[ neurons.length ];
		int numFF[] = new int[ neurons.length ];
		int numRC[] = new int[ neurons.length ];
		int numIaIn[] = new int[ neurons.length ];
		int numIbIn[] = new int[ neurons.length ];
		double nucleusXini[] = new double[ neurons.length ];
		double nucleusXend[] = new double[ neurons.length ];
		
    	// ------------------------
	    // Make a loop among nuclei
		// The loop begins with the index of the first regular nucleus
	    for(int x = 1; x < nuclei.size(); x++)
		{
	    	Nucleus nuc = (Nucleus)nuclei.get(x);
	    	String cdNucleus = nuc.getCd();

			numS[x] = 0;
			numFR[x] = 0;
			numFF[x] = 0;
			numRC[x] = 0;
			numIaIn[x] = 0;
			numIbIn[x] = 0;
			
			if( conf.getNeuronType(cdNucleus, ReMoto.S) != null && conf.getNeuronType(cdNucleus, ReMoto.S).isActive() )	
				numS[x] = conf.getNeuronType(cdNucleus, ReMoto.S).getQuantity();
			if( conf.getNeuronType(cdNucleus, ReMoto.FR) != null && conf.getNeuronType(cdNucleus, ReMoto.FR).isActive() )	
				numFR[x] = conf.getNeuronType(cdNucleus, ReMoto.FR).getQuantity();
			if( conf.getNeuronType(cdNucleus, ReMoto.FF) != null && conf.getNeuronType(cdNucleus, ReMoto.FF).isActive() )	
				numFF[x] = conf.getNeuronType(cdNucleus, ReMoto.FF).getQuantity();
			if( conf.getNeuronType(cdNucleus, ReMoto.RC) != null && conf.getNeuronType(cdNucleus, ReMoto.RC).isActive() )	
				numRC[x] = conf.getNeuronType(cdNucleus, ReMoto.RC).getQuantity();
			if( conf.getNeuronType(cdNucleus, ReMoto.IaIn) != null && conf.getNeuronType(cdNucleus, ReMoto.IaIn).isActive() )	
				numIaIn[x] = conf.getNeuronType(cdNucleus, ReMoto.IaIn).getQuantity();
			if( conf.getNeuronType(cdNucleus, ReMoto.IbIn) != null && conf.getNeuronType(cdNucleus, ReMoto.IbIn).isActive() )	
				numIbIn[x] = conf.getNeuronType(cdNucleus, ReMoto.IbIn).getQuantity();
			
			nucleusXini[x] = conf.getMiscellaneous( "xIni" + cdNucleus );
			nucleusXend[x] = conf.getMiscellaneous( "xEnd" + cdNucleus );
		}

		// The loop begins with the index of the first regular nucleus
		for(int x = 1; x < neurons.length; x++)
		{
			for(int y = 0; y < neurons[x].length; y++)
			{
		    	String type = neurons[x][y].getType();
				int index = neurons[x][y].getIndex();
		    	double quantity = 0;
		    	
		    	if( type.equals( ReMoto.RC ) ) 
		    		quantity = numRC[x];
		    	else if( type.equals( ReMoto.IaIn ) ) 
		    		quantity = numIaIn[x];
		    	else if( type.equals( ReMoto.IbIn ) ) 
		    		quantity = numIbIn[x];
		    	if( type.equals( ReMoto.S ) ) 
		    		quantity = numS[x] + numFR[x] + numFF[x];
		    	else if( type.equals( ReMoto.FR ) )
		    		quantity = numS[x] + numFR[x] + numFF[x];
		    	else if( type.equals( ReMoto.FF ) )
		    		quantity = numS[x] + numFR[x] + numFF[x];
		    	
		    	index--;
		    	quantity--;
		    	
		    	if( quantity <= 0  )
		    		continue;
		    	
		    	double xPosition = nucleusXini[x] + ( nucleusXend[x] - nucleusXini[x] ) * (index/quantity);
				
				neurons[x][y].setXPosition( xPosition );
			}
		}
	}

	
	public void createMuscles(Configuration conf, Neuron neurons[][], Muscle muscles[])
	{
		int ind = 0;

		for(int x = 1; x < neurons.length; x++)
		{
			if( neurons[x].length == 0 )
				continue;
			
			Neuron neu = neurons[x][0];
			
			if( neu == null )
				continue;
			
			String cdNucleus = neu.getCdNucleus();
			
			if( cdNucleus.equals( ReMoto.DT ) || cdNucleus.equals( ReMoto.IN_ext ) || cdNucleus.equals( ReMoto.IN_flex ) )
				continue;
			
			int numMNs = 0;
			
			if( conf.getNeuronType(cdNucleus, ReMoto.S).isActive() )
				numMNs = conf.getNeuronType(cdNucleus, ReMoto.S).getQuantity();
			
			if( conf.getNeuronType(cdNucleus, ReMoto.FR).isActive() )
				numMNs += conf.getNeuronType(cdNucleus, ReMoto.FR).getQuantity();
			
			if( conf.getNeuronType(cdNucleus, ReMoto.FF).isActive() )
				numMNs += conf.getNeuronType(cdNucleus, ReMoto.FF).getQuantity();
			
			MotorUnit[] motorunits = new MotorUnit[numMNs];
			int numberMu = 0;

			// Search for all MNs of the nucleus
			for(int y = 0; y < neurons[x].length; y++)
			{
		    	String category = neurons[x][y].getCategory();
				
				if( !category.equals( ReMoto.MN ) )
					continue;
				
				neu = neurons[x][y];

				if( cdNucleus.equals( neu.getCdNucleus() ) &&
					neu.getCategory().equals(ReMoto.MN) )
				{
					motorunits[numberMu++] = new MotorUnit( (Motoneuron)neu );
				}
			}
		    
		    Muscle muscle = new Muscle(cdNucleus, motorunits);

			// Set motor-units characteristics according to their sizes
			configureMotorUnits(conf, cdNucleus, motorunits);
			
			muscles[ind] = muscle;
			ind++;
		}
	}
	
	
	
	public void configureMotorUnits(Configuration conf, String cdNucleus, MotorUnit[] motorunits)
	{
		// Always true: no more used
		boolean isMerged = conf.isMerge();

		double thickness = conf.getMiscellaneous( ReMoto.thickness + cdNucleus );
		double skinLayer = conf.getMiscellaneous( ReMoto.skinLayer );
		double tauAttenuation = conf.getMiscellaneous( ReMoto.tauAttenuation );
		double cteEnlargement = conf.getMiscellaneous( ReMoto.cteEnlargement );
		
		double gPeak1 = 0, gPeak2 = 0;
		double gMax1 = 0, gMax2 = 0;
		double tPeak1 = 0, tPeak2 = 0;
		double ampEMG1 = 0, ampEMG2 = 0;
		double lambdaEMG1 = 0, lambdaEMG2 = 0;

		Hashtable muPresetPosition = conf.getMuPresetPosition();

		MotorUnitVO muS = conf.getMotorUnitType(cdNucleus, ReMoto.S);
		MotorUnitVO muFR = conf.getMotorUnitType(cdNucleus, ReMoto.FR);
		MotorUnitVO muFF = conf.getMotorUnitType(cdNucleus, ReMoto.FF);
		NeuronVO referenceS = conf.getCompleteNeuronType(cdNucleus, ReMoto.S);
		NeuronVO referenceFR = conf.getCompleteNeuronType(cdNucleus, ReMoto.FR);
		NeuronVO referenceFF = conf.getCompleteNeuronType(cdNucleus, ReMoto.FF);
		MotorUnitVO muType;
		
		for(int n = 0; n < motorunits.length; n++)
		{
			String type = motorunits[n].getType();
			String cd = motorunits[n].getCd();
			int index = motorunits[n].getIndex();
			
			// Bias is used for properties that have two values 
			double bias = 0;
			int quantity = 0;

			if( type.equals( ReMoto.S ) )
			{
				quantity = referenceS.getQuantity();
			}
			else if( type.equals( ReMoto.FR ) )
			{
				quantity = referenceFR.getQuantity();				
				index -= referenceS.getQuantity();
			}
			else
			{
				quantity = referenceFF.getQuantity();				
				index -= ( referenceS.getQuantity() + referenceFR.getQuantity() );
			}
				
			if( quantity > 1 )
				bias = (double)(index - 1)/(double)(quantity - 1);
			
			// Set order by the FB size and type for the parameters below.
			// Other parameters assume the default value
			
			// Always true: no more used
			if( isMerged )
			{
				if( type.equals( ReMoto.S ) )
				{
					gPeak1 = muS.getTwitchTension1();
					gMax1 = muS.getMaxTension1();
					tPeak1 = muS.getContractionTime1();
					ampEMG1 = muS.getAmpEMG1();
					lambdaEMG1 = muS.getLambdaEMG1();

					gPeak2 = ( muS.getTwitchTension2() + muFR.getTwitchTension1() ) / 2;
					gMax2 = ( muS.getMaxTension2() + muFR.getMaxTension1() ) / 2;
					tPeak2 = ( muS.getContractionTime2() + muFR.getContractionTime1() ) / 2;
					ampEMG2 = ( muS.getAmpEMG2() + muFR.getAmpEMG1() ) / 2;
					lambdaEMG2 = ( muS.getLambdaEMG2() + muFR.getLambdaEMG1() ) / 2;
				} 
				else if( type.equals( ReMoto.FR ) )
				{
					gPeak1 = ( muS.getTwitchTension2() + muFR.getTwitchTension1() ) / 2;
					gMax1 = ( muS.getMaxTension2() + muFR.getMaxTension1() ) / 2;
					tPeak1 = ( muS.getContractionTime2() + muFR.getContractionTime1() ) / 2;
					ampEMG1 = ( muS.getAmpEMG2() + muFR.getAmpEMG1() ) / 2;
					lambdaEMG1 = ( muS.getLambdaEMG2() + muFR.getLambdaEMG1() ) / 2;
					
					gPeak2 = ( muFR.getTwitchTension2() + muFF.getTwitchTension1() ) / 2;
					gMax2 = ( muFR.getMaxTension2() + muFF.getMaxTension1() ) / 2;
					tPeak2 = ( muFR.getContractionTime2() + muFF.getContractionTime1() ) / 2;
					ampEMG2 = ( muFR.getAmpEMG2() + muFF.getAmpEMG1() ) / 2;
					lambdaEMG2 = ( muFR.getLambdaEMG2() + muFF.getLambdaEMG1() ) / 2;
				}
				else
				{
					gPeak1 = ( muFR.getTwitchTension2() + muFF.getTwitchTension1() ) / 2;
					gMax1 = ( muFR.getMaxTension2() + muFF.getMaxTension1() ) / 2;
					tPeak1 = ( muFR.getContractionTime2() + muFF.getContractionTime1() ) / 2;
					ampEMG1 = ( muFR.getAmpEMG2() + muFF.getAmpEMG1() ) / 2;
					lambdaEMG1 = ( muFR.getLambdaEMG2() + muFF.getLambdaEMG1() ) / 2;
					
					gPeak2 = muFF.getTwitchTension2();
					gMax2 = muFF.getMaxTension2();
					tPeak2 = muFF.getContractionTime2();
					ampEMG2 = muFF.getAmpEMG2();
					lambdaEMG2 = muFF.getLambdaEMG2();
				}

				motorunits[n].getTwitchFunction().setGpeak( Bias.gradual(gPeak1, gPeak2, bias ) );
				motorunits[n].getTwitchFunction().setGmax( Bias.gradual(gMax1, gMax2, bias ) );
				motorunits[n].getTwitchFunction().setTpeak( Bias.gradual(tPeak1, tPeak2, bias ) );
				motorunits[n].setAmpEMG( Bias.gradual(ampEMG1, ampEMG2, bias ) );
				motorunits[n].setLambdaEMG( Bias.gradual(lambdaEMG1, lambdaEMG2, bias ) );
			}
			else
			{
				if( type.equals( ReMoto.S ) )
					muType = muS;
				else if( type.equals( ReMoto.FR ) )
					muType = muFR;
				else
					muType = muFF;
				
				motorunits[n].getTwitchFunction().setGpeak( Bias.gradual(muType.getTwitchTension1(), muType.getTwitchTension2(), bias ) );
				motorunits[n].getTwitchFunction().setGmax( Bias.gradual(muType.getMaxTension1(), muType.getMaxTension2(), bias ) );
				motorunits[n].getTwitchFunction().setTpeak( Bias.gradual(muType.getContractionTime1(), muType.getContractionTime2(), bias ) );
				motorunits[n].setAmpEMG( Bias.gradual(muType.getAmpEMG1(), muType.getAmpEMG2(), bias ) );
				motorunits[n].setLambdaEMG( Bias.gradual(muType.getLambdaEMG1(), muType.getLambdaEMG2(), bias ) );
			}
			
			if( conf.getMuDistribution() == ReMoto.muDistributionPreset )
			{
				Point point = (Point)muPresetPosition.get( cdNucleus + cd );
				
				if( point != null )
				{
					// Place motor-unit center in a preset position inside the muscle
					motorunits[n].presetSpatialDistribution( point.getY(), point.getZ(), thickness, skinLayer, tauAttenuation, cteEnlargement, n, motorunits.length );
				}
				else
				{
					// Place motor-unit center in a random position inside the muscle
					motorunits[n].randomSpatialDistribution( thickness, skinLayer, tauAttenuation, cteEnlargement );
				}
			}
			else if( conf.getMuDistribution() == ReMoto.muDistributionLinear )
			{
				// Place motor-unit center in a linear position inside the muscle
				motorunits[n].linearSpatialDistribution( thickness, skinLayer, tauAttenuation, cteEnlargement, n, motorunits.length );
			}
			else
			{
				// Place motor-unit center in a random position inside the muscle
				motorunits[n].randomSpatialDistribution( thickness, skinLayer, tauAttenuation, cteEnlargement );
			}
		}
	}

}
