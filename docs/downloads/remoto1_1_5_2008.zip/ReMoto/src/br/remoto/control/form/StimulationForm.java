/*
 * Created on 01/10/2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package br.remoto.control.form;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import br.remoto.model.Current;
import br.remoto.model.Nerve;


/**
 * @author rrcisi
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class StimulationForm extends ActionForm
{
	private static final long serialVersionUID = 1L;

	private List currents;
	private List nerves;
	private List nuclei;

	private String cdNucleus;
	

    public StimulationForm()
	{
		super();
	
		currents = new ArrayList();
		nerves = new ArrayList();
	}

	public void reset(ActionMapping map, HttpServletRequest req)
	{
		super.reset(map, req);
		
		currents = new ArrayList();
        nerves = new ArrayList();
	}
	
	public ActionErrors validate(ActionMapping map, HttpServletRequest req)
	{
		return super.validate(map, req);
	}
    
    public Nerve getNerve(int index)
    {
    	while(nerves.size() <= index)
    	{
    		nerves.add(new Nerve());
    	}

    	return (Nerve) nerves.get(index);
	}
    
    public Current getCurrent(int index)
    {
        while(currents.size() <= index)
        {
        	currents.add(new Current());
        }

        return (Current) currents.get(index);
    }

	public String getCdNucleus() {
		return cdNucleus;
	}

	public void setCdNucleus(String cdNucleus) {
		this.cdNucleus = cdNucleus;
	}

	public List getCurrents() {
		return currents;
	}

	public void setCurrents(List currents) {
		this.currents = currents;
	}

	public List getNerves() {
		return nerves;
	}

	public void setNerves(List nerves) {
		this.nerves = nerves;
	}

	public List getNuclei() {
		return nuclei;
	}

	public void setNuclei(List nuclei) {
		this.nuclei = nuclei;
	}

    
}
