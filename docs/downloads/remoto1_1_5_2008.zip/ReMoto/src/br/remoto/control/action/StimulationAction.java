
package br.remoto.control.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import br.remoto.control.form.StimulationForm;
import br.remoto.model.Configuration;
import br.remoto.model.Current;
import br.remoto.model.ModulatingSignal;
import br.remoto.model.ReMoto;


/**
 * @author rrcisi
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class StimulationAction extends MainAction
{
	/**
	 * Busca a lista de eventos de um determinado dia na base de dados.
	 * Se n�o houver eventos para a data especificada, retorna um formul�rio em branco.
	 */
	public ActionForward execute(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res)
	{
		ActionForward af = null;
		StimulationForm stimulationForm = (StimulationForm) form;
		Configuration conf = getConfiguration(req);
		
		String task = (String)req.getParameter("task");
		
		if( conf == null )
		{
			af = map.findForward( "noConfiguration" );
		}
		
		if( "saveStimulus".equals(task) )
		{
			setConfProperties(conf, stimulationForm);
		}

		setFormProperties(stimulationForm, conf, req);
		
		af = map.findForward( "configuration" );
		  
		return af;
	}
	
	
	private void setConfProperties(Configuration conf, StimulationForm stimulationForm)
	{
		List currents = stimulationForm.getCurrents();
		
		for(int i = 0; i < currents.size(); i++)
		{
			Current inj = (Current)currents.get(i);
			
			// Some validations
			if( inj.getAmp() > ReMoto.maxAmpCurrent )
				inj.setAmp( ReMoto.maxAmpCurrent );
			
			if( inj.getImax() > ReMoto.maxAmpCurrent )
				inj.setImax( ReMoto.maxAmpCurrent );
			
			ModulatingSignal signal = new ModulatingSignal();
			
			signal.setAmp( inj.getAmp() );
			signal.setCdSignal( inj.getCdSignal() );
			signal.setFreq( inj.getFreq() );
			signal.setTini( inj.getIni() );
			signal.setTfin( inj.getFin() );
			signal.setWidth( inj.getWidth() );
			
			inj.setSignal( signal );
		}
		
		conf.setListCurrents( currents );
		conf.setNerves( stimulationForm.getNerves() );
	}
	
	
	private void setFormProperties(StimulationForm stimulationForm, Configuration conf, HttpServletRequest req)
	{
		List nuclei = conf.getNuclei( ReMoto.MNs );
		nuclei.addAll( conf.getNuclei( ReMoto.INs ) );

		String cdNucleus = stimulationForm.getCdNucleus();
		
		// Set default value
		if( cdNucleus == null || cdNucleus.equals( "" ) || cdNucleus.equals( ReMoto.DT ) )
		{
			cdNucleus = (String)req.getSession().getAttribute( "cdNucleus" );
			
			if( cdNucleus == null || cdNucleus.equals( "" ) || cdNucleus.equals( ReMoto.DT ) )
				cdNucleus = ReMoto.SOL;
		}
		else
			req.getSession().setAttribute("cdNucleus", cdNucleus);
		
		stimulationForm.setNuclei( nuclei );
		stimulationForm.setCdNucleus( cdNucleus );
		stimulationForm.setCurrents( conf.getCurrents(cdNucleus) );
		stimulationForm.setNerves( conf.getNerves() );
	}

}
