
package br.remoto.control.action;

import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import br.remoto.control.form.InputForm;
import br.remoto.model.Configuration;
import br.remoto.model.ReMoto;
import br.remoto.model.vo.NeuronVO;


/**
 * @author rrcisi
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class InputAction extends MainAction
{
	/**
	 * Busca a lista de eventos de um determinado dia na base de dados.
	 * Se n�o houver eventos para a data especificada, retorna um formul�rio em branco.
	 */
	public ActionForward execute(ActionMapping map, ActionForm form, HttpServletRequest req, HttpServletResponse res)
	{
		ActionForward af = null;
		InputForm inputForm = (InputForm) form;
		Configuration conf = getConfiguration(req);
		
		String task = (String)req.getParameter("task");
		
		if( conf == null )
		{
			af = map.findForward( "noConfiguration" );
		}
		
		if( "saveStimulus".equals(task) )
		{
			setConfProperties(conf, inputForm);
		}

		setFormProperties(inputForm, conf, req);
		
		af = map.findForward( "configuration" );
		  
		return af;
	}
	
	
	private void setConfProperties(Configuration conf, InputForm inputForm)
	{
		conf.setChangedConfiguration( true );

		List inputs = inputForm.getInputs();
		List noises = inputForm.getNoises();
	
		for(int i = 0; i < inputs.size(); i++)
		{
			NeuronVO neu = (NeuronVO)inputs.get(i);
			
			// Some validations
			if( neu.isActive() )
			{
				if( neu.getMean() < ReMoto.minISImean )
					neu.setMean( ReMoto.minISImean );

				if( neu.getQuantity() > ReMoto.maxNeuronsPerType )
					neu.setQuantity( ReMoto.maxNeuronsPerType );
			}
		}
		
		for(int i = 0; i < noises.size(); i++)
		{
			NeuronVO neu = (NeuronVO)noises.get(i);
			
			// Validation
			if( neu.getMean() < ReMoto.minISImean / 10 )
				neu.setMean( ReMoto.minISImean / 10 );
		}
		
		conf.setListNeuronTypes( inputs );
		conf.setListNeuronTypes( noises );
	}
	
	
	private void setFormProperties(InputForm inputForm, Configuration conf, HttpServletRequest req)
	{
		inputForm.setNoises( conf.getNeuronTypes(ReMoto.DT, ReMoto.Noise) );

		List inputs = conf.getNeuronTypes(ReMoto.DT, ReMoto.TR);
		
		Collections.sort( inputs );
		
		inputForm.setInputs( inputs );
	}

}
