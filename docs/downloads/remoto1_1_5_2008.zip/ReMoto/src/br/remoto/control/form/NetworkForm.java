/*
 * Created on 01/10/2004
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package br.remoto.control.form;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import br.remoto.model.vo.NeuronVO;


/**
 * @author rrcisi
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class NetworkForm extends ActionForm
{
	private static final long serialVersionUID = 1L;

	private List neurons;
	
	
    public NetworkForm()
	{
		super();
	
		neurons = new ArrayList();
	}

	public void reset(ActionMapping map, HttpServletRequest req)
	{
		super.reset(map, req);
		
		neurons = new ArrayList();
	}
	
	public ActionErrors validate(ActionMapping map, HttpServletRequest req)
	{
		return super.validate(map, req);
	}
    
    public NeuronVO getNucleus(int index)
    {
       while(neurons.size() <= index)
       {
    	   neurons.add(new NeuronVO());
       }

       return (NeuronVO) neurons.get(index);
	}

	public List getNeurons() {
		return neurons;
	}

	public void setNeurons(List neurons) {
		this.neurons = neurons;
	}

}
