package br.remoto.teste;

import java.util.ArrayList;
import java.util.List;

import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import br.remoto.dao.ConfigurationDAO;
import br.remoto.dao.UserDAO;
import br.remoto.model.Configuration;
import br.remoto.model.Current;
import br.remoto.model.ModulatingSignal;
import br.remoto.model.Nerve;
import br.remoto.model.ReMoto;
import br.remoto.model.ResultDisplay;
import br.remoto.model.Simulation;
import br.remoto.model.vo.ResultVO;
import br.remoto.model.vo.Summary;
import br.remoto.model.vo.User;
import br.remoto.util.PlotXYLine;


// Linha de comando para execucao, a aprtir do diretorio raiz onde estao os .class:
// java -Xms900m -Xmx1000m -cp .;F:\rogerio\workspace\lib\jfreechart-1.0.6.jar;F:\rogerio\workspace\lib\jcommon-1.0.10.jar;F:\rogerio\workspace\lib\hsqldb.jar;C:\java\tomcat\lib\servlet-api.jar br.remoto.teste.TesteRC

public class TesteRC 
{
	UserDAO userDAO = new UserDAO();
	User user;
	Configuration conf;
	
	
	public TesteRC()
	{
		ReMoto.path = "C:\\java\\tomcat\\webapps\\remoto\\"; 
			
		user = userDAO.loadUser("guest", "guest");
		conf = new Configuration();
	}
		
	
	public static void main(String[] args) 
	{
		TesteRC teste = new TesteRC();
		
		teste.levantaCurvaSaturacao();
		
		//teste.levantaCurvaFI();
	}
		
	
	public void levantaCurvaSaturacao()
	{
		ConfigurationDAO simDAO = new ConfigurationDAO();
    	String cdSimulation = "1234";
		conf = simDAO.getConfiguration(1);

		double tFin = 800;

		ResultVO resultVO = new ResultVO();
		
		resultVO.setSample( 20 );
		resultVO.setOpt( ReMoto.array );
		
		conf.setTFin( tFin );
		conf.setMerge( true );

    	// Test of the MG motor nucleus
    	
    	conf.setQuantityNeuronType("MG", "S", 250);
    	conf.setQuantityNeuronType("MG", "FR", 125);
    	conf.setQuantityNeuronType("MG", "FF", 125);

    	conf.setQuantityNeuronType("LG", "S", 200);
    	conf.setQuantityNeuronType("LG", "FR", 100);
    	conf.setQuantityNeuronType("LG", "FF", 100);

    	conf.setQuantityNeuronType("SOL", "Ib", 0);
    	conf.setQuantityNeuronType("SOL", "Ia", 0);

		conf.setQuantityNeuronType("IN_ext", "RC", 900);
		conf.setQuantityNeuronType("IN_ext", "IbIn", 0);
		conf.setQuantityNeuronType("IN_ext", "IaIn", 0);

		/*
    	ConductanceVO gSrc = conf.getSynapseType("MG", "MG", "MN S-IN RC");
    	ConductanceVO gFRrc = conf.getSynapseType("MG", "MG", "MN FR-IN RC");
    	ConductanceVO gFFrc = conf.getSynapseType("MG", "MG", "MN FF-IN RC");
    	gSrc.setGmax( 2500 );
    	gFRrc.setGmax( 2500 );
    	gFFrc.setGmax( 2500 );
    	conf.setSynapseType("MG" + "MG" + "MN S-IN RC", gSrc);
    	conf.setSynapseType("MG" + "MG" + "MN FR-IN RC", gFRrc);
    	conf.setSynapseType("MG" + "MG" + "MN FF-IN RC", gFFrc);
    	*/

    	List listNerves = new ArrayList();

    	Nerve tibial = new Nerve( conf.getNerve( ReMoto.PTN ), conf.getStep() ); 
    	
    	tibial.setCdNerve( ReMoto.PTN );
    	tibial.setAmp( 20 );
    	tibial.setTini( 0 );
    	tibial.setTfin( tFin );
    	tibial.setActive( true );

		listNerves.add( tibial );
    	
    	conf.setNerves( listNerves );
    	
    	Simulation sim = new Simulation( conf, cdSimulation );
    	
		sim.createNetwork();
		sim.createInputs();
		sim.createStimulation();
		sim.createSynapses();

    	for(double freq = 5.0; freq <= 100.0; freq = freq + 5)
		{
    		List nerves = conf.getNerves();
    		
    		for(int n = 0; n < nerves.size(); n++)
    		{
    			Nerve nerve = (Nerve)nerves.get(n);
    			
    			if( nerve == null || nerve.isActive() == false )
    				continue;

    			nerve.setFreq( freq );
    		}
    		
    		sim.run();
    		
			ResultDisplay results = new ResultDisplay(conf);

			List ret = results.generateSummary(sim);
			
			System.out.print( freq + "\t" );  

			for(int j = 0; j < ret.size(); j++)
			{
				Summary summ = (Summary)ret.get(j);
				
				if( summ.getRateFirstInterval() < 0.1 )
					continue;
				
				if( summ.getCd().equals( "IN RC 1" ) ||
					summ.getCd().equals( "IN RC 100" ) ||
					summ.getCd().equals( "IN RC 200" ) ||
					summ.getCd().equals( "IN RC 300" ) ||
					summ.getCd().equals( "IN RC 400" ) ||
					summ.getCd().equals( "IN RC 500" ) ||
					summ.getCd().equals( "IN RC 600" ) ||
					summ.getCd().equals( "IN RC 700" ) ||
					summ.getCd().equals( "IN RC 800" ) ||
					summ.getCd().equals( "IN RC 900" ) )
				{
					System.out.print( summ.getRateSteadyState() + "\t" );  
				}
			}

			System.out.print( "\n" );  
		}
	}
	
	
	public void levantaCurvaFI()
	{
		ConfigurationDAO simDAO = new ConfigurationDAO();
		conf = simDAO.getConfiguration(1);

		double tFin = 5000;
		conf.setTFin( tFin );
		
		conf.setMerge( false );
		
		XYSeries serie1 = new XYSeries("1st interval");
		XYSeries serie2 = new XYSeries("2nd interval");
		XYSeries serie3 = new XYSeries("3rd interval");
		XYSeries serieSS = new XYSeries("steady state");
		
		double first = 0;
		double second = 0;
		double steady = 0;
		double third = 0;
		
		for(double i = 0.25; i <= 15; i = i + 0.25)
		{
			conf.setTFin( tFin );
			
			List currents = new ArrayList();
			
			ModulatingSignal signal = new ModulatingSignal();
			
			signal.setTini( tFin );
			
			Current inj = new Current("IN_ext", "RC", ReMoto.somaCompartment, true, i, conf.getStep(), signal); 
			currents.add( inj );

			conf.setCurrents( currents );
			
			conf.setQuantityNeuronType("MG", "S", 0);
			conf.setQuantityNeuronType("MG", "FR", 0);
			conf.setQuantityNeuronType("MG", "FF", 0);
			
			conf.setQuantityNeuronType("LG", "S", 0);
			conf.setQuantityNeuronType("LG", "FR", 0);
			conf.setQuantityNeuronType("LG", "FF", 0);
			
			conf.setQuantityNeuronType("SOL", "S", 0);
			conf.setQuantityNeuronType("SOL", "FR", 0);
			conf.setQuantityNeuronType("SOL", "FF", 0);
			conf.setQuantityNeuronType("SOL", "Ia", 0);
			conf.setQuantityNeuronType("SOL", "Ib", 0);
			
			conf.setQuantityNeuronType("TA", "S", 0);
			conf.setQuantityNeuronType("TA", "FR", 0);
			conf.setQuantityNeuronType("TA", "FF", 0);
			
			conf.setQuantityNeuronType("IN_ext", "RC", 1);
			conf.setQuantityNeuronType("IN_ext", "IaIn", 0);
			conf.setQuantityNeuronType("IN_ext", "IbIn", 0);
			
			conf.setQuantityNeuronType("IN_flex", "RC", 0);
			conf.setQuantityNeuronType("IN_flex", "IaIn", 0);
			conf.setQuantityNeuronType("IN_flex", "IbIn", 0);
			
			ResultVO result = new ResultVO();
			result.setCdNucleus( "IN_ext" );
			conf.setResult( result );
			
			Simulation sim = new Simulation( conf, "1234" );
			sim.run();

			ResultDisplay results = new ResultDisplay(conf);

			// Get results
			List ret = results.generateSummary(sim);
			
			for(int j = 0; j < ret.size(); j++)
			{
				Summary summ = (Summary)ret.get(j);
				
				if( summ.getRateFirstInterval() < 0.1 )
					continue;
				
				first = summ.getFiringRates()[0];  
				second = summ.getFiringRates()[1];  
				third = summ.getFiringRates()[2];  
				steady = summ.getRateSteadyState();  

				if( summ.getNeuronType().equals( ReMoto.RC ) )
				{
					serie1.add( i, Double.valueOf( first ) );
					serie2.add( i, Double.valueOf( second ) );
					serie3.add( i, Double.valueOf( third ) );
					serieSS.add( i, Double.valueOf( steady ) );
				}
			}
		}
		
	    XYSeriesCollection datasetRC = new XYSeriesCollection();
	    datasetRC.addSeries( serieSS );
	    datasetRC.addSeries( serie1 );
	    datasetRC.addSeries( serie2 );
	    datasetRC.addSeries( serie3 );

	    PlotXYLine.generate(datasetRC,
    						 ReMoto.path + "fi_RC.jpg",
							 "F x I relation", 
							 "injected current [nA]", 
							 "spike frequency [1/s]");
	}

}
