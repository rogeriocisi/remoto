package br.remoto.teste;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletOutputStream;

import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import br.remoto.dao.ConfigurationDAO;
import br.remoto.dao.UserDAO;
import br.remoto.model.Configuration;
import br.remoto.model.Current;
import br.remoto.model.ModulatingSignal;
import br.remoto.model.Nerve;
import br.remoto.model.Neuron.Neuron;
import br.remoto.model.ReMoto;
import br.remoto.model.ResultDisplay;
import br.remoto.model.Simulation;
import br.remoto.model.vo.ConductanceVO;
import br.remoto.model.vo.NeuronVO;
import br.remoto.model.vo.ResultVO;
import br.remoto.model.vo.Summary;
import br.remoto.model.vo.User;
import br.remoto.util.Coordenate;
import br.remoto.util.PlotXYLine;


// Linha de comando para execucao, a aprtir do diretorio raiz onde estao os .class:
// java -Xms900m -Xmx1000m -cp .;F:\rogerio\workspace\lib\jfreechart-1.0.6.jar;F:\rogerio\workspace\lib\jcommon-1.0.10.jar;F:\rogerio\workspace\lib\hsqldb.jar;C:\java\tomcat\lib\servlet-api.jar br.remoto.teste.TesteMN


public class TesteMN 
{
	UserDAO userDAO = new UserDAO();
	User user;
	Configuration conf;
	ResultDisplay results;
	Simulation sim;
	
	
	public TesteMN()
	{
		ReMoto.path = "C:\\java\\tomcat\\webapps\\remoto\\"; 
			
		user = userDAO.loadUser("guest", "guest");
		conf = new Configuration();
		results = new ResultDisplay(conf);
	}
		
	
	public static void main(String[] args) 
	{
		TesteMN teste = new TesteMN();
		
		//teste.testeAdaptacao();
		//teste.testaForce();
		//teste.testeRelexoH();
		//teste.testeSynapticNoise();
		//teste.testeRuido();
		//teste.testaOnionSkin();
		
		teste.leBD();
		
		//teste.testaCurvaFI();
		
		//teste.testeAHP();
		teste.testaOnionSkin();

		//teste.testaCurvaFV();
	}
		
	
	
	public void leBD()
	{
		ConfigurationDAO simDAO = new ConfigurationDAO();
		conf = simDAO.getConfiguration(1);
	}
	
	public void testaOnionSkin()
	{
		ConfigurationDAO simDAO = new ConfigurationDAO();
		conf = simDAO.getConfiguration(1);

		conf.setMerge( true );
		
		for(int i = 4; i <= 100; i = i + 2)
		{
			//double tFin = 5000;
			double tFin = 2000;

			conf.setTFin( tFin );
			
			List currents = new ArrayList();
			Current inj = new Current("SOL", "S", ReMoto.somaCompartment, true, i, conf.getStep(), null); 
			currents.add( inj );
			inj = new Current("SOL", "FR", ReMoto.somaCompartment, true, i, conf.getStep(), null); 
			currents.add( inj );
			inj = new Current("SOL", "FF", ReMoto.somaCompartment, true, i, conf.getStep(), null); 
			currents.add( inj );

			conf.setCurrents( currents );
			
			conf.setQuantityNeuronType("SOL", "S", 3);
			conf.setQuantityNeuronType("SOL", "FR", 3);
			conf.setQuantityNeuronType("SOL", "FF", 3);
			conf.setQuantityNeuronType("SOL", "Ia", 0);
			conf.setQuantityNeuronType("SOL", "Ib", 0);

			conf.setQuantityNeuronType("IN_ext", "RC", 0);
			conf.setQuantityNeuronType("IN_ext", "IaIn", 0);
			conf.setQuantityNeuronType("IN_ext", "IbIn", 0);

			ResultVO result = new ResultVO();
			result.setCdNucleus( "SOL" );
			conf.setResult( result );
			
			sim = new Simulation( conf, "1234" );
			sim.run();

			// Get results
			//double force = results.getMeanMuscleForce(sim);  
			List ret = results.generateSummary(sim);
			
			for(int j = 0; j < ret.size(); j++)
			{
				Summary summ = (Summary)ret.get(j);
				
				if( !summ.getNeuronType().equals( "S" ) &&
					!summ.getNeuronType().equals( "FR" ) &&
					!summ.getNeuronType().equals( "FF" ) )
				{
					continue;
				}

				if( summ.getRateSteadyState() < 0.1 )
					continue;

				//double forceMU = results.getMeanMotorUnitForce(sim, summ.getCd());  
				//System.out.println( summ.getIndex() + "\t" + i + "\t" + forceMU + "\t" + force + "\t" + summ.getSpikeFrequency() + ";" );  

				//System.out.println( i + "\t" + summ.getRateFirstInterval() );
				
				System.out.println( summ.getCd() + "\t" + i + "\t" + summ.getRateSteadyState() );  
			}
		}
	}
		
	
	public void testaForce()
	{
		ConfigurationDAO simDAO = new ConfigurationDAO();

		conf = simDAO.getConfiguration(2);

		double tFin = 500;

		ModulatingSignal signal = new ModulatingSignal();
		
		signal.setTfin( tFin );
		
		Current inj = new Current("MG", "S", ReMoto.somaCompartment, false, 100, conf.getStep(), signal); 
		
		List currents = new ArrayList();
		currents.add( inj );

		conf.setCurrents( currents );
		conf.setTFin( tFin );
		
		ResultVO result = new ResultVO();
		
		result.setCdNucleus( "MG" );
		result.setOpt( ReMoto.chart );
		result.setTask( ReMoto.force );
		result.setCdForce( "MN S 2" );
		
		conf.setResult( result );
		
		sim = new Simulation( conf, "1234" );
		sim.run();

		results.generateResults(sim, (ServletOutputStream)null);  
	}
	
	
	public void testeAHP()
	{
		conf.setQuantityNeuronType("MG", "S", 1);
		conf.setQuantityNeuronType("MG", "FR", 0);
		conf.setQuantityNeuronType("MG", "FF", 0);
		conf.setQuantityNeuronType("LG", "S", 0);
		conf.setQuantityNeuronType("LG", "FR", 0);
		conf.setQuantityNeuronType("LG", "FF", 0);
		conf.setQuantityNeuronType("Sol", "S", 0);
		conf.setQuantityNeuronType("Sol", "FR", 0);
		conf.setQuantityNeuronType("Sol", "FF", 0);
		conf.setQuantityNeuronType("TA", "S", 0);
		conf.setQuantityNeuronType("TA", "FR", 0);
		conf.setQuantityNeuronType("TA", "FF", 0);
		
		List lista = (ArrayList)conf.getNeuronIonicConductances( "MG", "S" );
		
		for(int i = 0; i < lista.size(); i++)
		{
			ConductanceVO g = (ConductanceVO)lista.get(i);
			
			if( g.getCdConductanceType().indexOf( "Ks" ) > 0 )
			{
				g.setGmax( 0.58 );
				g.setTpeak( 17.5 );
			}
			else if( g.getCdConductanceType().indexOf( "Kf" ) > 0 )
			{
				g.setGmax( 0.66 );
				g.setTpeak( 4 );
			}
			else if( g.getCdConductanceType().indexOf( "Na" ) > 0 )
			{
				g.setGmax( 5 );
				g.setTpeak( 0.15 );
				g.setInactivePeriod( 5 );
			}
			
			lista.set(i, g);
		}
		
		conf.setSynapseTypes( lista );
		
		double tFin = 300;
		conf.setTFin( tFin );

		List currents = new ArrayList();
		
		ModulatingSignal signal = new ModulatingSignal();
		
		signal.setTini( 100.0 );
		signal.setTfin( 100.5 );
		
		Current inj = new Current("MG", "S", ReMoto.somaCompartment, true, 100, conf.getStep(), signal); 
		currents.add( inj );

		conf.setCurrents( currents );
		
		sim = new Simulation( conf, "1234" );
		sim.run();
		
		ResultVO result = new ResultVO();
		
		result.setSample( 20 );
		result.setCdNucleus( "MG" );
		result.setOpt( ReMoto.chart );
		result.setTask( ReMoto.signal );
		result.setCoordenate( new Coordenate(100, 260, -10, 1) );
		result.setCdSignal( "MN S 1" );

		conf.setResult( result );

		//results.generateResults(sim, System.out);
	}

	
	public void testaCurvaFI()
	{
		double tFin = 1000;
		conf.setTFin( tFin );
		
		conf.setMerge( true );
		
		XYSeries serieS1 = new XYSeries("1st interval");
		//XYSeries serieS2 = new XYSeries("2nd interval");
		//XYSeries serieS3 = new XYSeries("3rd interval");
		XYSeries serieSSS = new XYSeries("steady state");
		
		XYSeries serieFR1 = new XYSeries("1st interval");
		//XYSeries serieFR2 = new XYSeries("2nd interval");
		//XYSeries serieFR3 = new XYSeries("3rd interval");
		XYSeries serieFRSS = new XYSeries("steady state");
		
		XYSeries serieFF1 = new XYSeries("1st interval");
		//XYSeries serieFF2 = new XYSeries("2nd interval");
		//XYSeries serieFF3 = new XYSeries("3rd interval");
		XYSeries serieFFSS = new XYSeries("steady state");
		
		double first = 0;
		//double second = 0;
		//double third = 0;
		double steady = 0;
		
		for(double i = 4; i <= 60; i = i + 1.0)
		{
			conf.setTFin( tFin );
			
			List currents = new ArrayList();
			
			Current inj = new Current("SOL", "S", ReMoto.somaCompartment, true, i, conf.getStep(), null); 
			currents.add( inj );
			inj = new Current("SOL", "FR", ReMoto.somaCompartment, true, i, conf.getStep(), null); 
			currents.add( inj );
			inj = new Current("SOL", "FF", ReMoto.somaCompartment, true, i, conf.getStep(), null); 
			currents.add( inj );

			conf.setCurrents( currents );
			
			conf.setQuantityNeuronType("MG", "S", 0);
			conf.setQuantityNeuronType("MG", "FR", 0);
			conf.setQuantityNeuronType("MG", "FF", 0);
			
			conf.setQuantityNeuronType("LG", "S", 0);
			conf.setQuantityNeuronType("LG", "FR", 0);
			conf.setQuantityNeuronType("LG", "FF", 0);
			
			conf.setQuantityNeuronType("SOL", "S", 1);
			conf.setQuantityNeuronType("SOL", "FR", 1);
			conf.setQuantityNeuronType("SOL", "FF", 1);
			conf.setQuantityNeuronType("SOL", "Ia", 0);
			conf.setQuantityNeuronType("SOL", "Ib", 0);
			
			conf.setQuantityNeuronType("TA", "S", 0);
			conf.setQuantityNeuronType("TA", "FR", 0);
			conf.setQuantityNeuronType("TA", "FF", 0);
			
			conf.setQuantityNeuronType("IN_ext", "RC", 0);
			conf.setQuantityNeuronType("IN_ext", "IaIn", 0);
			conf.setQuantityNeuronType("IN_ext", "IbIn", 0);
			
			conf.setQuantityNeuronType("IN_flex", "RC", 0);
			conf.setQuantityNeuronType("IN_flex", "IaIn", 0);
			conf.setQuantityNeuronType("IN_flex", "IbIn", 0);
			
			
			ResultVO result = new ResultVO();
			result.setCdNucleus( "SOL" );
			conf.setResult( result );
			
			sim = new Simulation( conf, "1234" );
			sim.run();

			// Get results
			List ret = results.generateSummary(sim);
			
			for(int j = 0; j < ret.size(); j++)
			{
				Summary summ = (Summary)ret.get(j);
				
				if( summ.getRateFirstInterval() < 0.1 )
					continue;
				
				first = summ.getFiringRates()[0];  
				//second = summ.getFiringRates()[1];  
				//third = summ.getFiringRates()[2];
				steady = summ.getRateSteadyState();  

				if( summ.getNeuronType().equals( ReMoto.S ) )
				{
					serieS1.add( i, Double.valueOf( first ) );
					//serieS2.add( i, Double.valueOf( second ) );
					//serieS3.add( i, Double.valueOf( third ) );
					serieSSS.add( i, Double.valueOf( steady ) );
				}
				else if( summ.getNeuronType().equals( ReMoto.FR ) )
				{
					serieFR1.add( i, Double.valueOf( first ) );
					//serieFR2.add( i, Double.valueOf( second ) );
					//serieFR3.add( i, Double.valueOf( third ) );
					serieFRSS.add( i, Double.valueOf( steady ) );
				}
				else
				{
					serieFF1.add( i, Double.valueOf( first ) );
					//serieFF2.add( i, Double.valueOf( second ) );
					//serieFF3.add( i, Double.valueOf( third ) );
					serieFFSS.add( i, Double.valueOf( steady ) );
				}
			}
		}
		
	    XYSeriesCollection datasetS = new XYSeriesCollection();
	    datasetS.addSeries( serieSSS );
	    datasetS.addSeries( serieS1 );
	    //datasetS.addSeries( serieS2 );
	    //datasetS.addSeries( serieS3 );

	    PlotXYLine.generate(datasetS,
    						 ReMoto.path + "fi_S.jpg",
							 "F x I relation", 
							 "injected current [nA]", 
							 "spike frequency [1/s]");
		
	    XYSeriesCollection datasetFR = new XYSeriesCollection();
	    datasetFR.addSeries( serieFRSS );
	    datasetFR.addSeries( serieFR1 );
	    //datasetFR.addSeries( serieFR2 );
	    //datasetFR.addSeries( serieFR3 );

    	PlotXYLine.generate(datasetFR,
    						 ReMoto.path + "fi_FR.jpg",
							 "F x I relation", 
							 "injected current [nA]", 
							 "spike frequency [1/s]");
		
	    XYSeriesCollection datasetFF = new XYSeriesCollection();
	    datasetFF.addSeries( serieFFSS );
	    datasetFF.addSeries( serieFF1 );
	    //datasetFF.addSeries( serieFF2 );
	    //datasetFF.addSeries( serieFF3 );

    	PlotXYLine.generate(datasetFF,
    						 ReMoto.path + "fi_FF.jpg",
							 "F x I relation", 
							 "injected current [nA]", 
							 "spike frequency [1/s]");
	}

	
	public void testaCurvaFV()
	{
		double tFin = 800;
		conf.setTFin( tFin );
		
		conf.setMerge( false );
		
		XYSeries serieS1 = new XYSeries("1st interval");
		XYSeries serieS2 = new XYSeries("2nd interval");
		XYSeries serieS3 = new XYSeries("3rd interval");
		XYSeries serieS4 = new XYSeries("4th interval");
		
		XYSeries serieFR1 = new XYSeries("1st interval");
		XYSeries serieFR2 = new XYSeries("2nd interval");
		XYSeries serieFR3 = new XYSeries("3rd interval");
		XYSeries serieFR4 = new XYSeries("4th interval");
		
		XYSeries serieFF1 = new XYSeries("1st interval");
		XYSeries serieFF2 = new XYSeries("2nd interval");
		XYSeries serieFF3 = new XYSeries("3rd interval");
		XYSeries serieFF4 = new XYSeries("4th interval");
		
		double first = 0;
		double second = 0;
		double third = 0;
		double forth = 0;
		
		for(double ramp = 0.02; ramp < 2; ramp = ramp + 0.02)
		{
			conf.setTFin( tFin );
			
			List currents = new ArrayList();
			
			double amp = 100;
			double width = amp / ramp;

			ModulatingSignal signal = new ModulatingSignal();
			
			signal.setCdSignal( ReMoto.ramp );
			signal.setAmp( amp );
			signal.setWidth( width );
			signal.setTini( 0 );
			signal.setTfin( tFin );
			
			Current inj = new Current("SOL", "S", ReMoto.somaCompartment, true, 0, conf.getStep(), signal); 
			currents.add( inj );
			inj = new Current("SOL", "FR", ReMoto.somaCompartment, true, 0, conf.getStep(), signal); 
			currents.add( inj );
			inj = new Current("SOL", "FF", ReMoto.somaCompartment, true, 0, conf.getStep(), signal); 
			currents.add( inj );

			conf.setCurrents( currents );
			
			conf.setQuantityNeuronType("MG", "S", 0);
			conf.setQuantityNeuronType("MG", "FR", 0);
			conf.setQuantityNeuronType("MG", "FF", 0);
			
			conf.setQuantityNeuronType("LG", "S", 0);
			conf.setQuantityNeuronType("LG", "FR", 0);
			conf.setQuantityNeuronType("LG", "FF", 0);
			
			conf.setQuantityNeuronType("SOL", "S", 1);
			conf.setQuantityNeuronType("SOL", "FR", 1);
			conf.setQuantityNeuronType("SOL", "FF", 1);
			conf.setQuantityNeuronType("SOL", "Ia", 0);
			conf.setQuantityNeuronType("SOL", "Ib", 0);
			
			conf.setQuantityNeuronType("TA", "S", 0);
			conf.setQuantityNeuronType("TA", "FR", 0);
			conf.setQuantityNeuronType("TA", "FF", 0);
			
			conf.setQuantityNeuronType("IN_ext", "RC", 0);
			conf.setQuantityNeuronType("IN_ext", "IaIn", 0);
			conf.setQuantityNeuronType("IN_ext", "IbIn", 0);
			
			conf.setQuantityNeuronType("IN_flex", "RC", 0);
			conf.setQuantityNeuronType("IN_flex", "IaIn", 0);
			conf.setQuantityNeuronType("IN_flex", "IbIn", 0);
			
			
			ResultVO result = new ResultVO();
			result.setCdNucleus( "SOL" );
			conf.setResult( result );
			
			sim = new Simulation( conf, "1234" );
			sim.run();

			// Get results
			List ret = results.generateSummary(sim);
			
			for(int j = 0; j < ret.size(); j++)
			{
				Summary summ = (Summary)ret.get(j);
				
				if( summ.getRateFirstInterval() < 0.1 )
					continue;
				
				first = summ.getFiringRates()[0];  
				second = summ.getFiringRates()[1];  
				third = summ.getFiringRates()[2];  
				forth = summ.getFiringRates()[3];  

				if( summ.getNeuronType().equals( ReMoto.S ) )
				{
					serieS1.add( ramp, Double.valueOf( first ) );
					serieS2.add( ramp, Double.valueOf( second ) );
					serieS3.add( ramp, Double.valueOf( third ) );
					serieS4.add( ramp, Double.valueOf( forth ) );
				}
				else if( summ.getNeuronType().equals( ReMoto.FR ) )
				{
					serieFR1.add( ramp, Double.valueOf( first ) );
					serieFR2.add( ramp, Double.valueOf( second ) );
					serieFR3.add( ramp, Double.valueOf( third ) );
					serieFR4.add( ramp, Double.valueOf( forth ) );
				}
				else
				{
					serieFF1.add( ramp, Double.valueOf( first ) );
					serieFF2.add( ramp, Double.valueOf( second ) );
					serieFF3.add( ramp, Double.valueOf( third ) );
					serieFF4.add( ramp, Double.valueOf( forth ) );
				}
			}
		}
		
	    XYSeriesCollection datasetS = new XYSeriesCollection();
	    datasetS.addSeries( serieS1 );
	    datasetS.addSeries( serieS2 );
	    datasetS.addSeries( serieS3 );
	    datasetS.addSeries( serieS4 );

	    PlotXYLine.generate( datasetS,
    						 ReMoto.path + "fv_S.jpg",
							 "F x v relation", 
							 "ramp [nA/ms]", 
							 "spike frequency [1/s]");
		
	    XYSeriesCollection datasetFR = new XYSeriesCollection();
	    datasetFR.addSeries( serieFR1 );
	    datasetFR.addSeries( serieFR2 );
	    datasetFR.addSeries( serieFR3 );
	    datasetFR.addSeries( serieFR4 );

    	PlotXYLine.generate( datasetFR,
    						 ReMoto.path + "fv_FR.jpg",
							 "F x v relation", 
							 "ramp [nA/ms]", 
							 "spike frequency [1/s]");
		
	    XYSeriesCollection datasetFF = new XYSeriesCollection();
	    datasetFF.addSeries( serieFF1 );
	    datasetFF.addSeries( serieFF2 );
	    datasetFF.addSeries( serieFF3 );
	    datasetFF.addSeries( serieFF4 );

    	PlotXYLine.generate( datasetFF,
    						 ReMoto.path + "fv_FF.jpg",
							 "F x v relation", 
							 "ramp [nA/ms]", 
							 "spike frequency [1/s]");
	}
	

	/*
	public void testeRuido()
	{
		// Load configuration properties
		SimulationDAO simDAO = new SimulationDAO();
		simDAO.loadProperties(conf, user, 1);
		sim = new Simulation( "1234", conf );

		NoiseVO noise = new NoiseVO("MG", "FF", ReMoto.EXCITATORY, true, 70, 10); 
		List noises = new ArrayList();
		noises.add( noise );
		conf.setNoises( noises );
		
		List nTypes = new ArrayList();
		
		ReferenceNeuronVO ntFF = conf.getNeuronType("MG", "FF");
		ntFF.setActive(true);
		ntFF.setQuantity(1);

		ReferenceNeuronVO ntFR = conf.getNeuronType("MG", "FR");
		ntFR.setActive(false);

		ReferenceNeuronVO ntS = conf.getNeuronType("MG", "S");
		ntS.setActive(false);

		nTypes.add( ntFF );
		nTypes.add( ntFR );
		nTypes.add( ntS );

		conf.setListNeuronTypes( nTypes );
		
		sim.run();
    	
		ResultVO result = new ResultVO();
		
		result.setCdNucleus( "MG" );
		result.setTask( ReMoto.chartVm );
		result.setSample( 20 );
		result.setCdVm( "MN FF 1" );
		conf.setResult( result );

		results.generateCharts(sim);
	}
	
	
	public void testeSynapticNoise()
	{
		double T = 0.05;
		double intMax = 10000;
		double duration = intMax * T;
		
		ReferenceNeuronVO neu = new ReferenceNeuronVO();

		neu.setDistribution( ReMoto.poisson );
		neu.setIni( 0 );
		neu.setFin( duration );
		neu.setMean( 1.0 );
			
		SynapticInput noise = new SynapticInput(neu, T);

    	double t = 0;

		XYSeries serie = new XYSeries("MN S");

		for(int j = 0; j < intMax; j++)
		{
			t = j * T;
			
			serie.add( t, noise.getv .getValue(j) );
			System.out.println( t + "\t" + noise.getConductanceValue(j) );
		}
		
    	XYLineChart.generate(serie,
    						 ReMoto.path + "ruido.jpg",
							 "ru�do sin�ptico", 
							 "tempo [ms]", 
							 "corrente [nA]");
		
		
	}
	*/
	
	
	public void testeReflexoH()
	{
		// Load configuration properties
		ConfigurationDAO simDAO = new ConfigurationDAO();

		conf = simDAO.getConfiguration(1);

		conf.setTFin( 50 );

		ModulatingSignal signal = new ModulatingSignal();
		
		signal.setTfin( 1 );
		
		Current inj = new Current("MG", "S", ReMoto.somaCompartment, true, 200, conf.getStep(), signal); 
		List currents = new ArrayList();
		currents.add( inj );

		conf.setCurrents( currents );

		List nerves = new ArrayList();
		
    	Nerve nerve = new Nerve( conf.getNerve( ReMoto.PTN ), conf.getStep() ); 
    	nerve.setActive( true );

    	nerves.add( nerve );
		
		conf.setNerves( nerves );

		List nTypes = new ArrayList();
		
		NeuronVO nt = new NeuronVO();
		nt.setType( ReMoto.RC );
		nt.setCategory( ReMoto.IN );
		nt.setActive( false );
		nTypes.add( nt );

		nt = new NeuronVO();
		nt.setType( ReMoto.IaIn );
		nt.setCategory( ReMoto.IN );
		nt.setActive( false );
		nTypes.add( nt );
		
		nt = new NeuronVO();
		nt.setType( ReMoto.FR );
		nt.setCategory( ReMoto.MN );
		nt.setActive( true );
		nTypes.add( nt );
		
		nt = new NeuronVO();
		nt.setType( ReMoto.FF );
		nt.setCategory( ReMoto.MN );
		nt.setActive( false );
		nTypes.add( nt );
		
		conf.setListNeuronTypes( nTypes );

		sim = new Simulation( conf, "1234" );
		sim.run();
    	
		ResultVO result = new ResultVO();
		
		result.setCdNucleus( "MG" );
		result.setOpt( ReMoto.chart );
		result.setTask( ReMoto.EMG );
		result.setSample( 20 );
		result.setCdEMG( ReMoto.ALL_MU );
		//result.setCdEMG( "MN S 1" );
		conf.setResult( result );

		results.generateResults(sim, (ServletOutputStream)null);
	}

	
	public void testeAdaptacao()
	{
		// Load configuration properties
		ConfigurationDAO simDAO = new ConfigurationDAO();
		conf = simDAO.getConfiguration(1);
		sim = new Simulation( conf, "1234" );

		double tFin = 5000;
		conf.setTFin( tFin );

		XYSeriesCollection datasetS = new XYSeriesCollection();
		XYSeriesCollection datasetFR = new XYSeriesCollection();
		XYSeriesCollection datasetFF = new XYSeriesCollection();
		
		XYSeriesCollection datasetNumberS = new XYSeriesCollection();
		XYSeriesCollection datasetNumberFR = new XYSeriesCollection();
		XYSeriesCollection datasetNumberFF = new XYSeriesCollection();
		
		for(int i = 10; i <= 60; i=i+10)
		{
			XYSeries serieS = new XYSeries( Integer.toString(i) );
			XYSeries serieFR = new XYSeries( Integer.toString(i) );
			XYSeries serieFF = new XYSeries( Integer.toString(i) );
			
			XYSeries serieNumberS = new XYSeries( Integer.toString(i) );
			XYSeries serieNumberFR = new XYSeries( Integer.toString(i) );
			XYSeries serieNumberFF = new XYSeries( Integer.toString(i) );
			
			ModulatingSignal signal = new ModulatingSignal();
			
			signal.setTfin( 5000 );
			
			List currents = new ArrayList();
			Current inj = new Current("MG", "S", ReMoto.somaCompartment, true, i, conf.getStep(), signal); 
			currents.add( inj );

			conf.setCurrents( currents );

			sim = new Simulation( conf, "1234" );
			sim.run();
			
			System.out.println( "\nInjected current: " + conf.getCurrent("MG", "S").getImax() );  

			Neuron neurons[][] = sim.getNeurons();			
			
            for(int n = 0; n < neurons[0].length; n++)
            {
            	String type = neurons[0][n].getType();
            	
    			System.out.println( type );  

				List spikes = neurons[0][n].getTerminalSpikeTrain();
				
				double spikeAnt = 0;
				
				for(int s = 0; s < spikes.size() && s < 7; s++)
				{
					double spike = ((Double)spikes.get(s)).doubleValue();
					double f = 1/(spike - spikeAnt) * 1000;
					
					System.out.println( f );
					
					spikeAnt = ((Double)spikes.get(s)).doubleValue();
					
					if( s == 0 )
						continue;

					if( type.equals( "S" ) )
						serieS.add( spike, f );
					else if( type.equals( "FR" ) )
						serieFR.add( spike, f );
					else
						serieFF.add( spike, f );

					if( type.equals( "S" ) )
						serieNumberS.add( s, f );
					else if( type.equals( "FR" ) )
						serieNumberFR.add( s, f );
					else
						serieNumberFF.add( s, f );
				}
            }
            
            if( serieS.getItems().size() > 0 )
            {
				datasetS.addSeries( serieS );
				datasetNumberS.addSeries( serieNumberS );
            }
            
            if( serieFR.getItems().size() > 0 )
            {
            	datasetFR.addSeries( serieFR );
            	datasetNumberFR.addSeries( serieNumberFR );
            }
            
            if( serieFF.getItems().size() > 0 )
            {
            	datasetFF.addSeries( serieFF );
            	datasetNumberFF.addSeries( serieNumberFF );
            }
		}
		
    	PlotXYLine.generate(datasetS,
    						 "adaptation_S.jpg",
							 "Adaptation MN S", 
							 "time [ms]", 
							 "spike frequency [1/s]");
		
    	PlotXYLine.generate(datasetFR,
    						 "adaptation_FR.jpg",
							 "Adaptation MN FR", 
							 "time [ms]", 
							 "spike frequency [1/s]");
		
    	PlotXYLine.generate(datasetFF,
    						 "adaptation_FF.jpg",
							 "Adaptation MN FF", 
							 "time [ms]", 
							 "spike frequency [1/s]");
		
    	PlotXYLine.generate(datasetNumberS,
    						 "adaptation2_S.jpg",
							 "Adaptation MN S", 
							 "spike number", 
							 "spike frequency [1/s]");
		
    	PlotXYLine.generate(datasetNumberFR,
    						 "adaptation2_FR.jpg",
							 "Adaptation MN FR", 
							 "spike number", 
							 "spike frequency [1/s]");
		
    	PlotXYLine.generate(datasetNumberFF,
    						 "adaptation2_FF.jpg",
							 "Adaptation MN FF", 
							 "spike number", 
							 "spike frequency [1/s]");
		
	}

	
	public void setOptimalParameters(Configuration conf)
	{
		/*
		for(int i = 0; i < conf.getNeuronTypes().size(); i++)
		{
			if( ((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getType().equals("S") )
			{
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setGmax( 1.45 );
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setAmp1( 0.9 );
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setAmp2( -0.1 );
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setTau1( 28 );
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setTau2( 6 );
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setE( -10 );
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setType( "S" );
			}
			else if( ((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getType().equals("FR") )
			{
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setGmax( 1.9 );
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setAmp1( 1.5 );
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setAmp2( -0.45 );
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setTau1( 15 );
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setTau2( 3.8 );
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setE( -10 );
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setType( "FR" );
			}
			else if( ((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getType().equals("FF") )
			{
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setGmax( 0.95 );
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setAmp1( 2 );
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setAmp2( -0.65 );
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setTau1( 15 );
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setTau2( 3.1 );
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setE( -10 );
				((ReferenceNeuronVO)conf.getNeuronTypes().get(i)).getGKvo().setType( "FF" );
			}
		}
		*/
	}
	
}
