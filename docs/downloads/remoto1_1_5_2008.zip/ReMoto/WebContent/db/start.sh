setenv JAVA_HOME /usr/java
setenv CLASSPATH /dados4/rogerio/tomcat/shared/lib/hsqldb.jar
setenv LD_NOVERSION lixo
java org.hsqldb.util.DatabaseManagerSwing --url jdbc:hsqldb:file:remoto