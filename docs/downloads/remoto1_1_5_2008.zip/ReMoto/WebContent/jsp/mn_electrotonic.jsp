<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<HTML>

<BODY BGCOLOR="#FAFFFF">

<html:form action="/mn_electrotonic">

<TABLE border=0>
	<tr>
	  	<td align="center" colspan=4>
		<b><font size="4" face="Arial, Helvetica, sans-serif">Alpha Motoneurons Electrotonic Parameters</font></b>
		</td>
	</tr>
	
	<tr>
  		<td colspan=4>&nbsp;</td>
	</tr>

	<tr>
  		<td colspan=4><b>Properties of mean S, FR and FF motoneurons</b></td>
	</tr>

	<tr>
  		<td colspan=4>&nbsp;</td>
	</tr>

	<tr>
		<td valign="top">
			<TABLE border=0>
			  	<TR>
			    	<TD height=27 align="right"></TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>Somatic input resistance [MOhm]</TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>Dendritic input resistance [MOhm]</TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>Membrane time constant [ms]</TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>Rheobase [nA]</TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>Mean threshold [mV]</TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>&nbsp;</TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>gls - soma leak conductance [uS]</TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>gd_s - coupling conductance [uS]</TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>gld - dendrite leak conductance [uS]</TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>Cs - soma capacitance [nF]</TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>Cd - dendrite capacitance [nF]</TD>
			  	</TR>
		  	</TABLE>
		</td>

		<logic:iterate name="NeuronForm" property="electrotonics" id="elType" indexId="index">
		<td valign="top">
			<TABLE border=0>
			  	<TR>
				    <TD colspan=2 height=27 align=center>
					    <b><bean:write name="elType" property="type"/></b>
				    </TD>
			  	</TR>
			  	<TR>
				    <TD colspan=2 height=27 align=left>
					    <bean:write name="elType" property="rns"/>
				    </TD>
			  	</TR>
			  	<TR>
				    <TD colspan=2 height=27 align=left>
					    <bean:write name="elType" property="rnd"/>
				    </TD>
			  	</TR>
			  	<TR>
				    <TD colspan=2 height=27 align=left>
					    <bean:write name="elType" property="tauMemb"/>
				    </TD>
			  	</TR>
			  	<TR>
				    <TD colspan=2 height=27 align=left>
					    <bean:write name="elType" property="rheobase"/>
				    </TD>
			  	</TR>
			  	<TR>
				    <TD colspan=2 height=27 align=left>
					    <bean:write name="elType" property="threshold"/>
				    </TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>&nbsp;</TD>
			  	</TR>
			  	<TR>
				    <TD colspan=2 height=27 align=left>
					    <bean:write name="elType" property="gleakSoma"/>
				    </TD>
			  	</TR>
			  	<TR>
				    <TD colspan=2 height=27 align=left>
					    <bean:write name="elType" property="gcoupling"/>
				    </TD>
			  	</TR>
			  	<TR>
				    <TD colspan=2 height=27 align=left>
					    <bean:write name="elType" property="gleakDend"/>
				    </TD>
			  	</TR>
			  	<TR>
				    <TD colspan=2 height=27 align=left>
					    <bean:write name="elType" property="cs"/>
				    </TD>
			  	</TR>
			  	<TR>
				    <TD colspan=2 height=27 align=left>
					    <bean:write name="elType" property="cd"/>
				    </TD>
			  	</TR>
		  	</TABLE>
		</td>
		</logic:iterate>
	</tr>
	
	<tr>
  		<td colspan=4>&nbsp;</td>
	</tr>

	<tr>
		<td colspan=4 align=center>
			<img src="mnCircuit.jpg" border="0">
		</td>
	</tr>

</TABLE>

</html:form>

</BODY>

</HTML>
