<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<HTML>

<head>
	<LINK REL="stylesheet" HREF="style.css" TYPE="text/css">
</head>

<script>

function change(value)
{
	document.ConductanceForm.task.value = value;
	document.ConductanceForm.submit();
}

</script>

<BODY BGCOLOR="#FAFFFF">

<html:form method="post" action="/conductance">

<html:hidden name="ConductanceForm" property="task" value="save" />

<TABLE border=0>

	<tr>
	  	<td colspan=6>
		<b><font size="4" face="Arial, Helvetica, sans-serif">Voltage-dependent Conductances Parameters</font></b>
		</td>
	</tr>
	
	<tr>
  		<td colspan=6>&nbsp;</td>
	</tr>

	<tr>
		<td colspan=6><b>Pool</b>
			<html:select name="ConductanceForm" property="cdNucleus" onchange="change('change');"> 
			<html:optionsCollection name="ConductanceForm" property="nuclei" label="name" value="cd"/>
			</html:select> 
  		</td>
	</tr>
	
	<tr>
  		<td colspan=6>&nbsp;</td>
	</tr>

	<tr>
		<td colspan=6><b>Neuron</b>
			<html:select name="ConductanceForm" property="type" onchange="change('change');"> 
			<html:optionsCollection name="ConductanceForm" property="types" label="categoryType" value="type"/>
			</html:select> 
		</td>
	</tr>
	
	<tr>
  		<td colspan=6>&nbsp;</td>
	</tr>

	<logic:notEmpty name="ConductanceForm" property="conductances">
		<tr>
			<td width=70><b>Conductance</b></td>
			<td align=center width=100><b>Maximum conductance [mS/cm2]</b></td>
			<td align=center width=100><b>Nernst potential * [mV]</b></td>
			<td align=center width=100><b>Time-to-peak [ms]</b></td>
			<td align=center width=100><b>Peak value of alpha [1/ms]</b></td>
			<td align=center width=100><b>Peak value of beta [1/ms]</b></td>
		</tr>
	
		<% int i = 0; %>
	
		<logic:iterate name="ConductanceForm" property="conductances" id="conducType" indexId="index">
			<tr>
				<td> 
					<% switch(i){ 
						case 0: out.println("Na - m"); break;
						case 1: out.println("Na - h"); break;
						case 2: out.println("K fast"); break;
						case 3: out.println("K slow"); break;
					   }
					   i++;
					%>
				
				
					<html:hidden name="conducType" property="cdConductanceType" indexed="true"/>
					<html:hidden name="conducType" property="cdNucleus" indexed="true"/>
					<html:hidden name="conducType" property="cdNucleusPre" indexed="true"/>
				</td>


			    	<% if(i == 1){ %>
			    		<td align=center valign=center rowspan=2><html:text name="conducType" property="gmax" size="5" indexed="true"/></td>
					<td align=center valign=center rowspan=2><html:text name="conducType" property="e" size="4" indexed="true"/></td>
			    	<%} else if(i == 3 || i == 4){ %>
			    		<td align=center><html:text name="conducType" property="gmax" size="5" indexed="true"/></td>
					<td align=center><html:text name="conducType" property="e" size="4" indexed="true"/></td>
			    	<%}%>

			    <td align=center><html:text name="conducType" property="tpeak" size="4" indexed="true"/></td>
			    <td align=center><html:text name="conducType" property="alpha" size="4" indexed="true"/></td>
			    <td align=center><html:text name="conducType" property="beta" size="4" indexed="true"/></td>
			</tr>
		</logic:iterate>
	
	</logic:notEmpty>


<TR><TD colspan=6 align="left"><br>* with respect to resting potential</TD></TR>

	<TR><TD colspan=6 align="center"><br><input type="button" value="  apply  " onclick="submit();"></TD></TR>

</TABLE>

</html:form>

</BODY>

</HTML>
