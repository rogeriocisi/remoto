<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<HTML>

<BODY BGCOLOR="#FAFFFF">

<html:form method="post" action="/general?task=reload">

<br>&nbsp;

<TABLE border=0>

  <TR>
    <TD>Reload all properties to default values?&nbsp;&nbsp;
    	<html:submit value="  Yes  "/>
    </TD> 
  </TR>
  
</TABLE>

</html:form>

</BODY>

</HTML>
