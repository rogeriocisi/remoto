<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<HTML>

<head>
	<LINK REL="stylesheet" HREF="style.css" TYPE="text/css">
</head>

<script>

function change()
{
	document.MarkovForm.task.value = "change";
	document.MarkovForm.submit();
}

</script>

<BODY BGCOLOR="#FAFFFF">

<html:form method="post" action="/markov">

<html:hidden name="MarkovForm" property="task" value="save" />
<html:hidden name="MarkovForm" property="option" />
<html:hidden name="MarkovForm" property="cdNeuron" />

<TABLE border=0>

	<tr>
	  	<td colspan=6 align="center">
		<b><font size="4" face="Arial, Helvetica, sans-serif">Kinetic Properties</font></b>
		</td>
	</tr>
	
	<tr>
  		<td colspan=6>&nbsp;</td>
	</tr>

	<tr>
		<td colspan=6><b>Pool</b>
			<html:select name="MarkovForm" property="cdNucleus" onchange="change();"> 
			<html:optionsCollection name="MarkovForm" property="nuclei" label="name" value="cd"/>
			</html:select> 
			&nbsp;&nbsp;&nbsp;
  			<a href="synapse.do">back</a>
  		</td>
	</tr>
	
	<tr>
  		<td colspan=6>&nbsp;</td>
	</tr>

	<logic:notEmpty name="MarkovForm" property="conductances">
		<tr>
			<td align=left width=50><b>Target neuron</b></td>
			<td align=center width=70><b>synapse type</b></td>
			<td align=center width=70><b>transmitter [mM]</b></td>
			<td align=center width=80><b>time-to-peak [ms]</b></td>
			<td align=center width=80><b>forward rate [1/ms]</b></td>
			<td align=center width=80><b>backward rate [1/ms]</b></td>
			<td align=center width=80><b>potential [mV]</b></td>
		</tr>
	
		<logic:iterate name="MarkovForm" property="conductances" id="conducType" indexId="index">
			<tr>
				<td><bean:write name="conducType" property="cdConductanceType"/>
					<html:hidden name="conducType" property="cdConductanceType" indexed="true"/>
					<html:hidden name="conducType" property="cdNucleus" indexed="true"/>
					<html:hidden name="conducType" property="index" indexed="true"/>
				</td>
			    <td align=center><bean:write name="conducType" property="polarity"/></td>
			    <td align=center><html:text name="conducType" property="tmax" size="3" indexed="true"/></td>
			    <td align=center><html:text name="conducType" property="tpeak" size="3" indexed="true"/></td>
			    <td align=center><html:text name="conducType" property="alpha" size="3" indexed="true"/></td>
			    <td align=center><html:text name="conducType" property="beta" size="3" indexed="true"/></td>
			    <td align=center><html:text name="conducType" property="e" size="3" indexed="true"/></td>
			</tr>
		</logic:iterate>
	
	</logic:notEmpty>

	<TR><TD colspan=6 align="center"><br><input type="button" value="  apply  " onclick="submit();"></TD></TR>

</TABLE>

</html:form>

</BODY>

</HTML>
