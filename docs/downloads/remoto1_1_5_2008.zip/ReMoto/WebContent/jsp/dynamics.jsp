<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<html>

<head>
  <title>ReMoto - A Remote Motoneuron Network Simulator</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" > 
</head>

<script>

function goToBack()
{
	document.DynamicsForm.action = 'synapse.do';
	document.DynamicsForm.submit();
}

</script>

<body BGCOLOR="#FAFFFF">

<html:form method="post" action="/dynamics">

<html:hidden name="DynamicsForm" property="task" value="save" />

<table border="0">

	<tr>
	  <td align="center">
		<b><font size="4" face="Arial, Helvetica, sans-serif">Synaptic dynamics</font></b>
	  </td>
	</tr>

	<tr>
	  <td align="center">&nbsp;</td>
	</tr>

  	<tr>
      <td>
      
      	<table border="0">

        <tr>
          <td width="180" align="center"><font size="2" face="Arial, Helvetica, sans-serif"><b>Synapse</b></font></td>
          <td width="60" align="center"><font size="2" face="Arial, Helvetica, sans-serif">type</font></td>
          <td width="60" align="center"><font size="2" face="Arial, Helvetica, sans-serif">variation[%]</font></td>
          <td width="100" align="center"><font size="2" face="Arial, Helvetica, sans-serif">time constant[ms]</font></td>
        </tr>

        <tr>
          <td align="center"><bean:write name="DynamicsForm" property="cdConductanceType"/></td>
          <td align="center">
			<html:select name="DynamicsForm" property="dynamicType">
				<html:option value="N">none</html:option>
				<html:option value="D">Depressing</html:option>
				<html:option value="F">Facilitating</html:option>
			</html:select>
			<html:hidden name="DynamicsForm" property="cdConductanceType"/>
			<html:hidden name="DynamicsForm" property="cdNucleus"/>
			<html:hidden name="DynamicsForm" property="cdNucleusPre"/>
		  </td>
          <td align="center"><html:text name="DynamicsForm" property="variation" size="3"/></td>
          <td align="center"><html:text name="DynamicsForm" property="tau" size="3"/></td>
	    </tr>

	    </table>
	  
	  </td>
  	</tr>

  	<TR><TD align="center"><br><br>
  		<input type="button" value="  return " onclick="goToBack();">
  		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  		<input type="button" value="  apply  " onclick="submit();">
  	</TD></TR>

</table>

</html:form>

</body>

</html>
