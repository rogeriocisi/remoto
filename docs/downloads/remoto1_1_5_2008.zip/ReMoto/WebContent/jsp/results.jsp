<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ page import="java.util.*,br.remoto.model.vo.Summary" %>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<html>
<head>
  <title>ReMoto - A Remote Motoneuron Network Simulator</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" > 
</head>

<script>

function change()
{
	document.ResultsForm.action.value = "change";
	document.ResultsForm.target = "";
	document.ResultsForm.submit();
}

function generate()
{
	<logic:equal name="ResultsForm" property="opt" value="chart">
		document.ResultsForm.target = "";
	</logic:equal>
	<logic:equal name="ResultsForm" property="opt" value="file">
		document.ResultsForm.target = "_blank";
	</logic:equal>
	
	document.ResultsForm.submit();
}

</script>

<body BGCOLOR="#FAFFFF">

<html:form method="post" action="/results" >
<html:hidden name="ResultsForm" property="action" value="" />
<html:hidden name="ResultsForm" property="opt" />
<input type="hidden" name="serialNumber" value="<%=Math.random()%>">

	<table>
	  <tr>
	  	<td align="center" colspan=2>
		<b><font size="4" face="Arial, Helvetica, sans-serif">
			Simulation results
			<logic:equal name="ResultsForm" property="opt" value="chart">
				- graphics generation
			</logic:equal>
			<logic:equal name="ResultsForm" property="opt" value="file">
				- files generation
			</logic:equal>
		</font></b>
		</td>
	  </tr>

	  <tr>
	  	<td colspan=2>&nbsp;</td>
	  </tr>

	  <tr>
		<td colspan=2><b>Pool</b>
			<html:select name="ResultsForm" property="cdNucleus" onchange="change();"> 
			<html:optionsCollection name="ResultsForm" property="nuclei" label="name" value="cd"/>
			</html:select> 
		</td>
	  </tr>
		
	</table>

	<br>
	<table>
		<tr>

			<td>
				<table>

					<logic:notEmpty name="ResultsForm" property="elementsSpikes">
						<tr height=25>
							<td><html:radio name="ResultsForm" property="task" value="spikes"/></td>
							<td>Spike times</td>
						</tr>
					</logic:notEmpty>

					<logic:notEmpty name="ResultsForm" property="elementsFiringRate">
						<tr height=25>
							<td><html:radio name="ResultsForm" property="task" value="firingRate"/></td>
							<td>Firing rate</td>
						</tr>
					</logic:notEmpty>

					<logic:notEmpty name="ResultsForm" property="elementsForce">
					  	<tr height=25>
							<td><html:radio name="ResultsForm" property="task" value="force"/></td>
							<td>Force</td>
					  	</tr>
					</logic:notEmpty>
	
					<logic:notEmpty name="ResultsForm" property="elementsEMG">
						<tr height=25>
							<td><html:radio name="ResultsForm" property="task" value="EMG"/></td>
							<td>EMG</td>
						</tr>
					</logic:notEmpty>
	
					<logic:notEmpty name="ResultsForm" property="elementsHistogram">
						<tr height=25>
							<td><html:radio name="ResultsForm" property="task" value="histogram"/></td>
							<td>ISI histogram</td>
						</tr>
					</logic:notEmpty>
	
					<logic:notEmpty name="ResultsForm" property="elementsSignal">
						<tr height=25>
							<td><html:radio name="ResultsForm" property="task" value="signal"/></td>
							<td>Signal</td>
						</tr>
					</logic:notEmpty>
					<logic:equal name="ResultsForm" property="cdNucleus" value="DT">
					<logic:notEmpty name="ResultsForm" property="elementsTracts">
						<tr height=25>
							<td><html:radio name="ResultsForm" property="task" value="signal"/></td>
							<td>Signal</td>
						</tr>
					</logic:notEmpty>
					</logic:equal>
	
					<logic:notEmpty name="ResultsForm" property="elementsForce">
					<logic:equal name="ResultsForm" property="opt" value="chart">
						<logic:notEmpty name="ResultsForm" property="elementsSpikes">
							<tr height=25>
								<td><html:radio name="ResultsForm" property="task" value="spikesAndForce"/></td>
								<td>Force and spikes</td>
							</tr>

							<tr height=25>
								<td><html:radio name="ResultsForm" property="task" value="spikesAndEMG"/></td>
								<td>EMG and spikes</td>
							</tr>
						</logic:notEmpty>
					</logic:equal>
					</logic:notEmpty>
					
					<logic:equal name="ResultsForm" property="opt" value="file">
						<logic:notEmpty name="ResultsForm" property="elementsProperties">
							<tr height=25>
								<td><html:radio name="ResultsForm" property="task" value="properties"/></td>
								<td>Properties</td>
							</tr>
						</logic:notEmpty>
					</logic:equal>
					

				</table>
			</td>

			<td valign=top>
				<table>

					<logic:notEmpty name="ResultsForm" property="elementsSpikes">
						<tr height=25>
							<td valign=top>
								<html:select name="ResultsForm" property="cdSpikes"> 
									<html:optionsCollection name="ResultsForm" property="elementsSpikes" label="cd" value="cd"/>
								</html:select>
							</td>
						</tr>
					</logic:notEmpty>

					<logic:notEmpty name="ResultsForm" property="elementsFiringRate">
						<tr height=25>
							<td valign=top>
								<html:select name="ResultsForm" property="cdFiringRate"> 
									<html:optionsCollection name="ResultsForm" property="elementsFiringRate" label="cd" value="cd"/>
								</html:select>
							</td>
						</tr>
					</logic:notEmpty>

					<logic:notEmpty name="ResultsForm" property="elementsForce">
						<tr height=25>
							<td valign=top>
								<html:select name="ResultsForm" property="cdForce"> 
									<html:optionsCollection name="ResultsForm" property="elementsForce" label="cd" value="cd"/>
								</html:select>
							</td>
						</tr>
					</logic:notEmpty>
					
					<logic:notEmpty name="ResultsForm" property="elementsEMG">
						<tr height=25>
							<td valign=top>
								<html:select name="ResultsForm" property="cdEMG"> 
									<html:optionsCollection name="ResultsForm" property="elementsEMG" label="cd" value="cd"/>
								</html:select>
							</td>
						</tr>
					</logic:notEmpty>
					
					<logic:notEmpty name="ResultsForm" property="elementsHistogram">
						<tr height=25>
							<td valign=top>
								<html:select name="ResultsForm" property="cdHistogram"> 
									<html:optionsCollection name="ResultsForm" property="elementsHistogram" label="cd" value="cd"/>
								</html:select>
								max # of bins <html:text name="ResultsForm" property="numberOfBins" size="3"/>
								width <html:text name="ResultsForm" property="binWidth" size="3"/>
							</td>
						</tr>
					</logic:notEmpty>
	
					<logic:notEmpty name="ResultsForm" property="elementsSignal">
						<tr>
							<td valign=top>
								<html:select name="ResultsForm" property="whichSignal"> 
									<html:option value="Vs">soma potential</html:option>
									<html:option value="Vd">dendrite potential</html:option>
									<html:option value="g">conductance</html:option>
									<html:option value="inj">injected current</html:option>
								</html:select>
								<html:select name="ResultsForm" property="cdSignal"> 
									<html:optionsCollection name="ResultsForm" property="elementsSignal" label="cd" value="cd"/>
								</html:select>
								<html:select name="ResultsForm" property="cdConductance"> 
									<html:optionsCollection name="ResultsForm" property="elementsConductance" label="cdConductanceType" value="cdConductanceType"/>
								</html:select>
							</td>
						</tr>
					</logic:notEmpty>
					<logic:equal name="ResultsForm" property="cdNucleus" value="DT">
					<logic:notEmpty name="ResultsForm" property="elementsTracts">
						<tr>
							<td valign=top>
								<html:select name="ResultsForm" property="cdSignal"> 
									<html:optionsCollection name="ResultsForm" property="elementsTracts" label="cd" value="cd"/>
								</html:select>
							</td>
						</tr>
					</logic:notEmpty>
					</logic:equal>
					
					<logic:notEmpty name="ResultsForm" property="elementsForce">
					<logic:equal name="ResultsForm" property="opt" value="chart">
						<logic:notEmpty name="ResultsForm" property="elementsSpikes">
							<tr height=25>
								<td valign=top>(MN spikes at end-plate)
								</td>
							</tr>
							<tr height=25>
								<td valign=top>(MN spikes at end-plate)
								</td>
							</tr>
						</logic:notEmpty>
					</logic:equal>
					</logic:notEmpty>
					
					<logic:equal name="ResultsForm" property="opt" value="file">
					<logic:notEmpty name="ResultsForm" property="elementsProperties">
						<tr height=25>
							<td valign=top>
								<html:select name="ResultsForm" property="cdProperties"> 
									<html:optionsCollection name="ResultsForm" property="elementsProperties" label="cd" value="cd"/>
								</html:select>
							</td>
						</tr>
					</logic:notEmpty>
					</logic:equal>
			
				</table>
			</td>
		</tr>
		
		<tr>
			<td>
			<center><br><input type="button" value=" generate " onclick="generate();"></center>
			</td>
			<td></td>
		</tr>
		
	</table>
	
	<br><br><b>Configurations</b>
	
	<br><br>
	&nbsp;&nbsp;Sampling rate
	<html:select name="ResultsForm" property="sample"> 
	<html:optionsCollection name="ResultsForm" property="listSamples" label="label" value="value"/>
	</html:select> kHz

	<logic:notEmpty name="ResultsForm" property="elementsEMG">
		<br><br>&nbsp;&nbsp;EMG filtering &nbsp;&nbsp;&nbsp;
		low-freq <html:text name="ResultsForm" size="4" property="fcLow"/>
		high-freq <html:text name="ResultsForm" size="4" property="fcHigh"/> Hz
	</logic:notEmpty>
	<logic:empty name="ResultsForm" property="elementsEMG">
		<html:hidden name="ResultsForm" property="fcLow"/>
		<html:hidden name="ResultsForm" property="fcHigh"/>
	</logic:empty>
		
	<br>
	<table>
		<logic:notEmpty name="ResultsForm" property="elementsEMG">
			<tr>
				<td><html:radio name="ResultsForm" property="filter" value="1st2nd"/>1st order low - 2nd order high</td>
			</tr>
			
			<tr>
				<td><html:radio name="ResultsForm" property="filter" value="3rd3rd"/>3rd order low - 3rd order high</td>
			</tr>
			
			<tr>
				<td><html:radio name="ResultsForm" property="filter" value="noFiltering"/>No filtering</td>
			</tr>
		</logic:notEmpty>
			
	</table>
	
	<br>&nbsp;<html:checkbox name="ResultsForm" property="withEMGnoise"/> EMG with noise
	<br>&nbsp;<html:checkbox name="ResultsForm" property="withEMGattenuation"/> EMG with amplitude attenuation / lowpass filtering

	<br>
	<br>
	<table>
		<tr>
			<td>X axis</td>
			<td>&nbsp;&nbsp;<html:text name="ResultsForm" property="xini" size="5"/></td>
			<td>to <html:text name="ResultsForm" property="xfin" size="5"/></td>
		</tr>
		<tr>
			<td>Y axis</td>
			<td>&nbsp;&nbsp;<html:text name="ResultsForm" property="yini" size="5"/></td>
			<td>to <html:text name="ResultsForm" property="yfin" size="5"/></td>
		</tr>
	</table>

</html:form>

</body>

</html>
