<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<HTML>

<script>

function change()
{
	document.NeuronForm.task.value = "IN";
	document.NeuronForm.submit();
}

function properties()
{
	document.NeuronForm.action = 'in_electrotonic.do?task=IN';
	document.NeuronForm.submit();
}

</script>

<BODY BGCOLOR="#FAFFFF">

<html:form method="post" action="/interneuron">

<html:hidden name="NeuronForm" property="task" value="saveIN" />

<TABLE border=0>
	<tr>
	  	<td colspan=5>
		<b><font size="4" face="Arial, Helvetica, sans-serif">Interneurons Parameters</font></b>
		</td>
	</tr>
	
	<tr>
  		<td colspan=4>&nbsp;</td>
	</tr>

	<tr>
		<td colspan=4><b>Pool</b>
			<html:select name="NeuronForm" property="cdNucleus" onchange="change();"> 
			<html:optionsCollection name="NeuronForm" property="nuclei" label="name" value="cd"/>
			</html:select> 
		</td>
	</tr>
	
	<tr>
		<td valign="top">
			<TABLE border=0>
		  	<TR>
		    	<TD height=27>&nbsp;</TD>
		  	</TR>
		  	<TR>
		    	<TD height=27>Rheobase [nA]</TD>
		  	</TR>
		  	<TR>
		    	<TD height=27>&nbsp;</TD>
		  	</TR>
		  	<TR>
		    	<TD height=27>Membrane specific capacitance [uF/cm2]</TD>
		  	</TR>
		  	<TR>
		    	<TD height=27>Specific resistance [ohm.cm2]</TD>
		  	</TR>
		  	<TR>
		    	<TD height=27>Total area [um2]</TD>
		  	</TR>
		  	<TR>
		    	<TD height=10>&nbsp;</TD>
	  	    </TR>
		  	<TR>
		    	<TD height=27>Index of the IN to have signals stored</TD>
		  	</TR>
		  	</TABLE>
		</td>

		<logic:iterate name="NeuronForm" property="interneurons" id="inType" indexId="index">
		<td valign="top">
			<TABLE border=0>
			  <TR>
			    <TD colspan=2 height=27><b>&nbsp;&nbsp;
			    <bean:write name="inType" property="type"/></b>
				<html:hidden name="inType" property="type" indexed="true"/>
				<html:hidden name="inType" property="cdNucleus" indexed="true"/>
				<html:hidden name="inType" property="category" indexed="true"/>
				<html:hidden name="inType" property="quantity" indexed="true"/>
				<html:hidden name="inType" property="active" indexed="true"/>
			    </TD>
			  </TR>
			  <TR>
			    <TD height=27><html:text name="inType" property="rheobase1" size="2" indexed="true"/></TD>
			    <TD height=27><html:text name="inType" property="rheobase2" size="2" indexed="true"/></TD>
			  </TR>
		  	  <TR>
		    	<TD colspan=2 height=10>&nbsp;</TD>
		  	  </TR>
			  <TR>
			    <TD colspan=2 height=27><html:text name="inType" property="cm" size="5" indexed="true"/></TD>
			  </TR>
			  <TR>
			    <TD colspan=2 height=27><html:text name="inType" property="rmSoma1" size="5" indexed="true"/></TD>
			  </TR>
			  <TR>
			    <TD colspan=2 height=27><html:text name="inType" property="totalArea" size="5" indexed="true"/></TD>
			  </TR>
		  	  <TR>
		    	<TD colspan=2 height=10>&nbsp;</TD>
		  	  </TR>
			  <TR>
			    <TD colspan=2 height=27><html:text name="inType" property="indexStoreVm1" size="4" indexed="true"/></TD>
			  </TR>
		  	</TABLE>
		</td>
		</logic:iterate>

	</tr>

	<TR>
		<TD colspan=2 align="center"><br><input type="button" value="see properties" onclick="properties();"></TD>
		<TD colspan=2 align="center"><br><input type="button" value="  apply  " onclick="submit();"></TD>
	</TR>

</TABLE>

</html:form>

</BODY>

</HTML>
