<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<html>

<head>
	<LINK REL="stylesheet" HREF="style.css" TYPE="text/css">
</head>

<script>

function change()
{
	document.StimulusForm.task.value = "change";
	document.StimulusForm.submit();
}

</script>

<head>
  <title>ReMoto - A Remote Motoneuron Network Simulator</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" > 
</head>

<body>

<html:form method="post" action="/stimulus">

<html:hidden name="StimulusForm" property="task" value="save" />

<table border="0">
	<tr>
	  	<td>
		<b><font size="4" face="Arial, Helvetica, sans-serif">Inputs</font></b>
		</td>
	</tr>

  	<tr>
      <td>
      
      	<table border="0">
        <tr>
          <td colspan="7" height=35><font face="Arial, Helvetica, sans-serif" size="2"><b>Descending tract spike trains</b></font>
		  </td>
        </tr>
        
        <tr>
          <td width="15" align="center"></td>
          <td width="40" height=30><font size="2" face="Arial, Helvetica, sans-serif"><b>Tract</b></font></td>
          <td width="80" align="center"><font size="2" face="Arial, Helvetica, sans-serif">distribution</font></td>
          <td width="80" align="center"><font size="2" face="Arial, Helvetica, sans-serif">ISI mean[ms]</font></td>
          <td width="80" align="center"><font size="2" face="Arial, Helvetica, sans-serif">ISI std[ms]</font></td>
          <td width="50" align="center"><font size="2" face="Arial, Helvetica, sans-serif">quantity</font></td>
          <td width="50" align="center"><font size="2" face="Arial, Helvetica, sans-serif">modulation</font></td>
        </tr>

		<logic:iterate name="StimulusForm" property="inputs" id="neuronType" indexId="index">
	        <tr>
			  <td><html:checkbox name="neuronType" property="active" indexed="true"/></td>
	          <td><font face="Arial, Helvetica, sans-serif" size="2">
	          	  <bean:write name="neuronType" property="type"/></font>
				  <html:hidden name="neuronType" property="type" indexed="true"/>
				  <html:hidden name="neuronType" property="category" indexed="true"/>
				  <html:hidden name="neuronType" property="cdNucleus" indexed="true"/>
	          </td>
	          <td align="center">
				<html:select name="neuronType" property="distribution" indexed="true">
				<html:option value="P">Poisson</html:option>
				<html:option value="G">Gaussian</html:option>
				</html:select>
			  </td>
	          <td align="center"><html:text name="neuronType" property="mean" size="3" indexed="true"/></td>
	          <td align="center"><html:text name="neuronType" property="std" size="3" indexed="true"/></td>
	          <td align="center"><html:text name="neuronType" property="quantity" size="3" indexed="true"/></td>
	          <td align="center">
	          	<a href='modulation.do?cdSignal=<bean:write name="neuronType" property="type"/>&cdNucleus=<bean:write name="neuronType" property="cdNucleus"/>'>
					<bean:write name="neuronType" property="signalType"/>
	          	</a>
	          </td>
		</logic:iterate>
      </table>
      
      </td>
    </tr>

	<tr>
  		<td>&nbsp;</td>
	</tr>

	<tr>
		<td><font face="Arial, Helvetica, sans-serif" size="2">&nbsp;<b>Nucleus</b></font>
			<html:select name="StimulusForm" property="cdNucleus" onchange="change();"> 
			<html:optionsCollection name="StimulusForm" property="nuclei" label="name" value="cd"/>
			</html:select> 
		</td>
	</tr>

	<tr>
  	<td align="left">
	  <table border="0">
	    
	    <tr>
	      <td>

	      	<table border="0">
		        <tr>
		          <td colspan="4" height=35><font face="Arial, Helvetica, sans-serif" size="2"><b>Injected current</b></font></td>
		        </tr>
		        
		        <tr align="left" valign="top">
				  <td></td>
		          <td width="50" align="center"><font size="2" face="Arial, Helvetica, sans-serif"><b>Neuron</b></font></td>
		          <td width="70" align="center"><font size="2" face="Arial, Helvetica, sans-serif">compartment</font></td>
		          <td width="70" align="center"><font size="2" face="Arial, Helvetica, sans-serif">amp [nA]</font></td>
		          <td width="70" align="center"><font size="2" face="Arial, Helvetica, sans-serif">modulation</td>
		        </tr>
		      	
				<logic:iterate name="StimulusForm" property="currents" id="current" indexId="index">
			        <tr align="left" valign="top">
					  <td><html:checkbox name="current" property="active" indexed="true"/></td>
			          <td align="left"><bean:write name="current" property="cdNeuronType"/></td>
			          <td align="center">
						<html:select name="current" property="compartment" indexed="true">
						<html:option value="S">soma</html:option>
						<html:option value="D">dendrite</html:option>
						</html:select>
					  </td>
			          <td align="center"><html:text name="current" property="amp" size="3" indexed="true" /></td>
			          <td align="center">
						<a href='modulation.do?cdSignal=<bean:write name="current" property="cdNeuronType"/>&cdNucleus=<bean:write name="current" property="cdNucleus"/>'>
							<bean:write name="current" property="signalType"/>
						</a>
						<html:hidden name="current" property="cdNucleus" indexed="true" />
						<html:hidden name="current" property="cdNeuronType" indexed="true" />
						<html:hidden name="current" property="index" indexed="true" />
					  </td>
			        </tr>
				</logic:iterate>
	        </table>
	        
	      	<table border="0">
		        <tr>
		          <td colspan="3" height=35><font face="Arial, Helvetica, sans-serif" size="2"><b>Synaptic noise</b></font></td>
		        </tr>
		        
		        <tr align="left" valign="top">
				  <td></td>
		          <td width="70" align="center"><font size="2" face="Arial, Helvetica, sans-serif"><b>Noise type</b></font></td>
		          <td width="100" align="center"><font size="2" face="Arial, Helvetica, sans-serif">ISI mean [ms]</font></td>
		        </tr>
	
				<logic:iterate name="StimulusForm" property="noises" id="noise" indexId="index">
			        <tr align="left" valign="top">
					  <td><html:checkbox name="noise" property="active" indexed="true"/></td>
			          <td align="left"><bean:write name="noise" property="type"/></td>
			          <td align="center"><html:text name="noise" property="mean" size="3" indexed="true" /></td>
					  <html:hidden name="noise" property="type" indexed="true"/>
					  <html:hidden name="noise" property="category" indexed="true"/>
					  <html:hidden name="noise" property="cdNucleus" indexed="true"/>
					  <html:hidden name="noise" property="distribution" indexed="true"/>
					  <html:hidden name="noise" property="quantity" indexed="true"/>
			        </tr>
				</logic:iterate>
	        </table>

		  </td>
		</tr>
	      
<!--

	  	<tr>
	      <td>
			
	      	<table border="0">

	        <tr>
	          <td colspan="6" height=35><font face="Arial, Helvetica, sans-serif" size="2"><b>Nerve stimulation</b></font></td>
	        </tr>
	        
	        <tr align="left" valign="top">
			  <td width="15"></td>
			  <td width="60" height=30><font size="2" face="Arial, Helvetica, sans-serif"><b>Nerve</b></font></td>
			  <td width="60"><font size="2" face="Arial, Helvetica, sans-serif">start[ms]</font></td>
	          <td width="60"><font size="2" face="Arial, Helvetica, sans-serif">amp.[mA]</font></td>
	          <td width="60"><font size="2" face="Arial, Helvetica, sans-serif">dur.[ms]</font></td>
	          <td width="60"><font size="2" face="Arial, Helvetica, sans-serif">freq.[Hz]</font></td>
	        </tr>

			<logic:iterate name="StimulusForm" property="nerves" id="nerve" indexId="index">
		        <tr align="left" valign="top">
				  <td><html:checkbox name="nerve" property="active" indexed="true"/></td>
		          <td><font face="Arial, Helvetica, sans-serif" size="2">
		          	  <bean:write name="nerve" property="cdNerve"/></font>
					  <html:hidden name="nerve" property="cdNerve" indexed="true"/>
		          </td>
		          <td><html:text name="nerve" property="ini" size="2" indexed="true"/></td>
		          <td><html:text name="nerve" property="amp" size="2" indexed="true"/></td>
		          <td><html:text name="nerve" property="duration" size="2" indexed="true"/></td>
		          <td><html:text name="nerve" property="frequency" size="2" indexed="true"/></td>
		        </tr>
			</logic:iterate>

	        </table>
		  </td>
		</tr>

-->
	  </table>
	  
	</td>
  	</tr>

  	<TR><TD align="center"><br><input type="button" value="  apply  " onclick="submit();"></TD></TR>

</table>

</html:form>

</body>

</html>
