<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<html>

<head>
	<LINK REL="stylesheet" HREF="style.css" TYPE="text/css">
</head>

<script>

function change()
{
	document.InputForm.task.value = "change";
	document.InputForm.submit();
}

</script>

<head>
  <title>ReMoto - A Remote Motoneuron Network Simulator</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" > 
</head>

<body BGCOLOR="#FAFFFF">

<html:form method="post" action="/input">

<html:hidden name="InputForm" property="task" value="saveStimulus" />

<table border="0">
	<tr>
	  	<td>
		<b><font size="4" face="Arial, Helvetica, sans-serif">Synaptic drive</font></b>
		</td>
	</tr>

  	<tr>
      <td>
      
      	<table border="0">
        <tr>
          <td colspan="14" height=30 valign="bottom"><font face="Arial, Helvetica, sans-serif" size="2"><b>Descending tract spike trains</b></font>
		  </td>
        </tr>
        
        <tr>
          <td colspan="3" height=35><font face="Arial, Helvetica, sans-serif" size="2"></font></td>
          <td colspan="3" height=35 align="center"><font face="Arial, Helvetica, sans-serif" size="2"><b>Basic drive</b></font></td>
          <td colspan="1" height=35></td>
          <td colspan="7" height=35 align="center"><font face="Arial, Helvetica, sans-serif" size="2"><b>Modulation signal superimposed on the basic drive</b></font></td>
        </tr>
        
        <tr>
          <td width="15" align="center"></td>
          <td width="150"><font size="2" face="Arial, Helvetica, sans-serif"><b>Tract</b></font></td>
          <td width="90" align="center"><font size="2" face="Arial, Helvetica, sans-serif">number<br>of axons</font></td>
          <td width="70" align="center" bgcolor="#ddeedd"><font size="2" face="Arial, Helvetica, sans-serif"><br>distribution</font></td>
          <td width="60" align="center" bgcolor="#ddeedd"><font size="2" face="Arial, Helvetica, sans-serif">ISI mean[ms]</font></td>
          <td width="60" align="center" bgcolor="#ddeedd"><font size="2" face="Arial, Helvetica, sans-serif">ISI<br>std[ms]</font></td>
          <td width="10" align="center">&nbsp;</td>
          <td width="70" align="center"><font size="2" face="Arial, Helvetica, sans-serif">modulation<br>signal</font></td>
          <td width="60" align="center"><font size="2" face="Arial, Helvetica, sans-serif">target</font></td>
          <td width="55" align="center"><font size="2" face="Arial, Helvetica, sans-serif">start [ms]</font></td>
          <td width="55" align="center"><font size="2" face="Arial, Helvetica, sans-serif">stop [ms]</font></td>
          <td width="55" align="center"><font size="2" face="Arial, Helvetica, sans-serif">peak [ms or pps]</font></td>
          <td width="55" align="center"><font size="2" face="Arial, Helvetica, sans-serif">freq [Hz]</font></td>
          <td width="55" align="center"><font size="2" face="Arial, Helvetica, sans-serif">width [ms]</font></td>
        </tr>

		<logic:iterate name="InputForm" property="inputs" id="neuronType" indexId="index">
	        <tr>
			  <td><html:checkbox name="neuronType" property="active" indexed="true"/></td>
	          <td><font face="Arial, Helvetica, sans-serif" size="2">
	          	  <bean:write name="neuronType" property="tractName"/></font>
				  <html:hidden name="neuronType" property="type" indexed="true"/>
				  <html:hidden name="neuronType" property="cdNucleus" indexed="true"/>
				  <html:hidden name="neuronType" property="category" indexed="true"/>
	          </td>
	          <td align="center"><html:text name="neuronType" property="quantity" size="3" indexed="true"/></td>
	          <td align="center" bgcolor="#ddeedd">
				<html:select name="neuronType" property="distribution" indexed="true">
				<html:option value="P">Poisson</html:option>
				<html:option value="G">Gaussian</html:option>
				</html:select>
			  </td>
	          <td align="center" bgcolor="#ddeedd"><html:text name="neuronType" property="mean" size="3" indexed="true"/></td>
	          <td align="center" bgcolor="#ddeedd"><html:text name="neuronType" property="std" size="3" indexed="true"/></td>
	          <td width="15" align="center">&nbsp;</td>
	          <td align="center">
				<html:select name="neuronType" property="cdSignal" indexed="true">
					<html:option value="none">none</html:option>
					<html:option value="constant">constant</html:option>
					<html:option value="ramp">ramp</html:option>
					<html:option value="random">random</html:option>
					<html:option value="sine">sine</html:option>
					<html:option value="square">square</html:option>
				</html:select>
			  </td>
	          <td align="center">
				<html:select name="neuronType" property="modType" indexed="true">
					<html:option value="ISI">ISI</html:option>
					<html:option value="rate">rate</html:option>
				</html:select>
			  </td>
	          <td align="center"><html:text name="neuronType" property="ini" size="3" indexed="true"/></td>
	          <td align="center"><html:text name="neuronType" property="fin" size="3" indexed="true"/></td>
	          <td align="center"><html:text name="neuronType" property="amp" size="3" indexed="true"/></td>
	          <td align="center"><html:text name="neuronType" property="freq" size="3" indexed="true"/></td>
	          <td align="center"><html:text name="neuronType" property="width" size="3" indexed="true"/></td>
		</logic:iterate>
      </table>
      
      </td>
    </tr>

	<tr>
  		<td>&nbsp;</td>
	</tr>

  	<tr>
      <td>
      	<table border="0">
	        <tr align="left" valign="top">
	          <td colspan=3 height=35><font size="2" face="Arial, Helvetica, sans-serif"><b>Synaptic noise</b></font></td>
	        </tr>

	        <tr align="left" valign="top">
			  <td></td>
	          <td><font size="2" face="Arial, Helvetica, sans-serif"><b>Type</b></font></td>
	          <td width="100" align="center"><font size="2" face="Arial, Helvetica, sans-serif">ISI mean [ms]</font></td>
	        </tr>

			<logic:iterate name="InputForm" property="noises" id="noise" indexId="index">
		        <tr align="left" valign="top">
				  <td><html:checkbox name="noise" property="active" indexed="true"/></td>
		          <td align="left"><bean:write name="noise" property="tractName"/></td>
		          <td align="center"><html:text name="noise" property="mean" size="3" indexed="true" /></td>
				  <html:hidden name="noise" property="type" indexed="true"/>
				  <html:hidden name="noise" property="category" indexed="true"/>
				  <html:hidden name="noise" property="cdNucleus" indexed="true"/>
				  <html:hidden name="noise" property="distribution" indexed="true"/>
				  <html:hidden name="noise" property="quantity" indexed="true"/>
		        </tr>
			</logic:iterate>
        </table>
	  </td>
  	</tr>


  	<TR><TD align="center"><br><input type="button" value="  apply  " onclick="submit();"></TD></TR>

</table>

</html:form>

</body>

</html>
