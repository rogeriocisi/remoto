<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<HTML>

<head>
	<LINK REL="stylesheet" HREF="style.css" TYPE="text/css">
</head>

<script>

function change()
{
	document.NeuronForm.task.value = "MN";
	document.NeuronForm.submit();
}

</script>

<BODY BGCOLOR="#FAFFFF">

<html:form method="post" action="/sensory">

<html:hidden name="NeuronForm" property="task" value="saveAF" />

<TABLE border=0>
	<tr>
	  	<td colspan=2>
		<b><font size="4" face="Arial, Helvetica, sans-serif">Sensory Fibers Parameters</font></b>
		</td>
	</tr>
	
	<tr>
  		<td colspan=2>&nbsp;</td>
	</tr>

	<tr>
		<td colspan=2><b>Pool</b>
			<html:select name="NeuronForm" property="cdNucleus" onchange="change();"> 
			<html:optionsCollection name="NeuronForm" property="nuclei" label="name" value="cd"/>
			</html:select> 
		</td>
	</tr>
	
	<tr>
  		<td colspan=2>&nbsp;</td>
	</tr>

	<tr>
		<td valign="top">
			<table border=0>
			  	<TR>
			    	<TD height=27>&nbsp;</TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>&nbsp;</TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>Axon threshold [mA]</TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>Axon conduction velocity [m/s]</TD>
			  	</TR>
			  	<TR>
			    	<TD height=10>&nbsp;</TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>Nerve</TD>
			  	</TR>
	        </table>
		</td>

		<logic:iterate name="NeuronForm" property="sensories" id="sfType" indexId="index">
		<td valign="top">
			<TABLE border=0>
			  	<TR><TD colspan=2 height=27><b>&nbsp;&nbsp;
					  <bean:write name="sfType" property="type"/>
					  <html:hidden name="sfType" property="type" indexed="true"/>
					  <html:hidden name="sfType" property="category" indexed="true"/>
					  <html:hidden name="sfType" property="cdNucleus" indexed="true"/>
				  	  <html:hidden name="sfType" property="active" indexed="true"/>
				  	  <html:hidden name="sfType" property="quantity" indexed="true"/>									
					  <html:hidden name="sfType" property="cdNerve" indexed="true"/>
  	  				</TD>
		  	  	</TR>

			  	<TR>
				    <TD height=27 align=center>from</TD>
				    <TD height=27 align=center>to</TD>
			  	</TR>

			  	<TR>
				    <TD height=27><html:text name="sfType" property="axonThreshold1" size="2" indexed="true"/></TD>
				    <TD height=27><html:text name="sfType" property="axonThreshold2" size="2" indexed="true"/></TD>
			  	</TR>
			  	<TR>
			    	<TD height=27><html:text name="sfType" property="axonVelocity1" size="3" indexed="true"/></TD>
			    	<TD height=27><html:text name="sfType" property="axonVelocity2" size="3" indexed="true"/></TD>
			  	</TR>
			  	<TR>
			    	<TD height=10 colspan=2>&nbsp;</TD>
			  	</TR>
			    <TR>
			    	<TD colspan=2 height=27><bean:write name="sfType" property="cdNerve"/></TD>
			    </TR>
		  	</TABLE>
		</td>
		</logic:iterate>

	</tr>

	<TR><TD colspan=2 align="center"><br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" value="  apply  " onclick="submit();"></TD></TR>

</TABLE>

</html:form>

</BODY>

</HTML>
