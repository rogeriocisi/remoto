<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<html>

<head>
  <title>ReMoto - A Remote Motoneuron Network Simulator</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" > 
</head>

<body BGCOLOR="#FAFFFF">

<html:form method="post" action="/simulation">

<input type="hidden" name="task" value="new" />

<table border="0">
  <tr>
  	<td align="center">
	<b><font size="4" face="Arial, Helvetica, sans-serif">Simulation Start</font></b>
	</td>
  </tr>
  <tr>
  	<td>&nbsp;</td>
  </tr>
  <tr>
  	<td align="left">
	  <table border="0">
	    
	    <tr>
	      <td>
	      	<table border="0">

		        <tr>
		          <td colspan=2>&nbsp;</td>
		        </tr>
		
		        <tr align="left" valign="top">
		          <td><font face="Arial, Helvetica, sans-serif" size="2"><b>Duration</b>&nbsp;&nbsp;&nbsp;</font></td>
		          <td>
		          	<html:text name="StartForm" property="duration" size="5" /> [ms]
		          	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="   start   ">
		          </td>
		        </tr>

	  		</table>
		  </td>
		</tr>
	</table>

	</td>
  </tr>
</table>

</html:form>

</body>

</html>
