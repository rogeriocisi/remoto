<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<HTML>

<BODY BGCOLOR="#FAFFFF">

<html:form action="/in_electrotonic">

<TABLE border=0>
	<tr>
	  	<td align="center" colspan=4>
		<b><font size="4" face="Arial, Helvetica, sans-serif">Interneurons Electrotonic Parameters</font></b>
		</td>
	</tr>
	
	<tr>
  		<td colspan=4>&nbsp;</td>
	</tr>

	<tr>
		<td valign="top">
			<TABLE border=0>
			  	<TR>
			    	<TD height=27 align="right"></TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>Input resistance [MOhm]</TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>Membrane time constant [ms]</TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>Mean threshold [mV]</TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>&nbsp;</TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>gl - leak conductance [uS]</TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>Ci - interneuron capacitance [nF]</TD>
			  	</TR>
		  	</TABLE>
		</td>

		<logic:iterate name="NeuronForm" property="electrotonics" id="elType" indexId="index">
		<td valign="top">
			<TABLE border=0>
			  	<TR>
				    <TD colspan=2 height=27 align=center>
					    <b><bean:write name="elType" property="type"/></b>
				    </TD>
			  	</TR>
			  	<TR>
				    <TD colspan=2 height=27 align=left>
					    <bean:write name="elType" property="rns"/>
				    </TD>
			  	</TR>
			  	<TR>
				    <TD colspan=2 height=27 align=left>
					    <bean:write name="elType" property="tauMemb"/>
				    </TD>
			  	</TR>
			  	<TR>
				    <TD colspan=2 height=27 align=left>
					    <bean:write name="elType" property="threshold"/>
				    </TD>
			  	</TR>
			  	<TR>
			    	<TD height=27>&nbsp;</TD>
			  	</TR>
			  	<TR>
				    <TD colspan=2 height=27 align=left>
					    <bean:write name="elType" property="gleakSoma"/>
				    </TD>
			  	</TR>
			  	<TR>
				    <TD colspan=2 height=27 align=left>
					    <bean:write name="elType" property="cs"/>
				    </TD>
			  	</TR>
		  	</TABLE>
		</td>
		</logic:iterate>
	</tr>
	
	<tr>
  		<td colspan=4>&nbsp;</td>
	</tr>

</TABLE>

<br>
<img src="inCircuit.jpg" border="0">

</html:form>

</BODY>

</HTML>
