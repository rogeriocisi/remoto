<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<HTML>

<script>

function change()
{
	document.MotorUnitForm.task.value = "change";
	document.MotorUnitForm.submit();
}

</script>

<BODY BGCOLOR="#FAFFFF">

<html:form method="post" action="/motorunit">

<html:hidden name="MotorUnitForm" property="task" value="save" />

<TABLE border=0>
	<tr>
	  	<td colspan=5>
		<b><font size="4" face="Arial, Helvetica, sans-serif">Motor-Units Parameters</font></b>
		</td>
	</tr>
	
	<tr>
  		<td colspan=4>&nbsp;</td>
	</tr>

	<tr>
		<td colspan=4><b>Pool</b>
			<html:select name="MotorUnitForm" property="cdNucleus" onchange="change();"> 
			<html:optionsCollection name="MotorUnitForm" property="nuclei" label="name" value="cd"/>
			</html:select> 
		</td>
	</tr>
	
	<tr>
  		<td colspan=4>&nbsp;</td>
	</tr>

	<tr>
  		<td colspan=4>
			Motor unit distribution in a muscle section
			<html:select name="MotorUnitForm" property="distribution">
				<html:option value="1">preset</html:option>
				<html:option value="2">random</html:option>
				<html:option value="3">linear</html:option>
			</html:select>
		</td>
	</tr>

	<tr>
  		<td colspan=4>&nbsp;</td>
	</tr>

	<tr>

		<td valign="top">
			<TABLE border=0>
		  	<TR>
		    	<TD height=30>&nbsp;</TD>
		  	</TR>
		  	<TR>
		    	<TD height=30>&nbsp;</TD>
		  	</TR>
		  	<TR>
		    	<TD height=30>Twitch peak [gf]</TD>
		  	</TR>
		  	<TR>
		    	<TD height=30>Tetanic force [gf]</TD>
		  	</TR>
		  	<TR>
		    	<TD height=30>Twitch time-to-peak [ms]</TD>
		  	</TR>
		  	<TR>
		    	<TD height=30>MUAP scale factor [mV]</TD>
		  	</TR>
		  	<TR>
		    	<TD height=30>MUAP duration factor [ms]</TD>
		  	</TR>
		  	</TABLE>
		</td>

		<logic:iterate name="MotorUnitForm" property="motorunits" id="muType" indexId="index">
		<td valign="top">
			<TABLE border=0>
			  <TR>
			    <TD colspan=2 height=30 align=center><b>
			    <bean:write name="muType" property="type"/></b>
				<html:hidden name="muType" property="type" indexed="true"/>
				<html:hidden name="muType" property="cdNucleus" indexed="true"/>
			    </TD>
			  </TR>
			  <TR>
			    <TD height=30 align=center>from</TD>
			    <TD height=30 align=center>to</TD>
			  </TR>
			  <TR>
			    <TD height=30><html:text name="muType" property="twitchTension1" size="3" indexed="true"/></TD>
			    <TD height=30><html:text name="muType" property="twitchTension2" size="3" indexed="true"/></TD>
			  </TR>
			  <TR>
			    <TD height=30><html:text name="muType" property="maxTension1" size="3" indexed="true"/></TD>
			    <TD height=30><html:text name="muType" property="maxTension2" size="3" indexed="true"/></TD>
			  </TR>
			  <TR>
			    <TD height=30><html:text name="muType" property="contractionTime1" size="3" indexed="true"/></TD>
			    <TD height=30><html:text name="muType" property="contractionTime2" size="3" indexed="true"/></TD>
			  </TR>
			  <TR>
			    <TD height=30><html:text name="muType" property="ampEMG1" size="3" indexed="true"/></TD>
			    <TD height=30><html:text name="muType" property="ampEMG2" size="3" indexed="true"/></TD>
			  </TR>
			  <TR>
			    <TD height=30><html:text name="muType" property="lambdaEMG1" size="3" indexed="true"/></TD>
			    <TD height=30><html:text name="muType" property="lambdaEMG2" size="3" indexed="true"/></TD>
			  </TR>
		  	</TABLE>
		</td>
		</logic:iterate>

	</tr>

	<TR><TD colspan=4 align="center"><br><input type="button" value="  apply  " onclick="submit();"></TD></TR>

</TABLE>

</html:form>

</BODY>

</HTML>
