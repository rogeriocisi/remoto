<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ page import="br.remoto.model.vo.User" %>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<html>

<head>
	<LINK REL="stylesheet" HREF="style.css" TYPE="text/css">
</head>

<script>

function newUser()
{
	document.LoginForm.task.value = "new";
	document.LoginForm.submit();
}

function register()
{
	document.LoginForm.task.value = "register";
	document.LoginForm.submit();
}

function login()
{
	document.LoginForm.task.value = "login";
	document.LoginForm.submit();
}

function logout()
{
	document.LoginForm.task.value = "logout";
	document.LoginForm.submit();
}

function exclude()
{
	if( confirm("Are you sure deleting user's configuration?") == true )
	{
		document.LoginForm.task.value = "exclude";
		document.LoginForm.submit();
	}	
}

</script>


<head>
  <title>ReMoto - A Remote Motoneuron Network Simulator</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" > 
</head>

<body BGCOLOR="#FAFFFF">

<html:form method="post" action="/login">

<html:hidden name="LoginForm" property="task" value="login" />

<%
String msg = (String)request.getAttribute("msg");
if( msg == null ) 
	msg = "";
else
	msg = msg + "<br>&nbsp;";
%>

<table width="500" border="0">
  <tr>
  	<td align="center">
	<b><font size="4" face="Arial, Helvetica, sans-serif">User authentication</font></b>
	</td>
  </tr>
  <tr>
  	<td>&nbsp;</td>
  </tr>
  <tr>
  	<td align="left">
	  <table border="0">
	    
		<tr>
			<td>
				<%
				User user = (User)session.getAttribute("user");
				String name = (String)user.getName();
				
				if( name == null ) name = "";
				%>
				
				<br>
				<font face=verdana size=2>
				You are currently logged as: <b><%=name%></b>
			</td>
		</tr>

		<tr>
		  <td><%=msg%>&nbsp;</td>
		</tr>
	    <tr>
	      <td>
	      	<table border="0">
	
				<logic:equal name="LoginForm" property="register" value="true" >
			        <tr>
			          <td align=left><b>Name</b></td>
			          <td align=left><html:text name="LoginForm" property="nmUser" size="32"/></td>
			        </tr>
		
			        <tr>
			          <td><b>E-mail</b></td>
			          <td><html:text name="LoginForm" property="email" size="32"/></td>
			        </tr>
		
			        <tr>
			          <td><b>Institution</b></td>
			          <td><html:text name="LoginForm" property="institution" size="32"/></td>
			        </tr>
				</logic:equal>

				<tr>
		          <td></td>
		        </tr>

		        <tr>
		          <td><b>Username</b></td>
		          <td><html:text name="LoginForm" property="cdUser"/></td>
		        </tr>
	
		        <tr>
		          <td><b>Password</b></td>
		          <td>
		          	<html:password name="LoginForm" property="password"/>
					<logic:notEqual name="LoginForm" property="register" value="true" >
			          	<input type="button" value=" submit " onclick="login();">
					</logic:notEqual>
					<logic:equal name="LoginForm" property="register" value="true" >
			          	<input type="button" value=" submit " onclick="register();">
					</logic:equal>
		          </td>
		        </tr>
	
		        <tr>
		          <td colspan=2>&nbsp;</td>
		        </tr>
	
		        <tr>
		          <td colspan=2>&nbsp;</td>
		        </tr>
	
				<logic:equal name="LoginForm" property="register" value="false" >
				    <tr>
				      <td colspan=2>
							<input type="button" value="delete user" onclick="exclude();">
							&nbsp;&nbsp;&nbsp;&nbsp;
							<input type="button" value="  logout  " onclick="logout();">
					  </td>
				    </tr>
				    <tr>
				      <td colspan=2>
						<br><br><a href="#" onclick="newUser();">
							<img src="image/seta.gif" border=0> Create an account</a>
					  </td>
				    </tr>
				</logic:equal>
			    
	  		</table>
		  </td>
		</tr>

	  </table>
	  
	</td>
  </tr>
</table>


</html:form>

</body>

</html>
