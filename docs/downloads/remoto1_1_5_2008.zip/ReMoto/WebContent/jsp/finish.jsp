<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<html>
<head>
  <title>ReMoto - A Remote Motoneuron Network Simulator</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" > 
</head>

<script>

function simulate()
{
	if( confirm("Start a new simulation? (current results will be deleted)") == true )
	{
		document.SimulationForm.submit();
	}	
}

</script>

<body BGCOLOR="#FAFFFF">

<%
String start = (String)session.getAttribute("start");
String finish = (String)session.getAttribute("finish");
String duration = (String)session.getAttribute("duration");

if( start == null ) start = "";
if( finish == null ) finish = "";
if( duration == null ) duration = "200";
%>

<br><b>Simulation finished.</b>
<br><br><b>Using options on menu Results, generate charts and files with simulated data.</b>
<br><br><br>Start: <%=start%> - finish: <%=finish%> h (GMT-3)
<br><br>Percentage: 100%

<form name="SimulationForm"  method="post" action="/remoto/simulation.do">

<input type="hidden" name="task" value="new" />

<br><br><table border="0">
	    
	    <tr>
	      <td>
	      	<table border="0">

		        <tr>
		          <td colspan=2>Start a new simulation (current results will be deleted)</td>
		        </tr>
		
		        <tr>
		          <td colspan=2>&nbsp;</td>
		        </tr>
		
		        <tr align="left" valign="top">
		          <td><font face="Arial, Helvetica, sans-serif" size="2"><b>Duration</b>&nbsp;&nbsp;&nbsp;</font></td>
		          <td>
		          	<input type="text" name="duration" size="5" value="<%=duration%>"> [ms]
		          	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		          	<input type="button" value="   start   " onclick="simulate();">
		          </td>
		        </tr>

	  		</table>
		  </td>
		</tr>
	</table>

</form>

</body>
</html>
