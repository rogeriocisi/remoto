<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-nested.tld" prefix="nested"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<HTML>

<BODY BGCOLOR="#FAFFFF">

<html:form method="post" action="/network">

<html:hidden name="NeuronForm" property="task" value="save" />

<TABLE border=0>
  
  <TR>
	<TD>
	<TABLE border=0>
  
  	<TR><TD colspan=3 align="left"><b><font size="4" face="Arial, Helvetica, sans-serif">Number of neurons in each pool</font></b></TD></TR>

	
<%
int numNeurons = 5; // For Motoneuron Nuclei
int i = 0;
int j = 0;
%> 

  <logic:iterate name="NetworkForm" property="neurons" id="nucleus" indexId="index">
<% 
// Divide nucleus in two columns
if( i%numNeurons == 0 )
{
	if( j%2 == 0 )
	{
		if( i > 0 )
		{
			out.println("</TD></TR>");
			out.println("</TABLE>");
		}		
	
		out.println("<TR>");
		out.println("<TD width='270'><TABLE border=0>");
	}
	else
	{
		out.println("</TABLE></TD>");
		out.println("<TD width='270'><TABLE border=0>");
	}

	j++;
		
%>
		<tr>
			<td colspan=3 height=40><font size="2" face="Verdana, Arial, sans-serif">
				<b><bean:write name="nucleus" property="nameNucleus"/></b>
				<font>
			</td>
		</tr>
<% 
}

i++;

if( i == 21 )
{
	i = 4;
	j = 1;
	numNeurons = 3; // For Interneuron Nuclei
}

%>
		<tr>
			<td width='10'><html:checkbox name="nucleus" property="active" indexed="true"/></td>
			<td width='75'><bean:write name="nucleus" property="category"/> <bean:write name="nucleus" property="type"/></td>
			<td width='85'><html:text name="nucleus" property="quantity" size="2" indexed="true"/></td>
			<html:hidden name="nucleus" property="type" indexed="true"/>
			<html:hidden name="nucleus" property="cdNucleus" indexed="true"/>
		</tr>

  </logic:iterate>


</TABLE>

</TD>
</TR>

<TR><TD align="right"><br><input type="button" value="  apply  " onclick="submit();"></TD></TR>

</TABLE>


</html:form>

</BODY>

</HTML>
