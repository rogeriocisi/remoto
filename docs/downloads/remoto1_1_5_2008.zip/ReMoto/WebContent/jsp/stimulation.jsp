<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<html>

<head>
	<LINK REL="stylesheet" HREF="style.css" TYPE="text/css">
</head>

<script>

function change()
{
	document.StimulationForm.task.value = "change";
	document.StimulationForm.submit();
}

</script>

<head>
  <title>ReMoto - A Remote Motoneuron Network Simulator</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" > 
</head>

<body BGCOLOR="#FAFFFF">

<html:form method="post" action="/stimulation">

<html:hidden name="StimulationForm" property="task" value="saveStimulus" />

<table border="0">
	<tr>
	  	<td>
		<b><font size="4" face="Arial, Helvetica, sans-serif">Electrical stimulation</font></b>
		</td>
	</tr>

	<tr>
	  	<td align="center">&nbsp;</td>
	</tr>

  	<tr>
      <td>
      	<table border="0">

        <tr>
          <td colspan="9" height=35><font face="Arial, Helvetica, sans-serif" size="2"><b>Nerve electrical stimulation</b></font></td>
        </tr>
        
        <tr align="left" valign="top">
		  <td width="15"></td>
		  <td width="40" ><font size="2" face="Arial, Helvetica, sans-serif"><b>Nerve</b></font></td>
          <td width="60" align="center"><font size="2" face="Arial, Helvetica, sans-serif">pulse duration</font></td>
          <td width="60" align="center"><font size="2" face="Arial, Helvetica, sans-serif">start[ms]</font></td>
          <td width="60" align="center"><font size="2" face="Arial, Helvetica, sans-serif">stop[ms]</font></td>
          <td width="60" align="center"><font size="2" face="Arial, Helvetica, sans-serif">peak[mA]</font></td>
          <td width="60" align="center"><font size="2" face="Arial, Helvetica, sans-serif">freq[Hz]</font></td>
          <td width="90" align="center"><font size="2" face="Arial, Helvetica, sans-serif">distance to spinal entry [m]</font></td>
          <td width="90" align="center"><font size="2" face="Arial, Helvetica, sans-serif">distance to end plate [m]</font></td>
        </tr>

		<logic:iterate name="StimulationForm" property="nerves" id="nerve" indexId="index">
	        <tr align="left" valign="top">
			  <td><html:checkbox name="nerve" property="active" indexed="true"/></td>
	          <td><font face="Arial, Helvetica, sans-serif" size="2">
	          	  <bean:write name="nerve" property="cdNerve"/></font>
				  <html:hidden name="nerve" property="cdNerve" indexed="true"/>
	          </td>
	          <td align="center">1 ms</td>
	          <td align="center"><html:text name="nerve" property="tini" size="3" indexed="true"/></td>
	          <td align="center"><html:text name="nerve" property="tfin" size="3" indexed="true"/></td>
	          <td align="center"><html:text name="nerve" property="amp" size="3" indexed="true"/></td>
	          <td align="center"><html:text name="nerve" property="freq" size="3" indexed="true"/></td>
	          <td align="center"><html:text name="nerve" property="stimulusSpinalEntry" size="3" indexed="true"/></td>
	          <td align="center"><html:text name="nerve" property="stimulusEndPlate" size="3" indexed="true"/></td>
	        </tr>
		</logic:iterate>

        </table>
	  </td>
	</tr>

	<tr>
  		<td height=35>&nbsp;</td>
	</tr>

	<tr>
  	<td align="left">
	  <table border="0">
	    
	    <tr>
	      <td>

	      	<table border="0">
		        <tr>
		          <td colspan="3" height=35><font face="Arial, Helvetica, sans-serif" size="2"><b>Injected current</b></font></td>
				  <td colspan="7"><font size="2" face="Arial, Helvetica, sans-serif"><b>Pool</b></font>
					<html:select name="StimulationForm" property="cdNucleus" onchange="change();"> 
					<html:optionsCollection name="StimulationForm" property="nuclei" label="name" value="cd"/>
					</html:select> 
				  </td>
		        </tr>
		        
		        <tr>
		          <td colspan="10">&nbsp;</td>
		        </tr>
		        
		        <tr>
		          <td colspan="3">&nbsp;</td>
		          <td width="120" align="center"><b>Basal current</b></td>
		          <td colspan="6" align="center"><b>Modulation superimposed on the basal current</b></td>
		        </tr>
		        
		        <tr align="left" valign="top">
				  <td></td>
		          <td width="60" align="center"><font size="2" face="Arial, Helvetica, sans-serif"><b><br>Neuron</b></font></td>
		          <td width="100" align="center"><font size="2" face="Arial, Helvetica, sans-serif"><br>compartment</font></td>
		          <td width="120" align="center"><font size="2" face="Arial, Helvetica, sans-serif"><br>amp [nA]</font></td>
		          <td width="70" align="center"><font size="2" face="Arial, Helvetica, sans-serif"><br>modulation signal</font></td>
		          <td width="70" align="center"><font size="2" face="Arial, Helvetica, sans-serif"><br>start[ms]</font></td>
		          <td width="70" align="center"><font size="2" face="Arial, Helvetica, sans-serif"><br>stop[ms]</font></td>
		          <td width="70" align="center"><font size="2" face="Arial, Helvetica, sans-serif"><br>peak[nA]</font></td>
		          <td width="70" align="center"><font size="2" face="Arial, Helvetica, sans-serif"><br>freq[Hz]</font></td>
		          <td width="70" align="center"><font size="2" face="Arial, Helvetica, sans-serif"><br>width[ms]</font></td>
		        </tr>
		      	
				<logic:iterate name="StimulationForm" property="currents" id="current" indexId="index">
			        <tr align="left" valign="top">
					  <td><html:checkbox name="current" property="active" indexed="true"/></td>
			          <td align="left"><bean:write name="current" property="cdNeuronType"/></td>
			          <td align="center">
						<html:select name="current" property="compartment" indexed="true">
						<html:option value="S">soma</html:option>
						<html:option value="D">dendrite</html:option>
						</html:select>
					  </td>
			          <td align="center"><html:text name="current" property="imax" size="3" indexed="true" /></td>
			          <td align="center">
						<html:select name="current" property="cdSignal" indexed="true">
							<html:option value="none">none</html:option>
							<html:option value="constant">constant</html:option>
							<html:option value="ramp">ramp</html:option>
							<html:option value="random">random</html:option>
							<html:option value="sine">sine</html:option>
							<html:option value="square">square</html:option>
						</html:select>
							<html:hidden name="current" property="cdNucleus" indexed="true" />
							<html:hidden name="current" property="cdNeuronType" indexed="true" />
							<html:hidden name="current" property="index" indexed="true" />
					  </td>
			          <td align="center"><html:text name="current" property="ini" size="3" indexed="true"/></td>
			          <td align="center"><html:text name="current" property="fin" size="3" indexed="true"/></td>
			          <td align="center"><html:text name="current" property="amp" size="3" indexed="true"/></td>
			          <td align="center"><html:text name="current" property="freq" size="3" indexed="true"/></td>
			          <td align="center"><html:text name="current" property="width" size="3" indexed="true"/></td>
			        </tr>
				</logic:iterate>
	        </table>

		  </td>
		</tr>
	      
	  </table>
	  
	</td>
  	</tr>

  	<TR><TD align="center"><br><input type="button" value="  apply  " onclick="submit();"></TD></TR>

</table>

</html:form>

</body>

</html>
