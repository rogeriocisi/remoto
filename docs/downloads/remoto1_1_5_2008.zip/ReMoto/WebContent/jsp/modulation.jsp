<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<html>

<head>
  <title>ReMoto - A Remote Motoneuron Network Simulator</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" > 
</head>

<script>

<%
	String retorno = (String)request.getParameter("retorno");
	String peak = (String)request.getParameter("peak");
%>

function goToBack()
{
	document.ModulationForm.action = '<%=retorno%>.do';
	document.ModulationForm.submit();
}

</script>

<body BGCOLOR="#FAFFFF">

<html:form method="post" action="/modulation">

<html:hidden name="ModulationForm" property="task" value="saveModulation" />
<html:hidden name="ModulationForm" property="retorno" value="<%=retorno%>" />
<input type="hidden" name="peak" value="<%=peak%>">

<table border="0">

	<tr>
	  <td align="center">
		<b><font size="4" face="Arial, Helvetica, sans-serif">Signal modulation</font></b>
	  </td>
	</tr>

	<tr>
	  <td align="center">&nbsp;</td>
	</tr>

  	<tr>
      <td>
      
      	<table border="0">

        <tr>
          <td width="60" height=30><font size="2" face="Arial, Helvetica, sans-serif"><b>Target</b></font></td>
          <td width="120" height=30><font size="2" face="Arial, Helvetica, sans-serif">Modulating Signal</font></td>
          <td width="60" align="center"><font size="2" face="Arial, Helvetica, sans-serif">start[ms]</font></td>
          <td width="60" align="center"><font size="2" face="Arial, Helvetica, sans-serif">stop[ms]</font></td>
          <td width="80" align="center"><font size="2" face="Arial, Helvetica, sans-serif">peak[<%=peak%>]</font></td>
          <td width="60" align="center"><font size="2" face="Arial, Helvetica, sans-serif">freq[Hz]</font></td>
          <td width="60" align="center"><font size="2" face="Arial, Helvetica, sans-serif">width[ms]</font></td>
        </tr>

        <tr>
          <td align="left"><bean:write name="ModulationForm" property="cdSignal"/></td>
          <td align="center">
			<html:select name="ModulationForm" property="type">
				<html:option value="none">none</html:option>
				<html:option value="constant">constant</html:option>
				<html:option value="ramp">ramp</html:option>
				<html:option value="random">random</html:option>
				<html:option value="sine">sine</html:option>
				<html:option value="square">square</html:option>
			</html:select>
			<html:hidden name="ModulationForm" property="cdNucleus"/>
			<html:hidden name="ModulationForm" property="cdSignal"/>
		  </td>
          <td align="center"><html:text name="ModulationForm" property="tini" size="3"/></td>
          <td align="center"><html:text name="ModulationForm" property="tfin" size="3"/></td>
          <td align="center"><html:text name="ModulationForm" property="amp" size="3"/></td>
          <td align="center"><html:text name="ModulationForm" property="freq" size="3"/></td>
          <td align="center"><html:text name="ModulationForm" property="width" size="3"/></td>
	    </tr>

	    </table>
	  
	  </td>
  	</tr>

  	<TR><TD align="center"><br>
  		<input type="button" value="  return " onclick="goToBack();">
  		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  		<input type="button" value="  apply  " onclick="submit();">
  	</TD></TR>

</table>

</html:form>

</body>

</html>
