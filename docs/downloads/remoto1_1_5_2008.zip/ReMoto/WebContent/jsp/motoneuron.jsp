<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<HTML>

<head>
	<LINK REL="stylesheet" HREF="style.css" TYPE="text/css">
</head>

<script>

function change()
{
	document.NeuronForm.task.value = "MN";
	document.NeuronForm.submit();
}

function properties()
{
	document.NeuronForm.action = 'mn_electrotonic.do?task=MN';
	document.NeuronForm.submit();
}

</script>

<BODY BGCOLOR="#FAFFFF">

<html:form method="post" action="/motoneuron">

<html:hidden name="NeuronForm" property="task" value="saveMN" />

<TABLE border=0>
	<tr>
	  	<td colspan=4>
		<b><font size="4" face="Arial, Helvetica, sans-serif">Alpha Motoneurons Parameters</font></b>
		</td>
	</tr>
	
	<tr>
  		<td colspan=4>&nbsp;</td>
	</tr>

	<tr>
		<td colspan=3><b>Pool</b>
			<html:select name="NeuronForm" property="cdNucleus" onchange="change();"> 
			<html:optionsCollection name="NeuronForm" property="nuclei" label="name" value="cd"/>
			</html:select> 
		</td>
		<TD><input type="button" value="see properties" onclick="properties();">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="button" value="    apply    " onclick="submit();">
		</TD>
	</tr>
	
	<tr>
  		<td colspan=4>&nbsp;</td>
	</tr>
	
	<tr>
		<td valign="top">
			<TABLE border=0>
		  	<TR>
		    	<TD height=27>&nbsp;</TD>
		  	</TR>
		  	<TR>
		    	<TD height=27>&nbsp;</TD>
		  	</TR>
		  	<TR>
		    	<TD height=27>Soma rheobase [nA]</TD>
		  	</TR>
		  	<TR>
		    	<TD height=27>Axon threshold [mA]</TD>
		  	</TR>
		  	<TR>
		    	<TD height=27>Axon conduction velocity [m/s]</TD>
		  	</TR>
		  	<TR>
		    	<TD height=27>Soma specific resistance [ohm.cm2]</TD>
		  	</TR>
		  	<TR>
		    	<TD height=27>Dendrite specific resistance [ohm.cm2]</TD>
		  	</TR>
		  	<TR>
		    	<TD height=27>Soma diameter [um]</TD>
		  	</TR>
		  	<TR>
		    	<TD height=27>Soma length [um]</TD>
		  	</TR>
		  	<TR>
		    	<TD height=27>Dendrite diameter [um]</TD>
		  	</TR>
		  	<TR>
		    	<TD height=27>Dendrite length [um]</TD>
		  	</TR>
		  	<TR>
		    	<TD height=27>Membrane specific capacitance [uF/cm2]</TD>
		  	</TR>
		  	<TR>
		    	<TD height=27>Cytoplasm resistivity [ohm.cm]</TD>
		  	</TR>
		  	<TR>
		    	<TD height=10>&nbsp;</TD>
	  	    </TR>
		  	<TR>
		    	<TD height=27>Type relative index of signal stored MNs</TD>
		  	</TR>
		  	<TR>
		    	<TD height=10></TD>
	  	    </TR>
		  	<TR>
		    	<TD height=27>Nerve</TD>
		  	</TR>
		  	</TABLE>
		</td>

		<logic:iterate name="NeuronForm" property="motoneurons" id="mnType" indexId="index">
		<td valign="top">
			<TABLE border=0>
			  <TR>
			    <TD colspan=2 height=27 align=center><b>
			    <bean:write name="mnType" property="type"/></b>
				<html:hidden name="mnType" property="type" indexed="true"/>
				<html:hidden name="mnType" property="cdNucleus" indexed="true"/>
				<html:hidden name="mnType" property="category" indexed="true"/>
				<html:hidden name="mnType" property="quantity" indexed="true"/>
				<html:hidden name="mnType" property="active" indexed="true"/>
				<html:hidden name="mnType" property="cdNerve" indexed="true"/>
			    </TD>
			  </TR>
			  <TR>
			    <TD height=27 align=center>from</TD>
			    <TD height=27 align=center>to</TD>
			  </TR>
			  <TR>
			    <TD height=27><html:text name="mnType" property="rheobase1" size="4" indexed="true"/></TD>
			    <TD height=27><html:text name="mnType" property="rheobase2" size="4" indexed="true"/></TD>
			  </TR>
			  <TR>
			    <TD height=27><html:text name="mnType" property="axonThreshold1" size="4" indexed="true"/></TD>
			    <TD height=27><html:text name="mnType" property="axonThreshold2" size="4" indexed="true"/></TD>
			  </TR>
			  <TR>
			    <TD height=27><html:text name="mnType" property="axonVelocity1" size="4" indexed="true"/></TD>
			    <TD height=27><html:text name="mnType" property="axonVelocity2" size="4" indexed="true"/></TD>
			  </TR>
			  <TR>
			    <TD height=27><html:text name="mnType" property="rmSoma1" size="4" indexed="true"/></TD>
			    <TD height=27><html:text name="mnType" property="rmSoma2" size="4" indexed="true"/></TD>
			  </TR>
			  <TR>
			    <TD height=27><html:text name="mnType" property="rmDend1" size="4" indexed="true"/></TD>
			    <TD height=27><html:text name="mnType" property="rmDend2" size="4" indexed="true"/></TD>
			  </TR>
			  <TR>
			    <TD height=27><html:text name="mnType" property="dsoma1" size="4" indexed="true"/></TD>
			    <TD height=27><html:text name="mnType" property="dsoma2" size="4" indexed="true"/></TD>
			  </TR>
			  <TR>
			    <TD height=27><html:text name="mnType" property="lsoma1" size="4" indexed="true"/></TD>
			    <TD height=27><html:text name="mnType" property="lsoma2" size="4" indexed="true"/></TD>
			  </TR>
			  <TR>
			    <TD height=27><html:text name="mnType" property="ddend1" size="4" indexed="true"/></TD>
			    <TD height=27><html:text name="mnType" property="ddend2" size="4" indexed="true"/></TD>
			  </TR>
			  <TR>
			    <TD height=27><html:text name="mnType" property="ldend1" size="4" indexed="true"/></TD>
			    <TD height=27><html:text name="mnType" property="ldend2" size="4" indexed="true"/></TD>
			  </TR>
			  <TR>
			    <TD colspan=2 height=27><html:text name="mnType" property="cm" size="4" indexed="true"/></TD>
			  </TR>
			  <TR>
			    <TD colspan=2 height=27><html:text name="mnType" property="ri" size="4" indexed="true"/></TD>
			  </TR>
		  	  <TR>
		    	<TD colspan=2 height=10>&nbsp;</TD>
		  	  </TR>
			  <TR>
			    <TD height=27><html:text name="mnType" property="indexStoreVm1" size="4" indexed="true"/></TD>
			    <TD height=27><html:text name="mnType" property="indexStoreVm2" size="4" indexed="true"/></TD>
			  </TR>
		  	  <TR>
		    	<TD height=10>&nbsp;</TD>
		  	  </TR>
			  <TR>
			    <TD colspan=2 height=27><bean:write name="mnType" property="cdNerve"/></TD>
			  </TR>
		  	</TABLE>
		</td>
		</logic:iterate>

	</tr>

</TABLE>

</html:form>

</BODY>

</HTML>
