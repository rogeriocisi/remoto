<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<HTML>

<head>
	<LINK REL="stylesheet" HREF="style.css" TYPE="text/css">
</head>

<script>

function change(value)
{
	document.SynapseForm.task.value = value;
	document.SynapseForm.submit();
}

</script>

<BODY BGCOLOR="#FAFFFF">

<html:form method="post" action="/synapse">

<html:hidden name="SynapseForm" property="task" value="save" />

<TABLE border=0>

	<tr>
	  	<td colspan=9>
		<b><font size="4" face="Arial, Helvetica, sans-serif">Synaptic Parameters</font></b>
		</td>
	</tr>
	
	<tr>
  		<td colspan=9>&nbsp;</td>
	</tr>

	<tr>
		<td colspan=3><b>Pool</b>
			<html:select name="SynapseForm" property="cdNucleus" onchange="change('change');"> 
			<html:optionsCollection name="SynapseForm" property="nuclei" label="name" value="cd"/>
			</html:select> 
		</td>
  		<td colspan=6>&nbsp;&nbsp;&nbsp;<a href="markov.do?option=S">kinetic properties</a></td>
	</tr>
	
	<tr>
  		<td colspan=9>&nbsp;</td>
	</tr>

	<tr>
		<td colspan=3><b>Incoming cell</b>
			<html:select name="SynapseForm" property="typePre" onchange="change('change');"> 
			<html:optionsCollection name="SynapseForm" property="typesPre" label="categoryTypeForSynapse" value="categoryTypeForSynapse"/>
			</html:select> 
		</td>
		<td colspan=3><b>Target cell</b>
			<html:select name="SynapseForm" property="typePos" onchange="change('change');"> 
			<html:optionsCollection name="SynapseForm" property="typesPos" label="categoryTypeForSynapse" value="categoryTypeForSynapse"/>
			</html:select> 
		</td>
		<td colspan=3>
			<input type="button" value="  apply  " onclick="submit();">
		</td>
	</tr>
	
	<tr>
  		<td colspan=9>&nbsp;</td>
	</tr>

	<logic:notEmpty name="SynapseForm" property="conductances">
		<tr>
			<td></td>
			<td width=150><b>incoming</b></td>
			<td width=100><b>target</b></td>
			<td align=left width=80><b>polarity</b></td>
			<td align=center width=90><b>compartment</b></td>
			<td align=center width=90><b>conductance max [nS]</b></td>
			<td align=center width=90><b>connectivity [%]</b></td>
			<td align=center width=80><b>transmission delay [ms]</b></td>
			<td align=center width=80><b>dynamics</b></td>
		</tr>
	
		<logic:iterate name="SynapseForm" property="conductances" id="conducType" indexId="index">
			<tr>
				<td><html:checkbox name="conducType" property="active" indexed="true"/></td>
				<td><bean:write name="conducType" property="pre"/>
				<td><bean:write name="conducType" property="pos"/>
					<html:hidden name="conducType" property="cdConductanceType" indexed="true"/>
					<html:hidden name="conducType" property="cdNucleus" indexed="true"/>
					<html:hidden name="conducType" property="cdNucleusPre" indexed="true"/>
				</td>
			    <td align=left>
			    	<bean:write name="conducType" property="polarity"/>
			    	<html:hidden name="conducType" property="e" indexed="true"/>
			    	<html:hidden name="conducType" property="tpeak" indexed="true"/>
			    </td>
			    <td align=center>
					<logic:notEqual name="conducType" property="compartment" value="" >
						<html:select name="conducType" property="compartment" indexed="true">
						<html:option value="S">soma</html:option>
						<html:option value="D">dendrite</html:option>
						</html:select>
					</logic:notEqual>
					<logic:equal name="conducType" property="compartment" value="" >
						not applicable
				    	<html:hidden name="conducType" property="compartment" indexed="true"/>
					</logic:equal>
			    </td>
			    <td align=center><html:text name="conducType" property="gmax" size="4" indexed="true"/></td>
			    <td align=center><html:text name="conducType" property="connectivity" size="3" indexed="true"/></td>
			    <td align=center><html:text name="conducType" property="delay" size="3" indexed="true"/></td>
			    <td align=center>
		          	<a href='dynamics.do?cdNucleusPre=<bean:write name="conducType" property="cdNucleusPre"/>&cdNucleus=<bean:write name="conducType" property="cdNucleus"/>&cdConductanceType=<bean:write name="conducType" property="cdConductanceType"/>'>
						<bean:write name="conducType" property="dynamicType"/>
		          	</a>
		    	</td>
			</tr>
		</logic:iterate>
	
	</logic:notEmpty>

	<TR><TD colspan=9 align="center"><br><input type="button" value="  apply  " onclick="submit();"></TD></TR>

</TABLE>

</html:form>

</BODY>

</HTML>
