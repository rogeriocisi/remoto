<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<html>

<head>
  <title>ReMoto - A Remote Motoneuron Network Simulator</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" > 
</head>

<body BGCOLOR="#FAFFFF">

<%
String msg = (String)request.getAttribute("msg");
if( msg == null ) 
	msg = "";
else
	msg = msg + "<br>&nbsp;";
%>

<script>

function post(task)
{
	document.GeneralForm.task.value = task;

	if( task == 'reload' )
	{
		if( confirm("Reload default configuration? (current settings will be deleted)") == true )
			document.GeneralForm.submit();
	}	
	else if( task == 'delete' )
	{
		if( confirm("Delete selected scenario (all configuration settings)?") == true )
			document.GeneralForm.submit();
	}	
	else if( task == 'new' )
	{
		if( confirm("Create new scenario based on the current one?") == true )
			document.GeneralForm.submit();
	}
	else
	{
		document.GeneralForm.submit();
	}
}

</script>

<html:form method="post" action="/general">

<html:hidden name="GeneralForm" property="task" value="save" />

<table width="500" border="0">
  <tr>
  	<td align="center">
	<b><font size="4" face="Arial, Helvetica, sans-serif">Simulation General Parameters</font></b>
	</td>
  </tr>
  <tr>
  	<td>&nbsp;</td>
  </tr>
  <tr>
  	<td><%=msg%>&nbsp;</td>
  </tr>
  <tr>
  	<td align="left">
	  <table border="0">
	    
	    <tr>
	      <td>
	      	<table border="0">

		        <tr>
		          <td><font face="Arial, Helvetica, sans-serif" size="2"><b>Scenario</b></font></td>
		          <td align=left>
				  	<html:select name="GeneralForm" property="id" onchange="post('load');"> 
					<html:optionsCollection name="GeneralForm" property="configurations" label="name" value="id"/>
					</html:select>
				  </td>
		        </tr>
		
		        <tr>
		          <td><font face="Arial, Helvetica, sans-serif" size="2"><b>Name</b></font></td>
		          <td><html:text name="GeneralForm" size="40" property="nmConfiguration"/></td>
		        </tr>
		
		        <tr>
		          <td><font face="Arial, Helvetica, sans-serif" size="2"><b>Description</b></font></td>
		          <td><html:textarea name="GeneralForm" cols="30" rows="3" property="dsConfiguration"/></td>
		        </tr>
		
				<logic:notEqual name="GeneralForm" property="cdUser" value="guest">
				<logic:notEqual name="GeneralForm" property="id" value="1">
			        <tr>
			          <td colspan=2>&nbsp;</td>
			        </tr>
			        <tr align="left" valign="top">
			          <td colspan=2><html:checkbox name="GeneralForm" property="storeResults" /><font face="Arial, Helvetica, sans-serif" size="2"> Store simulation results for future visualization</font></td>
			        </tr>
				</logic:notEqual>
				</logic:notEqual>
		
		        <tr>
		          <td colspan=2>&nbsp;</td>
		        </tr>
		
		        <tr>
		          <td colspan=2>&nbsp;</td>
		        </tr>
		
		        <tr>
		          <td colspan=2>&nbsp;</td>
		        </tr>
		
			    <tr>
			      <td colspan="2" align=center>
					<input type="button" value="  new  " onclick="post('new');">
			      	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			      	<input type="button" value=" delete " onclick="post('delete');">
			      	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			      	<input type="button" value="  save  " onclick="post('save');">
			      	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			      	<input type="button" value=" reload " onclick="post('reload');">
			      </td>
		        </tr>
		
		        <tr>
		          <td colspan=2>&nbsp;</td>
		        </tr>
		
			    <tr>
			      <td colspan="2">
			      </td>
			    </tr>
	    
	  		</table>
		  </td>
		</tr>
	</table>

	</td>
  </tr>
</table>

</html:form>

</body>

</html>
