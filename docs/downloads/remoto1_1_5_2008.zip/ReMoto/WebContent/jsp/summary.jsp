<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ page import="java.util.*,br.remoto.model.vo.Summary" %>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<html>
<head>
  <title>ReMoto - A Remote Motoneuron Network Simulator</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" > 
</head>

<body BGCOLOR="#FAFFFF">

<%
List summ = (List)request.getAttribute( "summ" );
String duration = (String)request.getAttribute( "duration" );
%>

Simulated time: <%=duration%> ms
<br>&nbsp;

<%
for(int i = 0; i < summ.size(); i++)
{
	Summary s = (Summary)summ.get(i);
	
	String nucleus = s.getNucleus();
	String type = s.getNeuronType();
	String cd = s.getCd();
	int numSpikes = s.getNumSpikes();
	double freq = s.getRateSteadyState();
	double gMaxExc = s.getGMaxExc();
	double gMaxInh = s.getGMaxInh();
	int numberOfSpikesReceivedExc = s.getNumberOfSpikesReceivedExc();
	int numberOfSpikesReceivedInh = s.getNumberOfSpikesReceivedInh();
	double inputResistance = s.getInputResistance();
	double threshold = s.getThreshold();
%>
<br>Neuron pool: <%=nucleus%>
<br>Neuron type: <%=type%>
<br>Neuron cd: <%=cd%>
<br>Input resistance: <%=inputResistance%>
<br>Threshold: <%=threshold%>
<br>Number of spikes: <%=numSpikes%>
<br>Firing rate (steady-state): <%=freq%> pps
<br>Maximal excitation: <%=gMaxExc%> nS
<br>Maximal inhibition: <%=gMaxInh%> nS
<br>Excitatory spikes received: <%=numberOfSpikesReceivedExc%>
<br>Inhibitory spikes received: <%=numberOfSpikesReceivedInh%>
<br>&nbsp;
<%
}
%>

</body>
</html>
