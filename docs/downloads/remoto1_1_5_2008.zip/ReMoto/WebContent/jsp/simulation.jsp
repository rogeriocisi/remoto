<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<html>
<head>
  <title>ReMoto - A Remote Motoneuron Network Simulator</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" > 
  <meta http-equiv="refresh" content="5;URL=simulation.do?task=simulating"> 
</head>

<body BGCOLOR="#FAFFFF">

<html:form method="post" action="/simulation.do?task=cancel">

<br>Simulation in progress. 
<br><br>Wait...

<logic:notEqual name="SimulationForm" property="start" value="" >

<br><br>Start: <bean:write name="SimulationForm" property="start"/> h (GMT-3)
<br><br>Percentage: <bean:write name="SimulationForm" property="percentage"/>
<br><br><input type="button" value=" cancel " onclick="submit();">

</logic:notEqual>

</html:form>

</body>
</html>
