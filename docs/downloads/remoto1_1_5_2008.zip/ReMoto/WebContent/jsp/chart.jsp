<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ page import="java.util.*" %>

<html>
<head>
  <title>ReMoto - A Remote Motoneuron Network Simulator</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" > 
</head>

<body BGCOLOR="#FAFFFF">

<%
String cdSimulation = (String)request.getAttribute( "cdSimulation" );
%>


<IMG SRC="/remoto/servlet/ServletChartGenerator?cdSimulation=<%=cdSimulation%>&id=<%=Math.random()%>" BORDER=0/>


</body>
</html>
