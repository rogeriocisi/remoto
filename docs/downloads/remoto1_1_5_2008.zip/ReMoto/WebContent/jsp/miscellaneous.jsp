<%@ page contentType="text/html;charset=ISO-8859-1"%>
<%@ taglib uri="/WEB-INF/struts-html.tld" prefix="html"%>
<%@ taglib uri="/WEB-INF/struts-logic.tld" prefix="logic"%>
<%@ taglib uri="/WEB-INF/struts-bean.tld" prefix="bean"%>

<html>

<head>
  <title>ReMoto - A Remote Motoneuron Network Simulator</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" > 
</head>

<body BGCOLOR="#FAFFFF">

<html:form method="post" action="/miscellaneous">

<html:hidden name="MiscellaneousForm" property="task" value="save" />

<table width="500" border="0">
  <tr>
  	<td>
	<b><font size="4" face="Arial, Helvetica, sans-serif">Miscellaneous - Constant Properties</font></b>
	</td>
  </tr>
  <tr>
  	<td align="left">
	  <table border="0">
	    
	    <tr>
	      <td>
	      	<table border="0">

		    <TR><TD colspan=2 align="left"><br><input type="button" value="  apply  " onclick="submit();"></TD></TR>
		    <TR><TD align="left">&nbsp;</TD></TR>
	      	
			<logic:iterate name="MiscellaneousForm" property="miscellaneous" id="prop" indexId="index">
		        <tr>
		          <td><font face="Arial, Helvetica, sans-serif" size="2"><bean:write name="prop" property="description"/></font></td>
		          <td>	<html:text name="prop" property="value" size="4" indexed="true"/>
		          		<html:hidden name="prop" property="property" indexed="true"/>
		          		<html:hidden name="prop" property="description" indexed="true"/>
		          		<html:hidden name="prop" property="index" indexed="true"/>
		          		<html:hidden name="prop" property="division" indexed="true"/>
		          </td>
		        </tr>

				<logic:equal name="prop" property="division" value="true" >
					<tr><td colspan=2>&nbsp;</td></tr>
				</logic:equal>

			</logic:iterate>
	
	        <tr align="left" valign="top">
	          <td colspan=2><font face="Arial, Helvetica, sans-serif" size="2">* Properties that can vary for each simulation run, according to the chosen CV</font></td>
	        </tr>

	        <tr>
	          <td colspan=2>&nbsp;</td>
	        </tr>

	        <tr align="left" valign="top">
	          <td colspan=2><html:checkbox name="MiscellaneousForm" property="storeSignals" /><font face="Arial, Helvetica, sans-serif" size="2"> Store neuron signals (membrane potential and conductance time course)</font></td>
	        </tr>
		
	        <tr align="left" valign="top">
	          <td colspan=2><html:checkbox name="MiscellaneousForm" property="keepProperties" /><font face="Arial, Helvetica, sans-serif" size="2"> Keep the same random property values for repeatable simulations</font></td>
	        </tr>

	        <tr>
	          <td colspan=2>&nbsp;</td>
	        </tr>

		    <TR><TD colspan=2 align="center"><br><input type="button" value="  apply  " onclick="submit();"></TD></TR>
	  </table>
	</td>
  </tr>
</table>

</html:form>

</body>

</html>
