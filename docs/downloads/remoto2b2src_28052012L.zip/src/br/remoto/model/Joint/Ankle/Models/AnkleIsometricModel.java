package br.remoto.model.Joint.Ankle.Models;


import java.util.ArrayList;

import br.remoto.model.Configuration;
import br.remoto.model.ModulatingSignal;
import br.remoto.model.Joint.Ankle.AnkleSuperClass;
//import br.remoto.model.Musculotendon.Muscle.Muscle;
import br.remoto.model.Musculotendon.MusculotendonSuperClass;
import br.remoto.model.Neuron.Miscellaneous;
import br.remoto.util.ButterworthBilinear;
import br.remoto.util.ButterworthImpulseInvariance;
import br.remoto.util.Sample;
import br.remoto.util.Signal;


public class AnkleIsometricModel extends AnkleSuperClass
{
	private static final long serialVersionUID = 1L;
	
	private double angleArray[];
	int iteration;
	private ButterworthBilinear butterBilinear;
	
	double scaleFactorDorsiflexors;
	double scaleFactorPlantarflexors;
	
	MusculotendonSuperClass[] musculotendons;
	Configuration conf;
	
	public AnkleIsometricModel(Configuration conf, MusculotendonSuperClass[] musculotendons){
		super(conf.getJointVO());
		
		this.conf = conf;
		this.musculotendons = musculotendons;
		
		samplerJointAngleStore = new Sample(conf.getDecimationFrequency(), 1000 / conf.getStep());
		samplerJointTorqueStore = new Sample(conf.getDecimationFrequency(), 1000 / conf.getStep());
		
		scaleFactorDorsiflexors = 1;
		scaleFactorPlantarflexors = 1;
		
		iteration = 0;
		
		butterBilinear = new ButterworthBilinear();
		
		angleArray = new double[(int) (conf.getTFin() / conf.getStep())];
		
		for(int i = 0; i < angleArray.length; i++){
			
			double t = i * conf.getStep();
			/*
			if(t >= 10000 && t <= 30000)
				angleArray[i] = 0.001 * (t - 10000);
			else if(t >= 30000 && t <= 40000)
				angleArray[i] = 20;
			else if(t >= 40000 && t <= 80000)
				angleArray[i] = 20 - 0.001 * (t - 40000);
			else if(t >= 80000 && t <= 90000)
				angleArray[i] = -20;
			else if(t >= 90000 && t <= 110000)
				angleArray[i] = -20 + 0.001 * (t - 90000);
			else
				angleArray[i] = 0;
			*/
			/*
			if(t >= 1000 && t <= 2000)
				angleArray[i] = 0.02 * (t - 1000);
			else if(t >= 2000 && t <= 3000)
				angleArray[i] = 20;
			else if(t >= 3000 && t <= 5000)
				angleArray[i] = 20 -0.025 * (t - 3000);
			else if(t >= 5000 && t <= 5010)
				angleArray[i] = -30;
			else if(t >= 5010 && t <= 6010)
				angleArray[i] = -30 + 0.03 * (t - 5010);
			else
				angleArray[i] = 0;
			*/
			
			
			/*
			ModulatingSignal signal = new ModulatingSignal();
			
		    signal.setCdSignal("sine");
			signal.setAmp(6);
			signal.setTini(0);
			signal.setTfin(3000);
			signal.setFreq(3);
			signal.setDelay(0);
			
			angleArray[i] = 0 + signal.value(t);
			*/
			
			
			
			/*
			if(t >= 1000 && t <= 2000)
				angleArray[i] = 0.015 * (t - 1000);
			else if(t >= 2000 && t <= 3000)
				angleArray[i] = 15;
			else if(t >= 3000 && t <= 5000)
				angleArray[i] = 15 -0.015 * (t - 3000);
			else if(t >= 5000 && t <= 6000)
				angleArray[i] = -15;
			else if(t >= 6000 && t <= 7000)
				angleArray[i] = -15 + 0.015 * (t - 6000);
			else
				angleArray[i] = 0;
			*/
			/*
			double width = 6000 / conf.getJointVelocity();
			
			ModulatingSignal signal = new ModulatingSignal();
			
		    signal.setCdSignal("ramp");
			signal.setAmp(6);
			signal.setTini(1000);
			signal.setTfin(3000);
			signal.setWidth(width);
			
			ModulatingSignal signal2 = new ModulatingSignal();
			
		    signal2.setCdSignal("ramp");
			signal2.setAmp(6);
			signal2.setTini(1460);
			signal2.setTfin(3000);
			signal2.setWidth(width);
			
			angleArray[i] = 0 + signal.value(t) - signal2.value(t);
			*/
			/*
			ModulatingSignal signal = new ModulatingSignal();
			
		    signal.setCdSignal("ramp");
			signal.setAmp(3);
			signal.setTini(500);
			signal.setTfin(1000);
			signal.setWidth(75);
			
			angleArray[i] = signal.value(t);
			*/
			
			/*
			ModulatingSignal signal = new ModulatingSignal();
			
			double width = conf.getJointAngle() * 1000 / conf.getJointVelocity();
			
		    signal.setCdSignal("ramp");
			signal.setAmp(conf.getJointAngle());
			signal.setTini(1000);
			signal.setTfin(1500);
			signal.setWidth(width);
			
			angleArray[i] = 0 + signal.value(t);
			*/
			
			angleArray[i] = 0;
			
			/*
			ModulatingSignal signal = new ModulatingSignal();
			
			double width = 6000 / conf.getJointVelocity();
			
		    signal.setCdSignal("sine");
		    signal.setFreq(1.33);
			signal.setAmp(25);
			signal.setTini(500);
			signal.setTfin(1500);
			signal.setDelay(500);
			
			angleArray[i] = 5 + signal.value(t);
			*/
		}
		
		kneeAngle = conf.getKneeAngle();
		
		//angleArray = butterBilinear.lowPass(angleArray, 100, conf.getStep() * 1e-3);
	}
	
	
	public void atualize(double t){
		
		samplerJointAngleStore.sample(jointAngleStore, t, angle);
		samplerJointTorqueStore.sample(jointTorqueStore, t, torque);
		
		angle = calculateAngle(t);
		
		/*
		if(angle >=0){
			torque = calculateTorque(t) - angle * 0.5 - 1;
		}
		else{
			torque = calculateTorque(t) - angle * 0.2 - 1;
		}
		*/
		
		torque = calculateTorque(t);
		
	}
	
	private double calculateAngle (double t){
		
		double result;
		double filteredResult;
		/*
		if(t >= 1000 && t <= 2000)
			result = 0.02 * (t - 1000);
		else if(t >= 2000 && t <= 3000)
			result = 20;
		else if(t >= 3000 && t <= 5000)
			result = 20 -0.02 * (t - 3000);
		else if(t >= 5000 && t <= 6000)
			result = -20;
		else if(t >= 6000 && t <= 7000)
			result = -20 + 0.02 * (t - 6000);
		else
			result = 0;
		*/
		//angleArray[angleIndex++] = result;
		
		
		
		
		/*
		if(t >= 500 && t <= 1000)
			result = 0.04 * (t - 500);
		else if(t >= 1000 && t <= 1500)
			result = 20;
		else if(t >= 1500 && t <= 2500)
			result = 20 -0.04 * (t - 1500);
		else if(t >= 2500 && t <= 3000)
			result = -20;
		else if(t >= 3000 && t <= 3500)
			result = -20 + 0.04 * (t - 3000);
		else
			result = 0;
		*/
		
		
		//result = 6 / (1 + Math.exp(-(t - 1000)/100));
		
		/*
		result = 6 / (1 + Math.exp(-(t - 1000)/10)) -
					6 / (1 + Math.exp(-(t - 1500)/10));
		*/
		
		/*
		ModulatingSignal signal = new ModulatingSignal();
		
	    signal.setCdSignal("ramp");
		signal.setAmp(6);
		signal.setTini(1000);
		signal.setTfin(1793);
		signal.setWidth(333);
		
		result = signal.value(t);
		*/
		/*
		double width = 6000 / conf.getJointVelocity();
		
		
		
		ModulatingSignal signal = new ModulatingSignal();
		
	    signal.setCdSignal("ramp");
		signal.setAmp(6);
		signal.setTini(1000);
		signal.setTfin(3000);
		signal.setWidth(width);
		
		ModulatingSignal signal2 = new ModulatingSignal();
		
	    signal2.setCdSignal("ramp");
		signal2.setAmp(6);
		signal2.setTini(1460);
		signal2.setTfin(3000);
		signal2.setWidth(width);
		
		result = 0 + signal.value(t) - signal2.value(t);
		*/
		/*
		ModulatingSignal signal = new ModulatingSignal();
		
	    signal.setCdSignal("ramp");
		signal.setAmp(3);
		signal.setTini(500);
		signal.setTfin(1000);
		signal.setWidth(75);
		
		result = signal.value(t);
		*/
		/*
		ModulatingSignal signal = new ModulatingSignal();
		
	    signal.setCdSignal("ramp");
		signal.setAmp(conf.getJointAngle());
		signal.setTini(100);
		signal.setTfin(2000);
		signal.setWidth(1500);
		
		result = signal.value(t);
		*/
		//result = conf.getJointAngle();
		
		
		filteredResult = angleArray[iteration];
		iteration++;
		
		return filteredResult;
	}
	
	private double calculateTorque (double t){
		
		double resultantTorque = 0;
		
		for(int i = 0; i < musculotendons.length; i++){
			
			if(musculotendons[i] != null){
				
				if(musculotendons[i].getCdMuscle().equals("TA")){
					resultantTorque += scaleFactorDorsiflexors * musculotendons[i].getForce() * musculotendons[i].getMomentArm();
				}
				else{
					resultantTorque += scaleFactorPlantarflexors * musculotendons[i].getForce() * musculotendons[i].getMomentArm();
				}
				
				
			
			}
			//System.out.println("musculotendons.length: " + musculotendons.length);
			
			//System.out.println("muscle: " + musculotendons[i].getCdMuscle());
			
			
		}
		
		//System.out.println("resultantTorque: " + resultantTorque);
		
		return resultantTorque;
	}

}
